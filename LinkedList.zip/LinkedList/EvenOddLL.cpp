#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main() {

    Node* root = new Node(1);
    root->next = new Node(2);
    root->next->next = new Node(3);
    root->next->next->next=new Node(4);
    root->next->next->next->next=new Node(5);

    Node* odd=root;
    Node* even=root->next;
    Node* evenHead=root->next;

    while(even!=NULL && even->next!=NULL)
    {
        odd->next=odd->next->next;
        even->next=even->next->next;

        odd=odd->next;
        even=even->next;
    }

    odd->next=evenHead;

    printList(root);
}