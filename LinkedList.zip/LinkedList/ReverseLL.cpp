#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

int main() {

    Node* root = new Node(1);
    root->next = new Node(2);
    root->next->next = new Node(0);
    root->next->next->next=new Node(0);
    root->next->next->next->next=new Node(1);

    Node* temp=root;
    Node* prev=NULL;

    while(temp!=NULL)
    {
        Node* front=temp->next;
        temp->next=prev;

        prev=temp;
        temp=front;
    }

    printList(prev);

}