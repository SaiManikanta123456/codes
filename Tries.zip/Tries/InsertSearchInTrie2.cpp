#include<bits/stdc++.h>
using namespace std;

struct Trie
{
    Trie* links[26];
    int endsWith=0;
    int countPrefix=0;

    bool containsKey(char ch)
    {
        return links[ch-'a']!=NULL;
    }

    void put(char ch,Trie* node)
    {
        links[ch-'a']=node;
    }

    Trie* get(char ch)
    {
        return links[ch-'a'];
    }

    void incrementEndswith()
    {
        endsWith++;
    }

    void incrementCountPrefix()
    {
        countPrefix++;
    }

    void decrementEndswith()
    {
        endsWith--;
    }

    void decrementCountPrefix()
    {
        countPrefix--;
    }

    int getCountPrefix()
    {
        return countPrefix;
    }

    int getEndsWith()
    {
        return endsWith;
    }
};

class TrieImplimentation
{
    Trie* root;
    public:
    TrieImplimentation()
    {
        root=new Trie();
    }

    void insert(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            {
                node->put(word[i],new Trie());
            }
            node=node->get(word[i]);
            node->incrementCountPrefix();
        }
        node->incrementEndswith();
    }

    int countWords(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(node->containsKey(word[i]))
            {
                node=node->get(word[i]);
            }
            else
            {
                return 0;
            }
        }
        return node->getEndsWith();
    }

    int countMatches(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(node->containsKey(word[i]))
            {
                node=node->get(word[i]);
            }
            else
            {
                return 0;
            }
        }
        return node->getCountPrefix();
    }

    void deleteTrie(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(node->containsKey(word[i]))
            {
                node=node->get(word[i]);
                node->decrementCountPrefix();
            }
            else
            {
                return;
            }
        }

        node->decrementEndswith();
    }
};

int main()
{
    TrieImplimentation* t=new TrieImplimentation();
    t->insert("sai");
    t->insert("saii");
    t->insert("saiii");
    cout << t->countWords("sai") << "\n";     
    cout << t->countMatches("sa") << "\n";     
}