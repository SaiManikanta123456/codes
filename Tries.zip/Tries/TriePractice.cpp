#include<bits/stdc++.h>
using namespace std;

struct Trie
{
    Trie* links[26];
    bool flag=false;

    bool containsKey(char i)
    {
        return links[i-'a']!=NULL;
    }

    void put(char ch,Trie* trie)
    {
        links[ch-'a']=trie;
    }

    Trie* get(char ch)
    {
        return links[ch-'a'];
    }

    void setEnd()
    {
        flag=true;
    }

    bool isEnd()
    {
        return flag;
    }
};


class TrieImplimentation
{
    Trie* root;
    public:
    TrieImplimentation()
    {
        root=new Trie();
    }

    void insert(string word,int &c)
    {
        Trie* node=root;

        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            {
                node->put(word[i],new Trie());
            }
            else
            {
                c++;
            }

            node=node->get(word[i]);
        }

        node->setEnd();
    }


    bool search(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            {
                return false;
            }
            node=node->get(word[i]);
        }

        if(node->isEnd())
        return true;

        return false;
    }

    bool startsWith(string prefix)
    {
        Trie* node=root;
        for(int i=0;i<prefix.length();i++)
        {
            if(!node->containsKey(prefix[i]))
            {
                return false;
            }
            node=node->get(prefix[i]);
        }

        return true;
    }
};

int main()
{
    TrieImplimentation* t=new TrieImplimentation();

    vector<string>words{"dog","racecar","car"};

    int c=0;
    t->insert(words[0],c);

    for(int i=1;i<words.size();i++)
    {
        int c=0;
        t->insert(words[i],c);
        cout<<c<<endl;
    }
}