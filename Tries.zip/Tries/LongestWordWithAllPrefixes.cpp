#include<bits/stdc++.h>
using namespace std;

struct Trie
{
    Trie* links[26];
    bool flag=false;

    bool containsKey(char ch)
    {
        return links[ch-'a']!=NULL;
    }

    void put(char ch,Trie* node)
    {
        links[ch-'a']=node;
    }

    Trie* get(char ch)
    {
        return links[ch-'a'];
    }

    void setEnd()
    {
        flag=true;
    }

    bool isEnd()
    {
        return flag;
    }
};

class TrieImplimentation
{
    Trie* root;

    public:
    TrieImplimentation()
    {
        root=new Trie();
    }

    void insert(string word)
    {

        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            {
                node->put(word[i],new Trie());
            }

            node=node->get(word[i]);
        }
        
        node->setEnd();
    }

    bool checkIfPrefixExists(string word)
    {
        Trie* node=root;

        for(int i=0;i<word.length();i++)
        {
            if(node->containsKey(word[i]))   
            {
                node=node->get(word[i]);
                if(node->isEnd()==false)
                return false;
            }
            else
            {
                return false;
            }
        }

        return true;
    }
};

int main()
{
    TrieImplimentation* t=new TrieImplimentation();
    t->insert("s");
    t->insert("sa");
    t->insert("sai");
    t->insert("saim");
    t->insert("szx");
    vector<string>words{"s","sa","sai","saim","szx"};
    string ans="";
    for(int i=0;i<5;i++)
    {
        if(t->checkIfPrefixExists(words[i]))
        {
            if(words[i].length()>ans.length())
            {
                ans=words[i];
            }
            else if(words[i].length() == ans.length() && words[i]<ans)
            {
                ans=words[i];
            }
        }
    }

    cout<<ans;
}