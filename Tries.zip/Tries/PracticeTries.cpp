#include<bits/stdc++.h>
using namespace std;

struct Trie
{
    Trie* links[26];
    bool flag=false;

    bool containsKey(char ch){
    return links[ch-'a']!=NULL;
    }

    Trie* get(char ch){
    return links[ch-'a'];
    }

    void put(char ch,Trie* trie)
    {
        links[ch-'a']=trie;
    }

    bool isEnd(){
    return flag;
    }

    void setEnd()
    {
    flag=true;
    }
};

class TrieImplimentation{

    public: 
    Trie* root;
    TrieImplimentation()
    {
        root=new Trie();
    }

    void insert(string word)
    {
        Trie* node=root;

        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            {
                node->put(word[i],new Trie());
            }
            node=node->get(word[i]);
        }

        node->setEnd();
    }

    bool search(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            return false;

            node=node->get(word[i]);
        }

        return node->isEnd();
    }

    bool searchPattern(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            if(!node->containsKey(word[i]))
            return false;

            node=node->get(word[i]);
        }

        return true;
    }
};

int main()
{
    TrieImplimentation* t=new TrieImplimentation();
    t->insert("s");
    t->insert("sa");
    t->insert("sai");
    t->insert("saim");
    t->insert("szx");
    vector<string>words{"s","sa","sai","saim","szx"};

    string ans="";

    for(auto word:words)
    {
        if(t->searchPattern(word))
        {
            if(word.length() > ans.length())
            {
                ans=word;
            }
            else if(word.length() == ans.length() && word<ans)
            {
                ans=word;
            }
        }
    }

    cout<<ans;
}