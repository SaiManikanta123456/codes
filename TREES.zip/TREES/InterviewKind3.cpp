#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

int diameter(Node* root,int &maxi)
{
    if(!root)
    return 0;

    int lh=diameter(root->left,maxi);
    int rh=diameter(root->right,maxi);

    maxi=max(maxi,lh+rh);

    return 1+max(lh,rh);
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    int maxi=INT_MIN;
    int c=diameter(root,maxi);
    cout<<maxi;
}