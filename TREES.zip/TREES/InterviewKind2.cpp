#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

bool rootToNode(Node* root,vector<int> &ds,int x)
{
    if(!root)
    return false;

    ds.push_back(root->data);

    if(root->data==x)
    return true;

    if(rootToNode(root->left,ds,x) || rootToNode(root->right,ds,x))
    return true;

    ds.pop_back();

    return false;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    Node* p=new Node(5);
    Node* q=new Node(8);

    vector<int>ds1;
    vector<int>ds2;

    int ans=-1;
    int i=0,j=0;

    if(rootToNode(root,ds1,p->data) && rootToNode(root,ds2,q->data))
    {
        while(true)
        {
            if(ds1[i]==ds2[j])
            {
                ans=ds1[i];
                i++;j++;    
            }
            else
            {
                break;
            }
        }
    }

    cout<<ans;
}