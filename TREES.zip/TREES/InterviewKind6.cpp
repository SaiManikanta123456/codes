#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

bool isLeaf(Node* root)
{
    if(root->left==NULL && root->right==NULL)
    return true;

    return false;
}

void leftB(Node* root,vector<int> &res)
{
    Node* cur=root->left;

    while(cur)
    {
        if(!isLeaf(cur))
        {
            res.push_back(cur->data);
        }
        if(cur->left)
        cur=cur->left;
        else
        cur=cur->right;
    }
}

void leafB(Node* root,vector<int> &res)
{
    if(!root)
    return;

    if(isLeaf(root))
    {
        res.push_back(root->data);
        return;
    }

    leafB(root->left,res);
    leafB(root->right,res);
}

void rightB(Node* root,vector<int> &res)
{
    Node* cur=root->right;

    stack<int>st;
    while(cur)
    {
        if(!isLeaf(cur))
        {
            st.push(cur->data);
        }

        if(cur->right)
        cur=cur->right;
        else
        cur=cur->left;
    }

    while(!st.empty())
    {
        res.push_back(st.top());
        st.pop();
    }
}

void boundaryTraversal(Node* root,vector<int> &res)
{
    if(!root)
    return;

    leftB(root,res);
    leafB(root,res);
    rightB(root,res);
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    vector<int>res;
    res.push_back(root->data);
    boundaryTraversal(root,res);
    for(auto i:res)
    cout<<i<<" ";
}