#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

int isHeightBalanced(Node* root)
{
    if(!root)
    return -1;

    int lh=isHeightBalanced(root->left);
    int rh=isHeightBalanced(root->right);

    if(abs(lh-rh)>1 || lh==-1 || rh==-1)
    return -1;

    return 1+max(lh,rh);
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    if(isHeightBalanced(root)!= -1)
    cout<<"True";
    else
    cout<<"False";
}