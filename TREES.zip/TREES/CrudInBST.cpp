#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

bool checkBst(Node* root,int mini,int maxi)
{
    if(!root)
    return true;

    if(root->data <= mini || root->data >= maxi)
    return false;

    return checkBst(root->left,mini,root->data) && checkBst(root->right,root->data,maxi);
}

bool searchInBst(Node* root,int node)
{
    if(!root)
    return false;

    Node* curr=root;
    while(curr!=NULL)
    {
        if(curr->data==node)
        return true;

        if(node < curr->data)
        {
            curr=curr->left;
        }
        else
        {
            curr=curr->right;
        }
    }
    return false;
}

void inorder(Node* root,vector<int> &a)
{
    if(!root)
    return;

    inorder(root->left,a);
    a.push_back(root->data);
    inorder(root->right,a);
}

void insertInBst(Node* root,int newNode)
{
    if(!root)
    return;

    while(true)
    {
        if(newNode < root->data)
        {
            if(root->left!=NULL)
            {
                root=root->left;
            }
            else
            {
                root->left=new Node(newNode);break;
            }
        }
        else
        {
            if(root->right!=NULL)
            {
                root=root->right;
            }
            else
            {
                root->right=new Node(newNode);break;
            }
        }
    }
}

Node* help(Node* root)
{
    if(root->right==NULL)
    return root;

    return help(root->right);
}

Node* helper(Node* root)
{
    if(!root)
    return NULL;

    Node* rightRoot=root->right;
    Node* rightMost=help(root->left);
    rightMost->right=rightRoot;

    return root->left;
}

Node* deleteInBst(Node* root,int delNode)
{
    if(!root)
    return NULL;

    Node* d=root;

    while(root!=NULL)
    {
        if(delNode < root->data)
        {
            if(root->left!=NULL && root->left->data==delNode)
            {
                root->left=helper(root->left);
            }
            else
            {
                root=root->left;
            }
        }
        else
        {
            if(root->right!=NULL && root->right->data==delNode)
            {
                root->right=helper(root->right);
            }
            else
            {
                root=root->right;
            }
        }
    }


    return d;
}

void rootToLeaf(Node* root,vector<vector<int>>&ans,vector<int> &ds)
{
    if(!root)
    return;

    ds.push_back(root->data);

    if(root->left==NULL && root->right==NULL)
        ans.push_back(ds);

    rootToLeaf(root->left,ans,ds);
    rootToLeaf(root->right,ans,ds);

    ds.pop_back();
}

bool rootToNode(Node* root,vector<int> &ds,int node)
{
    if(!root)
    return false;

    ds.push_back(root->data);

    if(root->data==node)
        return true;

    if(rootToNode(root->left,ds,node) || rootToNode(root->right,ds,node))
        return true;

    ds.pop_back();
    return false;
}

int main()
{
    Node* root = new Node(5);
    root->left = new Node(3);
    root->right = new Node(7);
    root->left->left = new Node(2);
    root->left->right = new Node(4);
    root->right->left = new Node(6);
    root->right->right = new Node(18);

    // cout<<checkBst(root,-1e9,1e9);
    // cout<<searchInBst(root,22);
    
    // vector<int>a;
    // insertInBst(root,15);
    // inorder(root,a);
    // for(auto i:a)
    // cout<<i<<" ";

    // Node* newRoot=deleteInBst(root,7);
    // vector<int>a;
    // inorder(newRoot,a);
    // for(auto i:a)
    // cout<<i<<" ";

    // vector<int>ds;
    // vector<vector<int>>ans;
    // rootToLeaf(root,ans,ds);
    // for(auto i:ans)
    // {
    //     for(auto j:i)
    //     {
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }

    vector<int>ds;
    bool res=rootToNode(root,ds,4);
    if(res)
    {
        for(auto i:ds)
        {
            cout<<i<<" ";
        }
    }
}