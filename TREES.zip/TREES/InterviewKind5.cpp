#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

vector<vector<int>> levelOrderZigZag(Node* root)
{
    vector<vector<int>>ans;
    if(!root)
    return ans;

    deque<Node*>dq;
    dq.push_back(root);
    bool l2r=true;

    while(!dq.empty())
    {
        int size=dq.size();
        vector<int>v;

        for(int i=0;i<size;i++)
        {
            if(l2r)
            {
                Node* n=dq.front();
                dq.pop_front();
                v.push_back(n->data);
                if(n->left)
                dq.push_back(n->left);
                if(n->right)
                dq.push_back(n->right);
            }
            else
            {
                Node* n=dq.back();
                dq.pop_back();
                v.push_back(n->data);
                if(n->left)
                dq.push_front(n->right);
                if(n->right)
                dq.push_front(n->left);
            }

        }

        ans.push_back(v);
        l2r=!l2r;
    }

    return ans;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    vector<vector<int>>ans=levelOrderZigZag(root);

    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
            cout<<endl;
    }
}