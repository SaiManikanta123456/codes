#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

void parent_child(Node* root,unordered_map<Node*,Node*> &mp)
{
    if(!root)
    return;

    queue<Node*>q;
    q.push(root);

    while(!q.empty())
    {
        Node* node=q.front();
        q.pop();

        if(node->left!=NULL)
        {
            q.push(node->left);
            mp[node->left]=node;
        }
        if(node->right!=NULL)
        {
            q.push(node->right);
            mp[node->right]=node;
        }
    }
}

int MinTimeToBurn(Node* root, Node* target)
{
    if(!root)
    return 0;

    unordered_map<Node*,Node*>mp;
    parent_child(root,mp);
    unordered_map<Node*,bool>visited;
    queue<Node*>q;
    q.push(target);
    visited[target]=true;
    int time=0;

    while(!q.empty())
    {
        int size=q.size();
        int f=0;
        for(int i=0;i<size;i++)
        {
            Node* node=q.front();
            q.pop();

            if(node->left!=NULL && !visited[node->left])
            {
                f=1;
                q.push(node->left);
                visited[node->left]=true;
            }
            if(node->right!=NULL && !visited[node->right])
            {
                f=1;
                q.push(node->right);
                visited[node->right]=true;
            }
            if(mp[node]!=NULL && !visited[mp[node]])
            {
                f=1;
                q.push(mp[node]);
                visited[mp[node]]=true;
            }
        }
        if(f!=0)
        time++;
    }
    return time;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    cout<<MinTimeToBurn(root,root->right->left);
}