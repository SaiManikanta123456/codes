#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

bool countSameValuedSubstrees(Node* root,int &c)
{
    if(!root)
    return true;

    bool left=countSameValuedSubstrees(root->left,c);
    bool right=countSameValuedSubstrees(root->right,c);

    if(!left || !right)return false;

    if(root->left && root->data!=root->left->data)return false;
    if(root->right && root->data!=root->right->data)return false;

    c++;
    return true;
}

int main()
{
    Node* root = new Node(5);
    root->left = new Node(5);
    root->right = new Node(5);
    root->left->left = new Node(5);
    root->left->right = new Node(5);
    root->right->right = new Node(5);
    root->right->left = new Node(5);

    int c=0;
    countSameValuedSubstrees(root,c);
    cout<<c;
}