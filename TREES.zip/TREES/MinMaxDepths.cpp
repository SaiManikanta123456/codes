#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

int maxDepth(Node* root,int &res)
{
    if(!root)
    return 0;

    queue<Node*>q;
    q.push(root);
    int level=0;
    while(!q.empty())
    {
        int size=q.size();
        level++;
        while(size--)
        {
            Node* node=q.front();
            q.pop();
            

            if(node->left==NULL && node->right==NULL)
            {
                res=level;
            }
            if(node->left)
            q.push(node->left);

            if(node->right)
            q.push(node->right);
        }
    }
    return level;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->left->right = new Node(18);
    root->left->left->right->left = new Node(31);
    root->left->left->right->left->left = new Node(25);

    int mini=0;
    cout<<maxDepth(root,mini)<<endl;
    // cout<<mini;
}

