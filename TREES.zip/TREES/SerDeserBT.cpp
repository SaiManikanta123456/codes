#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

string serialize(Node* root)
{
    string s="";
    if(!root)
    return s;

    queue<Node*>q;
    q.push(root);

    while(!q.empty())
    {
        Node* node=q.front();
        q.pop();

        if(node)
        {
            s=s+to_string(node->data)+",";
            q.push(node->left);
            q.push(node->right);
        }
        else
        {
            s=s+("N,");
        }
    }

    return s;
}

void levelOrder(Node* root)
{
    vector<int>a;
    vector<vector<int>>ans;
        if(!root)
        return;

        queue<Node*>q;
        q.push(root);

        while(!q.empty())
        {
            int size=q.size();
            vector<int>v;
            for(int i=0;i<size;i++)
            {
                Node* node=q.front();
                q.pop();
                if(node->left){
                q.push(node->left);
                }
                if(node->right)
                q.push(node->right);
                
                v.push_back(node->data);
            }

            ans.push_back(v);
        }
     
        for(auto i:ans)
        {
            for(auto j:i)
            {
                cout<<j<<" ";
            }
            cout<<endl;
        }
}

Node* deserialize(string s)
{
    if(s.length()==0)
    return nullptr;

    stringstream ss(s);
    string str;

    getline(ss,str,',');
    Node* root=new Node(stoi(str));
    queue<Node*>q;
    q.push(root);

    while(!q.empty())
    {
        Node* node=q.front();
        q.pop();

        if(getline(ss,str,','))
        {
            if(str!="N"){
            node->left=new Node(stoi(str));
            q.push(node->left);
            }
        }
        if(getline(ss,str,','))
        {
            if(str!="N"){
            node->right=new Node(stoi(str));
            q.push(node->right);
            }
        }
    }

    return root;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    // root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    string s=serialize(root);
    cout<<s<<endl;
    Node* tree=deserialize(s);
    levelOrder(tree);
}