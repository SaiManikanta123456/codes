#include <bits/stdc++.h>
using namespace std;

int decodeWaysHelper(int ind,string s,int n)
{
    if(ind==n)
    {
        return 1;
    }

    if(s[ind]=='0')
    {
        return 0;
    }

    int ways=decodeWaysHelper(ind+1,s,n);

    if(ind+1<n && (s[ind]-'0')*10 + s[ind+1]-'0' <=26 )
    ways=ways+decodeWaysHelper(ind+2,s,n);

    return ways;
}

void decodeWays(string s)
{
    int n=s.length();
    cout<<decodeWaysHelper(0,s,n);
}

int main()
{
    string s="123";
    decodeWays(s);
}