#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

void dfs(int src, int n, vector<int> adj[], vector<int> &d, vector<int> &vis)
{
    vis[src] = 1;
    d.push_back(src);
    for (auto i : adj[src])
    {
        if (!vis[i])
        {
            dfs(i, n, adj, d, vis);
        }
    }
}

void bfs(int src, int n, vector<int> adj[], vector<int> &b, vector<int> &vis)
{
    queue<int> q;
    q.push(src);
    vis[src] = 1;
    while (!q.empty())
    {
        int node = q.front();
        q.pop();
        b.push_back(node);
        for (auto i : adj[node])
        {
            if (!vis[i])
            {
                vis[i] = 1;
                q.push(i);
            }
        }
    }
}

void levelTraversal(Node *root)
{
    if (!root)
        return;

    vector<vector<int>> ans;

    queue<Node*> q;
    q.push(root);

    while (!q.empty())
    {
        int size = q.size();
        vector<int> v;

        for (int i = 0; i < size; i++)
        {
            Node *node = q.front();
            q.pop();
            // if(i==size-1)
            v.push_back(node->data);
            if (node->left)
            {
                q.push(node->left);
            }
            if (node->right)
            {
                q.push(node->right);
            }
        }

        ans.push_back(v);
    }

    for (auto i : ans)
    {
        for (auto j : i)
        {
            cout << j << " ";
        }
        cout << endl;
    }
}

bool isLeaf(Node* root)
{
    if(root->left==NULL && root->right==NULL)
    return true;

    return false;
}

void leftB(Node* node,vector<int> &res)
{
    if(!node)
    return;

    Node* cur=node->left;
    while(cur)
    {
        if(!isLeaf(cur))
        res.push_back(cur->data);
        
        if(cur->left!=NULL)
        cur=cur->left;
        else
        cur=cur->right;
    }
}

void leafB(Node* node,vector<int> &res)
{
    if(!node)
    return;

    if(isLeaf(node))
    {
        res.push_back(node->data);
    }
    leafB(node->left,res);
    leafB(node->right,res);
}

void rightB(Node* node,vector<int> &res)
{
    if(!node)
    return;
    stack<int>st;
    Node* cur=node->right;
    while(cur)
    {
        if(!isLeaf(cur))
        st.push(cur->data);
    
        
        if(cur->right!=NULL)
        cur=cur->right;
        else
        cur=cur->left;
    }

    while(!st.empty())
    {
        res.push_back(st.top());
        st.pop();
    }

}

void boundaryTraversal(Node* root,vector<int> &res)
{
    if(!root)
    return;

    leftB(root,res);
    leafB(root,res);
    rightB(root,res);
}

void topView(Node* root)
{
    if(!root)
    return;

    queue<pair<Node*,int>>q;
    q.push({root,0});
    map<int,int>mp;

    while(!q.empty())
    {
        Node* node=q.front().first;
        int line=q.front().second;
        q.pop();

        if(mp.find(line)==mp.end())
        {
            mp[line]=node->data;
        }

        if(node->left!=NULL)
        q.push({node->left,line-1});

        if(node->right!=NULL)
        q.push({node->right,line+1});
    }

    for(auto i:mp)
    cout<<i.second<<" ";
}

bool checkBst(Node* root,long long mini,long long maxi)
{
    if(!root)
    return true;

    if(root->data <= mini ||  root->data >= maxi)
        return false;

    return checkBst(root->left,mini,root->data) && checkBst(root->right,root->data,maxi);
}

int dfs1(int row,int col,vector<vector<int>>graph,vector<vector<int>> &vis,int n,int m)
{
    vis[row][col]=1;

    int dr[]={0,-1,0,1};
    int dc[]={-1,0,1,0};
    int c=1;
    for(int i=0;i<4;i++)
    {
        int nr=row+dr[i];
        int nc=col+dc[i];
        if(nr>=0 && nr<n && nc>=0 && nr<m && vis[nr][nc]==0 && graph[nr][nc]==1)
        {
            
            c=c+dfs1(nr,nc,graph,vis,n,m);
        }
    }
    return c;
}

void nodesAtKDistHelper(Node* root,unordered_map<Node*,Node*> &mpp)
{
    if(!root)
    return;

    queue<Node*>q;
    q.push(root);

    while(!q.empty())
    {
        Node* node=q.front();
        q.pop();

        if(node->left!=NULL)
        {
            q.push(node->left);
            mpp[node->left]=node;
        }
        if(node->right!=NULL)
        {
            q.push(node->right);
            mpp[node->right]=node;
        }
    }
}

void nodesAtKDist(Node* root,Node* target,int k,vector<int> &res)
{
    if(!root)
    return;

    unordered_map<Node*,Node*>mpp;
    nodesAtKDistHelper(root,mpp);
    unordered_map<Node*,bool>vis;
    queue<Node*>q;
    q.push(target);
    vis[target]=true;
    int level=0;
    while(!q.empty())
    {
        int size=q.size();
        // if(level==k)
        // break;
        int f=0;
      for(int i=0;i<size;i++)
        {  
            Node* node=q.front();
            q.pop();

            if(node->left!=NULL && !vis[node->left])
            {
                f=1;
                q.push(node->left);
                vis[node->left]=true;
            }
            if(node->right!=NULL && !vis[node->right])
            {
                f=1;
                q.push(node->right);
                vis[node->right]=true;
            }
            if(mpp[node] && !vis[mpp[node]])
            {
                f=1;
                q.push(mpp[node]);
                vis[mpp[node]]=true;
            }
        }
        if(f==1)
            level++;
    }

    while(!q.empty())
    {
        res.push_back(q.front()->data);
        q.pop();
    }
    cout<<level<<endl;   
}

int main()
{
    // int n=5;
    // vector<vector<int>>a{
    //     {0,1},{0,2},{1,2},{2,3},{3,4}
    // };
    // vector<int>adj[n];
    // for(int i=0;i<n;i++)
    // {
    //     int n=a[i][0];
    //     int m=a[i][1];
    //     adj[n].push_back(m);
    //     adj[m].push_back(n);
    // }

    // vector<int>d;
    // vector<int>vis(n,0);
    // dfs(0,n,adj,d,vis);
    // for(auto i:d)
    // cout<<i<<" ";

    // vector<int>b;
    // vector<int>vis(n,0);
    // bfs(0,n,adj,b,vis);
    // for(auto i:b)
    // cout<<i<<" ";

    Node *root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    Node* target=root->right;
    int k=1;
    vector<int>res;
    nodesAtKDist(root,target,k,res);
    for(auto i:res)
    cout<<i<<" ";

    // levelTraversal(root);

    //Boundary Traversal
    // vector<int>ans;
    // ans.push_back(root->data);
    // boundaryTraversal(root,ans);
    // for(auto i:ans)
    // cout<<i<<" ";

    // topView(root);

    // cout<<checkBst(root,-1e9,1e9);

    // vector<vector<int>>graph{
    //     {1,1,0,0,0},
    //     {1,0,0,0,1},
    //     {1,0,1,1,1},
    //     {1,1,0,0,1},
    //     {0,0,0,0,1}
    // };

    // int c=0;
    // int n=graph.size();
    // int m=graph[0].size();

    // vector<vector<int>>vis(n,vector<int>(m,0));
    // for(int i=0;i<n;i++)
    // {
    //     for(int j=0;j<m;j++)
    //     {
    //         if(vis[i][j]==0 && graph[i][j]==1)
    //         {
                
    //             int k=dfs1(i,j,graph,vis,n,m);
    //             c=max(c,k);
    //         }
    //     }
    // }

    // cout<<c;
}