#include <bits/stdc++.h>
using namespace std;

double getRatio(string start,string end,vector<pair<string,pair<string,double>>> &data)
{
    map<string,map<string,double>>mp;
    for(auto i:data)
    {
        mp[i.first][i.second.first]=i.second.second;
        mp[i.second.first][i.first]=1.0/i.second.second;
    }

    queue<string>q;
    queue<double>val;
    unordered_set<string>vis;
    q.push(start);
    val.push(1.0);
    while(!q.empty())
    {
        string cur=q.front();
        q.pop();
        double value=val.front();
        val.pop();

        if(vis.count(cur))continue;

        vis.insert(cur);

        if(mp.count(cur))
        {
            for(auto i:mp[cur])
            {
                if(!vis.count(i.first))
                {
                    if(i.first==end)
                    {
                        return value*i.second;
                    }
                    q.push(i.first);
                    val.push(i.second*value);
                }
            }
        }
    }
    return -1;
}

void dfs(string source,string dest,unordered_map<string, vector<pair<string, double>>> &adj,double val,double &ans,unordered_set<string> &visited)
{
    if(visited.count(source)) return;
    visited.insert(source);
    if(source==dest)
    {
        ans=val;
        return;
    }

    for(auto neigh:adj[source])
    {
        string neighNode=neigh.first;
        double v=neigh.second;

        dfs(neighNode,dest,adj,val*v,ans,visited);
    }
}

int main()
{
    unordered_map<string, vector<pair<string, double>>> adj;

    adj["usd"].push_back({"jpy", 110});
    adj["usd"].push_back({"aud", 1.45});
    adj["jpy"].push_back({"gbp", 0.0070});
    adj["jpy"].push_back({"usd", 1.0 / 110});
    adj["aud"].push_back({"usd", 1.0 / 1.45});
    adj["gbp"].push_back({"jpy", 1.0 / 0.0070});

    // cout<<getRatio("gbp","aud",data);
    double val=1.0,ans=0.0;
    unordered_set<string>visited;
    dfs("gbp","aud",adj,val,ans,visited);
    cout<<ans;
}