#include<bits/stdc++.h>
using namespace std;

void bruteHelper(vector<int> &a,int n,vector<int> &ds,vector<vector<int>> &res,vector<int> &freq)
{
    if(ds.size()==n)
    {
        res.push_back(ds);
        return;
    }

    for(int i=0;i<n;i++)
    {
        if(!freq[i])
        {
            freq[i]=1;
            ds.push_back(a[i]);
            bruteHelper(a,n,ds,res,freq);
            ds.pop_back();
            freq[i]=0;
        }
    }
}

vector<int> brute(vector<int> &a,int n)
{
    vector<int>ds;
    vector<vector<int>>res;
    vector<int>freq(n,0);
    bruteHelper(a,n,ds,res,freq);
    sort(res.begin(),res.end());
    for(int i=0;i<res.size();i++)
    {
        if(res[i]==a)
        return res[i+1];
    }
    return {};
}


void optimal(vector<int> &a,int n)
{
    int ind=-1;
    for(int i=n-2;i>=0;i--)
    {
        if(a[i]<a[i+1])
        {
            ind=i;
            break;
        }
    }
    if(ind==-1)
    {
        reverse(a.begin(),a.end());
    }
    for(int i=n-1;i>=0;i--)
    {
        if(a[ind]<a[i])
        {
            swap(a[ind],a[i]);
            break;
        }
    }
    reverse(a.begin()+ind+1,a.end());
}

int main()
{
    vector<int>a{2,4,1,7,5,0};
    // vector<int>ans=brute(a,a.size());
    optimal(a,a.size());
    for(auto i:a)
    cout<<i<<" ";
}