#include <bits/stdc++.h>
using namespace std;

class StackUsingQueues
{
    public:

    queue<int>q1,q2;

    void push(int x)
    {
        q2.push(x);

        while(!q1.empty())
        {
            q2.push(q1.front());
            q1.pop();
        }

        swap(q1,q2);
    }

    void pop()
    {
        if(!q1.empty())
        {
            cout<<q1.front()<<endl;
            q1.pop();
        }
    }

    int peek()
    {
        if(!q1.empty())
        {
            return q1.front();
        }
        return -1;
    }

    bool isEmpty()
    {
        return q1.empty();
    }
};
int main()
{
    StackUsingQueues sq;
    sq.push(1);
    sq.push(2);
    sq.push(3);

    cout<<sq.peek()<<endl;

    sq.pop();
}