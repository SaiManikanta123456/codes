#include <bits/stdc++.h>
using namespace std;

int dfs(int row,int col,vector<vector<int>>graph,vector<vector<int>>&vis,int n,int m,int index)
{
    vis[row][col]=index;
    int dx[]={0,-1,0,1};
    int dy[]={-1,0,1,0};
    int c=1;
    for(int i=0;i<4;i++)
    {
        int nr=row+dx[i];
        int nc=col+dy[i];

        if(nr>=0 && nr<n && nc>=0 && nc<m && vis[nr][nc]==0 && graph[nr][nc]==1)
        {
            c=c+dfs(nr,nc,graph,vis,n,m,index);
        }
    }
    return c;
}

int main()
{
    vector<vector<int>>graph{
        {1,1,1,0,0},
        {0,0,0,1,1},
        {0,0,0,1,1},
        {1,1,0,0,0}
    };

    int n=graph.size();
    int m=graph[0].size();
    vector<vector<int>>vis(n,vector<int>(m,0));

    unordered_map<int,int>mp;
    int index=2;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(graph[i][j]==1 && !vis[i][j])
            {
                mp[index]=dfs(i,j,graph,vis,n,m,index);
                index++;
            }
        }
    }

    int maxIsland=0;
    for(auto i:mp)
    maxIsland=max(maxIsland,i.second);

    cout<<maxIsland<<endl;

    int dx[]={0,-1,0,1};
    int dy[]={-1,0,1,0};

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(graph[i][j]==0)
            {
                unordered_set<int>set;
                int total=1;

                for(int k=0;k<4;k++)
                {
                    int nr=i+dx[k];
                    int nc=j+dy[k];

                    if(nr>=0 && nr<n && nc>=0 && nc<m && vis[nr][nc]>0)
                    {
                        int nid=vis[nr][nc];
                        if(set.find(nid)==set.end())
                        {
                            set.insert(nid);
                            total=total+mp[nid];
                        }
                    }
                }

                maxIsland=max(maxIsland,total);
            }
        }
    }

    cout<<maxIsland;

    // for(int i=0;i<n;i++)
    // {
    //     for(int j=0;j<m;j++)
    //     {
    //         cout<<vis[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }
}