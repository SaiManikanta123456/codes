#include <bits/stdc++.h>
using namespace std;

void dfs(int node, int vis[], stack<int> &st, vector<int> adjList[],vector<int> &ans)
{
    vis[node] = 1;
    ans.push_back(node);

    for (auto i : adjList[node])
    {
        if (!vis[i])
        {
            dfs(i, vis, st, adjList,ans);
        }
    }

    st.push(node);
}

int main()
{
    int V = 6;
    vector<int> adjList[V + 1];
    vector<vector<int>> graph{
        {1, 2}, {2, 4}, {4, 3}, {4, 5}, {5, 6}, {4, 6}
    };

    for (int i = 0; i < graph.size(); i++)
    {
        int m = graph[i][0];
        int n = graph[i][1];
        adjList[m].push_back(n);
    }

    cout << "Adjacency List:\n";
    for (int i = 1; i <= V; i++)
    {
        cout << i << " ---> ";
        for (auto j : adjList[i])
        {
            cout << j << " ";
        }
        cout << endl;
    }

    // vector<int>inorder(V+1);
    // for(int i=1;i<=V;i++)
    // {
    //     for(auto it:adjList[i])
    //     {
    //         inorder[it]++;
    //     }
    // }
    // queue<int>q;
    // for(int i=1;i<inorder.size();i++)
    // {
    //     if(inorder[i]==0)
    //     {
    //         q.push(i);
    //     }
    // }
    // vector<int> topo;
    // while(!q.empty())
    // {
    //     int node=q.front();
    //     q.pop();
    //     topo.push_back(node);
    //     for(auto i:adjList[node])
    //     {
    //         inorder[i]--;
    //         if(inorder[i]==0)
    //         q.push(i);
    //     }
    // }

    // for(auto i:topo)
    // cout<<i<<" ";


    vector<int> topo;
    stack<int> st;
    vector<int>ans;
    int vis[V + 1] = {0};

    for (int i = 1; i <= V; i++)
    {
        if (!vis[i])
            dfs(i, vis, st, adjList,ans); // run DFS from unvisited nodes
    }

    // cout << "\nTopological Sort:\n";
    // while (!st.empty())
    // {
    //     cout << st.top() << " ";
    //     st.pop();
    // }
    // cout << endl;

     for(auto i:ans)
    cout<<i<<" ";
}
