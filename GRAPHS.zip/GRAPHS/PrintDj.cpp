#include <bits/stdc++.h>
using namespace std;

int main()
{
    int V = 5, E = 6;
    vector<vector<int>> edges = {{1, 2, 2}, {2, 5, 5}, {2, 3, 4}, {1, 4, 1}, {4, 3, 3}, {3, 5, 1}};

    vector<pair<int,int>>adj[V+1];
    for(auto i:edges)
    {
        adj[i[0]].push_back({i[1],i[2]});
        adj[i[1]].push_back({i[0],i[2]});
    }

    vector<int>dist(V+1,1e9),parent(V+1);
    dist[1]=0;
    for (int i = 1; i <= V; i++)
        parent[i] = i;
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
    pq.push({0,1});

    while(!pq.empty())
    {
        int distance=pq.top().first;
        int node=pq.top().second;
        pq.pop();

        for(auto i:adj[node])
        {
            int neigh=i.first;
            int neighdist=i.second;

            if(dist[neigh] > distance+neighdist)
            {
                dist[neigh] = distance+neighdist;
                pq.push({dist[neigh],neigh});

                parent[neigh]=node;
            }
        }
    }

    vector<int> path;
    int node = V;
    while (parent[node] != node)
    {
        path.push_back(node);
        node = parent[node];
    }
    path.push_back(1);

    reverse(path.begin(), path.end());

    for(auto i:path)
    cout<<i<<" ";
}