#include<bits/stdc++.h>
using namespace std;

void bfs(vector<vector<int>> &graph)
{
    int n=graph.size();

    int maxNode = 0;
    for (auto &edge : graph)
        maxNode = max(maxNode, max(edge[0], edge[1]));

    vector<vector<int>> adj(maxNode + 1);

    for(int i=0;i<n;i++)
    {
        adj[graph[i][0]].push_back(graph[i][1]);
        adj[graph[i][1]].push_back(graph[i][0]);
    }

    for(int i=0;i<n;i++)
    {
        cout<<i<<"--->";
        for(auto j:adj[i])
        cout<<j<<" ";
        cout<<endl;
    }

    vector<int>res;
    int root=1;
    vector<bool>vis(n,false);
    vis[root]=true;
    queue<int>q;
    q.push(root);


    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        res.push_back(node);

        for(auto i:adj[node])
        {
            if(!vis[i])
            {
                vis[i]=true;
                q.push(i);
            }
        }
    }

    for(auto i:res)
    cout<<i<<" ";
}

void dfsHelper(int root,vector<int> &res,vector<bool> &vis,vector<vector<int>> &adj)
{
    vis[root]=true;
    res.push_back(root);

    for(auto i:adj[root])
    {
        if(!vis[i])
        dfsHelper(i,res,vis,adj);
    }
}

void dfs(vector<vector<int>> &graph)
{
    int n=graph.size();

    int maxNode = 0;
    for (auto &edge : graph)
        maxNode = max(maxNode, max(edge[0], edge[1]));

    vector<vector<int>> adj(maxNode + 1);

    for(int i=0;i<n;i++)
    {
        adj[graph[i][0]].push_back(graph[i][1]);
        adj[graph[i][1]].push_back(graph[i][0]);
    }

    for(int i=0;i<n;i++)
    {
        cout<<i<<"--->";
        for(auto j:adj[i])
        cout<<j<<" ";
        cout<<endl;
    }

    vector<int>res;
    int root=1;
    vector<bool>vis(n,false);
    dfsHelper(root,res,vis,adj);
    for(auto i:res)
    cout<<i<<" ";
}

int main()
{
    vector<vector<int>>graph{
       {0,1},{0,2},{1,3},{1,4},{2,5}
    };

    // bfs(graph);
    dfs(graph);
}