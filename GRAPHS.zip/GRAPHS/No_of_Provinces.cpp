#include<bits/stdc++.h>
using namespace std;

void dfs(int root,vector<bool> &vis,vector<int> adj[])
{
    vis[root]=true;

    for(auto i:adj[root])
    {
        if(!vis[i])
        dfs(i,vis,adj);
    }
}

int main()
{
    vector<vector<int>>graph{
        {1,1,0,0,0},
        {1,1,1,0,0},
        {0,1,1,0,0},
        {0,0,0,1,0},
        {0,0,0,0,1}
    };

    vector<int> adj[graph.size()];

    int n=graph.size();

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(graph[i][j]==1 && i!=j)
            {
                adj[i].push_back(j);
            }
        }
    }

    for(int i=0;i<n;i++)
    {
        cout<<i<<"--->";
        for(auto j:adj[i])
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }

    vector<bool>vis{0};
    int c=0;
    for(int i=0;i<n;i++)
    {
        if(!vis[i])
        {
            c++;
            dfs(i,vis,adj);
        }
    }

    cout<<c;
}