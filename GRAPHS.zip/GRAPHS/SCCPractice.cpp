#include <bits/stdc++.h>
using namespace std;
void dfs(int node,vector<bool> &vis,stack<int> &st,vector<int> adj[])
{
    vis[node]=true;

    for(auto i:adj[node])
    {
        if(!vis[i])
        {
            dfs(i,vis,st,adj);
        }
    }
    st.push(node);
}

void dfs1(int node,vector<bool> &vis1,vector<int> adjT[],vector<int> &temp)
{
    vis1[node]=true;
    temp.push_back(node);
    for(auto i:adjT[node])
    {
        if(!vis1[i])
        {
            dfs1(i,vis1,adjT);
        }
    }
}
int main()
{
    vector<vector<int>> edges{
        {0,2},{1,0},{2,1},{0,3},{3,4}
    };

    // Step 1: Build adjacency list
    int maxNode = 0;
    for (auto &e : edges) {
        maxNode = max({maxNode, e[0], e[1]});
    }
    int v = maxNode + 1;
    vector<int> adj[v];
    for (auto e : edges) {
        adj[e[0]].push_back(e[1]);
    }

    stack<int>st;
    vector<bool>vis(v,false);

    for(int i=0;i<v;i++)
    {
        if(!vis[i])
        {
            dfs(i,vis,st,adj);
        }
    }

    vector<int> adjT[v];
    vector<bool>vis1(v+1,false);
    for(int i=0;i<v;i++)
    {
        for(auto it:adj[i])
        {
            adjT[it].push_back(i);
        }
    }
    int scc=0;
    vector<vector<int>>ans;
    vector<int>temp;
    while(!st.empty())
    {
        int node=st.top();
        st.pop();
        if(!vis1[node])
        {
            scc++;
            dfs1(node,vis1,adjT,temp);
        }
    }

    cout<<scc;
}