#include <bits/stdc++.h>
using namespace std;

// Check if two primes differ by exactly one digit
bool distByOne(int n1, int n2)
{
    string s1 = to_string(n1);
    string s2 = to_string(n2);

    int c = 0;
    for (int i = 0; i < 4; i++)
        if (s1[i] == s2[i])
            c++;

    return c == 3; // exactly one digit different
}

// Sieve to generate all 4-digit primes
void seive(vector<int> &primes)
{
    int n = 9999;
    vector<bool> prim(n + 1, true);

    prim[0] = prim[1] = false;

    for (int i = 2; i * i <= n; i++)
    {
        if (prim[i])
        {
            for (int j = i * i; j <= n; j += i)
            {
                prim[j] = false;
            }
        }
    }

    for (int p = 1000; p <= n; p++)
        if (prim[p])
            primes.push_back(p);
}

// BFS to find shortest transformation steps
int stepsReq(vector<vector<int>> &graph, int startPrime, int endPrime, vector<int> &primes)
{
    int n = primes.size();
    vector<int> dist(n, -1); // distance array

    // Map prime -> index in primes list
    unordered_map<int, int> primeIndex;
    for (int i = 0; i < n; i++)
        primeIndex[primes[i]] = i;

    // BFS
    queue<int> q;
    q.push(primeIndex[startPrime]);
    dist[primeIndex[startPrime]] = 0;

    while (!q.empty())
    {
        int node = q.front();
        q.pop();

        if (primes[node] == endPrime)
            return dist[node];

        for (auto neigh : graph[node])
        {
            if (dist[neigh] == -1)
            {
                dist[neigh] = dist[node] + 1;
                q.push(neigh);
            }
        }
    }

    return -1; // no transformation possible
}

int main()
{
    int n1 = 1033, n2 = 8179;
    vector<int> primes;
    seive(primes);

    int N = primes.size();
    vector<vector<int>> graph(N);

    // Build adjacency list
    for (int i = 0; i < N; i++)
    {
        for (int j = i + 1; j < N; j++)
        {
            if (distByOne(primes[i], primes[j]))
            {
                graph[i].push_back(j);
                graph[j].push_back(i);
            }
        }
    }

    int steps = stepsReq(graph, n1, n2, primes);

    if (steps != -1)
        cout << "Minimum steps: " << steps << endl;
    else
        cout << "No transformation possible" << endl;
}
