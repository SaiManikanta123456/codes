#include <bits/stdc++.h>
using namespace std;

int main()
{
    int V = 5, E = 6;
    vector<vector<int>> edges = {{1, 2, 2}, {2, 5, 5}, {2, 3, 4}, {1, 4, 1}, {4, 3, 3}, {3, 5, 1}};

    vector<pair<int,int>>adj[V+1];
    for(auto i:edges)
    {
        adj[i[0]].push_back({i[1],i[2]});
        adj[i[1]].push_back({i[0],i[2]});
    }

    vector<int>dist(V+1,1e9);
    dist[1]=0;
    priority_queue<pair<int,pair<int,int>> , vector<pair<int,pair<int,int>>> , greater<pair<int,pair<int,int>>> >pq;
    pq.push({0,{1,-1}});
    while(!pq.empty())
    {
        int wt=pq.top().first;
        int sourceNode=pq.top().second.first;
        int parentNode=pq.top().second.second;
        pq.pop();
        

        for(auto i:adj[sourceNode])
        {
            int neigh=i.first;
            int neighWt=i.second;

            if(dist[neigh]>neighWt+wt)
            {
                pq.push({neighWt+wt ,{neigh,sourceNode}});
                dist[neigh]=neighWt+wt;
            }
        }
    }

    for(auto i:dist)
    cout<<i<<" ";
}