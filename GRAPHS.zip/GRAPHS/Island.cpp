#include <bits/stdc++.h>
using namespace std;

class DisJoint{
    public:
    vector<int>parent,size;
    DisJoint(int n)
    {
        parent.resize(n+1);
        size.resize(n+1,1);
        for(int i=0;i<=n;i++)
        {
            parent[i]=i;
        }
    }

    int findUP(int node)
    {
        if(parent[node]==node)
        return node;

        return parent[node]=findUP(parent[node]);
    }

    void unionBySize(int u,int v)
    {
        int upu=findUP(u);
        int upv=findUP(v);
        if(upu == upv) return;
        if(size[upu]<size[upv])
        {
            parent[upu]=upv;
            size[upv]=size[upu]+size[upv];
        }
        else
        {
            parent[upv]=upu;
            size[upu]=size[upu]+size[upv];
        }
    }
};

void dfs(int row,int col,vector<vector<int>> &graph,vector<vector<int>> &vis,int n,int m,int row0,int col0,vector<pair<int,int>> &vec)
{
    vis[row][col]=1;
    vec.push_back({row-row0,col-col0});
    int dr[]={0,-1,0,1};
    int dc[]={-1,0,1,0};
    for(int i=0;i<4;i++)
    {
        int nrow=row+dr[i];
        int ncol=col+dc[i];

        if(nrow>=0 && nrow<n && ncol>=0 && ncol<m && graph[nrow][ncol]==1 && !vis[nrow][ncol])
        {
            dfs(nrow,ncol,graph,vis,n,m,row0,col0,vec);
        }
    }
}
void distinctIslands(vector<vector<int>> &graph,int n,int m)
{
    vector<vector<int>>vis(n,vector<int>(m,0));
    set<vector<pair<int,int>>>st;
    for(int row=0;row<n;row++)
    {
        for(int col=0;col<m;col++)
        {
            if(!vis[row][col] && graph[row][col]==1)
            {
                vector<pair<int,int>>vec;
                dfs(row,col,graph,vis,n,m,row,col,vec);
                st.insert(vec);
            }
        }
    }
    cout<<"Distinct Islands ::"<<st.size()<<endl;
}

int main()
{
    
    vector<vector<int>>graph{
        {1,1,1,0,0},
        {0,0,0,1,1},
        {0,0,0,1,1},
        {1,1,0,0,0}
    };

    int n=graph.size();
    int m=graph[0].size();
    distinctIslands(graph,n,m);
    DisJoint ds(n*m);
    int dr[]={0,-1,0,1};
    int dc[]={-1,0,1,0};
    for(int row=0;row<n;row++)
    {
        for(int col=0;col<m;col++)
        {
            if(graph[row][col]==0)continue;
            for(int i=0;i<4;i++)
            {
                int nrow=row+dr[i];
                int ncol=col+dc[i];

                if(nrow>=0 && nrow<n && ncol>=0 && ncol<m && graph[nrow][ncol]==1)
                {
                    int node=(row*m)+col;
                    int adjNode=(nrow*m)+ncol;
                    ds.unionBySize(node,adjNode);
                }
            }
        }
    }

    vector<int>sizes;
    for(int row=0;row<n;row++)
    {
        for(int col=0;col<m;col++)
        {
            if(graph[row][col]==1)
            {
                int node=(row*m)+col;
                if(ds.findUP(node)==node)
                sizes.push_back(ds.size[node]);
            }
        }
    }
    cout<<sizes.size()<<endl;
    for(auto i:sizes)
    cout<<i<<" ";
    cout<<endl;

    int maxi=0;
    
    for(int row=0;row<n;row++)
    {
        for(int col=0;col<m;col++)
        {
            if(graph[row][col]==1)continue;
            unordered_set<int>set;
            for(int i=0;i<4;i++)
            {
                int nrow=row+dr[i];
                int ncol=col+dc[i];

                if(nrow>=0 && nrow<n && ncol>=0 && ncol<m && graph[nrow][ncol]==1)
                {
                    set.insert(ds.findUP((nrow*m)+ncol));
                }
            }
            int totalSize=0;
            for(auto i:set)
            {
                totalSize=totalSize+ds.size[i];
            }

            maxi=max(maxi,totalSize+1);
        }
    }

    cout<<maxi;

}