#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<vector<int>>graph{
        {1,2,2},{2,5,5},{2,3,4},{1,4,1},{4,3,3},{3,5,1}
    };
    int V=5;
    vector<pair<int,int>>edgeList[V+1];

    for(auto i:graph)
    {
        int u=i[0];
        int v=i[1];
        int w=i[2];
            
        edgeList[u].push_back({v,w});
        edgeList[v].push_back({u,w});
    }

    // for(int i=0;i<=V;i++)
    // {
    //     cout<<i<<"--->";
    //     for(auto j:edgeList[i])
    //     {
    //         cout<<j.first<<".....> "<<j.second<<" ";
    //     }
    //     cout<<endl;
    // }

    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
    pq.push({0,1});
    vector<int>distance(V+1,1e9);
    distance[1]=0;
    vector<int>parent(V+1,0);
    for(int i=1;i<=V;i++)
    {
        parent[i]=i;
    }

    while(!pq.empty())
    {
        int edjNode=pq.top().second;
        int edjW=pq.top().first;
        pq.pop();

        for(auto i:edgeList[edjNode])
        {
            int weight=i.second;
            int neigh=i.first;

            if(weight+edjW < distance[neigh])
            {
                distance[neigh]=weight+edjW;
                pq.push({weight+edjW,neigh});
                parent[neigh]=edjNode;
            }
        }
    }

    // for(auto i:parent)
    // cout<<i<<" ";
    if(distance[V]==1e9)
    {
        cout<<"Error";
        exit(0);
    }
    int node=V;
    while(parent[node]!=node)
    {
        cout<<parent[node]<<" ";
        node=parent[node];
    }
    cout<<1;
}