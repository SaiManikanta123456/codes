#include <bits/stdc++.h>
using namespace std;

bool dfs(int node,vector<int>adj[],vector<int> &vis,vector<int> &pathVis,vector<int> &safeNode)
{
    vis[node]=1;
    pathVis[node]=1;
    safeNode[node]=0;

    for(auto i:adj[node])
    {
        if(!vis[i])
        {
            if(dfs(i,adj,vis,pathVis,safeNode))
            return true;
        }
        else if(pathVis[i])
        {
            return true;
        }
    }

    pathVis[node]=0;
    safeNode[node]=1;
    return false;
}

int main()
{
    vector<vector<int>> graph{{0,2},{2,1},{1,0},{3,1},{2,4}};
    int V=5;
    vector<int>adj[V];
    for(auto i:graph)
    {
        adj[i[0]].push_back(i[1]);
    }
    vector<int>vis(V,0);
    vector<int>pathVis(V,0);
    vector<int>safeNode(V,0); //Eventual Safe States
    for(int i=0;i<V;i++)
    {
        if(!vis[i])
        {
            if(dfs(i,adj,vis,pathVis,safeNode)){
            cout<<"Cycle";
            }
        }
    }
    for(int i=0;i<V;i++)
    {
        if(safeNode[i])
        cout<<i<<" ";
    }
}