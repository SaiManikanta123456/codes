#include <bits/stdc++.h>
using namespace std;

void dfs1(int node, stack<int> &st, vector<int> &vis, vector<int> adj[]) {
    vis[node] = 1;
    for (auto i : adj[node]) {
        if (!vis[i]) {
            dfs1(i, st, vis, adj);
        }
    }
    st.push(node);
}

void dfs2(int node, vector<int> &vis, vector<int> adj[]) {
    vis[node] = 1;
    for (auto i : adj[node]) {
        if (!vis[i]) {
            dfs2(i, vis, adj);
        }
    }
}

int main() {
    vector<vector<int>> edges{
        {0,2},{1,0},{2,1},{0,3},{3,4}
    };

    // Step 1: Build adjacency list
    int maxNode = 0;
    for (auto &e : edges) {
        maxNode = max({maxNode, e[0], e[1]});
    }
    int v = maxNode + 1;
    vector<int> adj[v];
    for (auto e : edges) {
        adj[e[0]].push_back(e[1]);
    }

    // Step 2: First DFS (Topo order)
    vector<int> vis(v, 0);
    stack<int> st;
    for (int i = 0; i < v; i++) {
        if (!vis[i]) {
            dfs1(i, st, vis, adj);
        }
    }

    // Step 3: Transpose graph
    vector<int> adjT[v];
    for (int i = 0; i < v; i++) {
        for (auto it : adj[i]) {
            adjT[it].push_back(i);
        }
    }

    // Step 4: Second DFS on transposed graph
    int sccCount = 0;
    vector<int> vis1(v, 0);
    while (!st.empty()) {
        int node = st.top();
        st.pop();
        if (!vis1[node]) {
            sccCount++;
            dfs2(node, vis1, adjT);
        }
    }

    cout << "Number of Strongly Connected Components: " << sccCount << endl;
}
