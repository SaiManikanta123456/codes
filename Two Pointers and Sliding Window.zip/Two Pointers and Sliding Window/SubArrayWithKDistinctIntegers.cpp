#include <bits/stdc++.h>
using namespace std;

int optimal(vector<int> &a,int k)
{
    int r=0;
    int l=0;
    int c=0;
    unordered_map<int,int>mp;

    while(r<a.size())
    {
        

        while(mp.size()>k)
        {
            mp[a[l]]--;
            if(mp[a[l]]==0)
            mp.erase(mp[l]);
            l=l+1;
        }
        if(mp.size()<=k)
        {
            c=max(c,r-l+1);
        }
        mp[a[r]]++;
        r++;
    }
    return c;
}

int main()
{
    vector<int>a{2,1,1,1,3,4,3,2};
    int k=3;
    cout<<optimal(a,k)-optimal(a,k-1);
}