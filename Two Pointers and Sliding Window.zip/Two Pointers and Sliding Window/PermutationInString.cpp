#include<bits/stdc++.h>
using namespace std;

bool PermString()
{
    string s1="abm";
    string s2="saibamani";

    vector<int>s1Hash(26,0);
    vector<int>s2Hash(26,0);

    int right=0;
    int left=0;
    while(right<s1.length())
    {
        s1Hash[s1[right]-'a']++;
        s2Hash[s2[right]-'a']++;
        right++;
    }
    right=right-1;
    while(right<s2.length())
    {
        if(s1Hash==s2Hash)
        return true;
        
        right++;
        s2Hash[s2[right]-'a']++;
        s2Hash[s2[left]-'a']--;
        left++;
    }
    return false;
} 

int main()
{
    cout<<PermString();
}