#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s="abcdefgha"; //cadbzabcd
    int l=0;
    int r=0;
    int maxLen=0;
    int hash[256]={-1};
    while(r<s.length())
    {
        if(hash[s[r]]!=-1)
        {
            if(hash[s[r]]>=l)
            {
                l=hash[s[r]]+1;
            }
        }
        int len=r-l+1;
        maxLen=max(maxLen,len);

        hash[s[r]]=r;
        r++;
    }
    cout<<maxLen;
}