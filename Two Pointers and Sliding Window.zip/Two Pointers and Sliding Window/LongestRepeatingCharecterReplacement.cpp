#include <bits/stdc++.h>
using namespace std;

int brute(string s,int k)
{
    int maxLen=0;
    int l=0,r=0;
    
    for(int i=0;i<s.length();i++)
    {
        int hash[26]={0};
        int maxF=0;
        for(int j=i;j<s.length();j++)
        {
            hash[s[j]-'A']++;

            for(int i=0;i<25;i++)
            {
                maxF=max(maxF,hash[i]);
            }

            int changes=(j-i+1)-maxF;

            if(changes<=k)
            {
                maxLen=max(maxLen,j-i+1);
            }
            else
            {
                break;
            }
        }
    }

    return maxLen;
}

int optimal(string s,int k)
{
    int maxLen=0;
    int r=0,l=0,maxF=0;
    int hash[26]={0};
    while(r<s.length())
    {
        hash[s[r]-'A']++;
        maxF=max(maxF,hash[s[r]-'A']);
        while((r-l+1)-maxF > k)
        {
            hash[s[l]-'A']--;
            l++;
        }
        if((r-l+1)-maxF <= k)
        {
            maxLen=max(maxLen,r-l+1);
        }
        r++;
    }
    return maxLen;
}
int main()
{
    string s="AAABBCCD";
    // cout<<brute(s,2);
    cout<<optimal(s,2);

}