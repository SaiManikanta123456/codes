#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<int>a{1,1,1,1,0,-1,-1};

    int widowSize=4;
    int maxSum=0;
    int lsum=0;
    int rsum=0;
    for(int i=0;i<widowSize;i++)
    {
        lsum=lsum+a[i];
    }
    maxSum=lsum;
    int righIndex=a.size()-1;
    for(int i=widowSize-1;i>=0;i--)
    {
        lsum=lsum-a[i];
        rsum=rsum+a[righIndex];
        righIndex--;
        maxSum=max(maxSum,lsum+rsum);
    }

    cout<<maxSum;
}