#include<bits/stdc++.h>
using namespace std;

void brute(string s)
{
    unordered_map<int,int>mp;
    int maxLen=0;
    for(int i=0;i<s.length();i++)
    {
        mp.clear();
        for(int j=i;j<s.length();j++)
        {
            mp[s[j]]++;
            if(mp.size()<=2)
            {
                maxLen=max(maxLen,j-i+1);
            }
            else
            break;
        }
    }
    cout<<maxLen;
}

void optimal(string s)
{
    unordered_map<int,int>mp;
    int l=0;
    int r=0;
    int maxLen=0;
    int k=2;

    while(r<s.length())
    {
        mp[s[r]]++;

        while(mp.size()>k)
        {
            mp[s[l]]--;
            if(mp[s[l]]==0)
            mp.erase(s[l]);
            l++;
        }
        if(mp.size()<=k)
        {
            maxLen=max(maxLen,r-l+1);
        }
        
        r++;
    }

    cout<<maxLen;
}
int main()
{
    string s="aaabbccd";
    // brute(s);
    optimal(s);
}