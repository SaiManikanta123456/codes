#include <bits/stdc++.h>
using namespace std;

int main()
{
    vector<int>a{1,2,3,2,2};
    int k=2;
    int r=0,l=0;
    int n=a.size();
    int maxLen=0;
    unordered_map<int,int>mp;
    while(r<n)
    {
        mp[a[r]]++;
        while(mp.size()>k)
        {
            mp[a[l]]--;
            if(mp[a[l]]==0)
            mp.erase(a[l]);

            l++;
        }

        if(mp.size()<=k)
        {
            maxLen=max(maxLen,r-l+1);
        }

        r++;
    }

    cout<<maxLen;
}