#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<int>a{-1,4,5,1,-2};
    int l=0;
    int windowLength=1;
    int r=windowLength-1;
    int sum=0;
    int maxSum=0;

    for(int i=l;i<=r;i++)
    {
        sum=sum+a[i];
    }
    maxSum=sum;
    while(r<a.size()-1)
    {
        sum=sum-a[l];
        l++;
        r++;
        sum=sum+a[r];

        maxSum=max(sum,maxSum);
    }

    cout<<maxSum;
}