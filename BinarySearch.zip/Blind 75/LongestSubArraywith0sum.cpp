#include<bits/stdc++.h>
using namespace std;

int largestSubarray(vector<int> &a)
{
    int n=a.size();
    unordered_map<int,int>mp;
    int s=0;
    int maxi=-1;
    for(int i=0;i<n;i++)
    {
        s=s+a[i];
        if(s==0)
            maxi=i+1;
        else
        {
            if(mp.find(s)!=mp.end())
            {
                maxi=max(maxi,i-mp[s]);
            }
            else
            mp[s]=i;
        }
    }

    return maxi;
}

int main()
{
    //Intution :: a,b,c,d sum is X. a+b=X. which means c+d=0. if we can store index and sum....
    vector<int>a{9, -3, 3, -1, 6, -5};
    cout<<largestSubarray(a);
}