#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<int>a{10,19,6,3,5};
    int n=a.size();
    
    vector<int>temp=a;
    sort(temp.begin(),temp.end());

    unordered_map<int,int>mp;
    for(int i=0;i<n;i++)
    {
        mp[a[i]]=i;
    }
    int swaps=0;
    for(int i=0;i<n;i++)
    {
        if(temp[i]!=a[i])
        {
            int correct_ind_i=mp[temp[i]];
            swap(a[i],a[correct_ind_i]);

            mp[a[i]]=i;
            mp[a[correct_ind_i]]=correct_ind_i;
            swaps++;
        }
    }
    cout<<swaps;
}