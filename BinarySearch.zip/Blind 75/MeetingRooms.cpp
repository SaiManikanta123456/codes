#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<vector<int>>intervals{{0,6},{1,2},{3,4},{5,7},{5,9},{8,9}};
    priority_queue<int, vector<int>, greater<int>> minHeap; // stores end times

        minHeap.push(intervals[0][1]);
        for (int i = 1; i < intervals.size(); i++) {
            if (intervals[i][0] >= minHeap.top()) {
                minHeap.pop();
            }
            minHeap.push(intervals[i][1]);
        }
        cout<<minHeap.size();
}