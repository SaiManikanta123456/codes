#include <bits/stdc++.h>
using namespace std;

int printElement(int n,int r)
{
    int res=1;
    for(int i=0;i<r;i++)
    {
        res=res*(n-i);
        res=res/(i+1);
    }
    return res;
}

int main()
{
    //variation -1 : printing element at particular row col
    cout<<printElement(6-1,4-1)<<endl;

    //variation -2 : printing complete nth row
    // vector<int>ans;
    // int row=6;
    // for(int i=1;i<=row;i++)
    // {
    //     ans.push_back(printElement(row-1,i-1));
    // }
    // for(auto i:ans)
    // cout<<i<<" ";

    //optimal Approch
    vector<int>ans;
    int row=6;
    int prev=1;
    ans.push_back(prev);
    for(int col=1;col<row;col++)
    {
        prev=prev*(row-col)/col;
        ans.push_back(prev);
    }
    for(auto i:ans)
    cout<<i<<" ";
}