#include <bits/stdc++.h>
using namespace std;

int countSteps(vector<vector<int>> grid,pair<int,int> target,vector<vector<int>>&vis,int n,int m)
{
    int steps=0;
    vis[0][0]=1;
    queue<pair<int,int>>q;
    q.push({0,0});

    while(!q.empty())
    {
        int size=q.size();
        while(size--)
        {
            int row=q.front().first;
            int col=q.front().second;
            q.pop();

            if(row==target.first && col==target.second)
            return steps;

            for(int i=-1;i<=1;i++)
            {
                for(int j=-1;j<=1;j++)
                {
                    int nr=row+i;
                    int nc=col+j;

                    if(nr>=0 && nr<n && nc>=0 && nc<m && vis[nr][nc]==0 && grid[nr][nc]==1)
                    {
                        vis[nr][nc]=1;
                        q.push({nr,nc});
                    }
                }
            }
        }
        steps++;
    }

    return steps;
}

int countStepsRec(int i,int j,pair<int,int> target,vector<vector<int>>&grid,int n,int m)
{
    if(i== target.first && j== target.second)
    {
        return 1;
    }
    
    int down=0;
    if(i+1 < n && grid[i+1][j]==1)
    down=countStepsRec(i+1,j,target,grid,n,m);

    int right=0;
    if(j+1 < m && grid[i][j+1]==1)
    right=countStepsRec(i,j+1,target,grid,n,m);

    return right+down;
}

int main()
{
    vector<vector<int>> grid = {
        {1, 0, 1, 1, 1, 1, 0, 1, 1, 1},
        {1, 0, 1, 0, 1, 1, 1, 0, 1, 1},
        {1, 1, 1, 0, 1, 1, 0, 1, 0, 1},
        {0, 0, 0, 0, 1, 0, 0, 0, 0, 1},
        {1, 1, 1, 0, 1, 1, 1, 0, 1, 0},
        {1, 0, 1, 1, 1, 1, 0, 1, 0, 0},
        {1, 0, 0, 0, 0, 0, 0, 0, 0, 1},
        {1, 0, 1, 1, 1, 1, 0, 1, 1, 1},
        {1, 1, 0, 0, 0, 0, 1, 0, 0, 1}
    };

    int n=grid.size();
    int m=grid[0].size();
    // vector<vector<int>>vis(n,vector<int>(m,0));
    pair<int,int>target={2,2};
    // cout<<countSteps(grid,target,vis,n,m);
    cout<<countStepsRec(0,0,target,grid,n,m);
}