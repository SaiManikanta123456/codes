#include <bits/stdc++.h>
using namespace std;

class QueueUsingSt{
    public:

    stack<int>s1,s2;

    void insert(int x)
    {
        s1.push(x);
    }

    void pop()
    {
        if(s2.empty()==true)
        {
            while(!s1.empty())
            {
                s2.push(s1.top());
                s1.pop();
            }
        }

        if(!s2.empty())
        {
            cout<<s2.top()<<endl;
            s2.pop();
        }
    }

    int peek()
    {
        if(s2.empty())
        {
            while(!s1.empty())
            {
                s2.push(s1.top());
                s1.pop();
            }
        }

        if(!s2.empty())
        {
            return s2.top();
        }

        return -1;
    }
};

int main()
{
    QueueUsingSt qs;

    qs.insert(10);
    qs.insert(20);
    qs.insert(30);

    qs.pop();

    cout<<qs.peek();
}