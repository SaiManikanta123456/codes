#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

void levelOrder(Node* root)
{
    vector<int>a;
    vector<vector<int>>ans;
        if(!root)
        return;

        queue<Node*>q;
        q.push(root);

        while(!q.empty())
        {
            int size=q.size();
            vector<int>v;
            for(int i=0;i<size;i++)
            {
                Node* node=q.front();
                q.pop();
                if(node->left){
                q.push(node->left);
                }
                if(node->right)
                q.push(node->right);
                
                if(i==size-1)
                cout<<node->data<<" ";
                // v.push_back(node->data);
            }

            ans.push_back(v);
        }
     
        // for(auto i:ans)
        // {
        //     for(auto j:i)
        //     {
        //         cout<<j<<" ";
        //     }
        //     cout<<endl;
        // }
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    levelOrder(root);
}