#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

unordered_map<Node*,Node*> parent_child(Node* root)
{
    unordered_map<Node*,Node*>mpp;

    if(!root)
    return mpp;

    queue<Node*>q;
    q.push(root);

    while(!q.empty())
    {
        Node* node=q.front();q.pop();

        if(node->left)
        {
            mpp[node->left]=node;
            q.push(node->left);
        }
        if(node->right)
        {
            mpp[node->right]=node;
            q.push(node->right);
        }
    }

    return mpp;
}

void distAtK(Node* root,int k,vector<int> &res,Node* target)
{
    if(!root)
    return;

    unordered_map<Node*,Node*> mpp=parent_child(root);
    unordered_map<Node*,bool>visited;
    queue<Node*>q;
    q.push(target);
    visited[target]=true;
    int c=0;

    while(!q.empty())
    {
        int size=q.size();
        if(c==k)
        break;

        for(int i=0;i<size;i++)
        {
            Node* node=q.front();q.pop();

            if(node->left && !visited[node->left])
            {
                q.push(node->left);
                visited[node->left]=true;
            }

            if(node->right && !visited[node->right])
            {
                q.push(node->right);
                visited[node->right]=true;
            }

            if(mpp[node] && !visited[mpp[node]])
            {
                q.push(mpp[node]);
                visited[mpp[node]]=true;
            }

        }
        c++;
    }

    while(!q.empty())
    {
        res.push_back(q.front()->data);
        q.pop();
    }
}
int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    Node* target=root->left->left;
    int k=2;
    vector<int>res;
    distAtK(root,k,res,target);

    for(auto i:res)
    cout<<i<<" ";
}