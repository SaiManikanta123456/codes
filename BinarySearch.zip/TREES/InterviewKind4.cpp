#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

void levelOrder(Node* root)
{
    vector<int>a;
    vector<vector<int>>ans;
        if(!root)
        return;

        queue<Node*>q;
        q.push(root);

        while(!q.empty())
        {
            int size=q.size();
            vector<int>v;
            for(int i=0;i<size;i++)
            {
                Node* node=q.front();
                q.pop();
                if(node->left){
                q.push(node->left);
                }
                if(node->right)
                q.push(node->right);
                
                v.push_back(node->data);
            }

            ans.push_back(v);
        }
     
        for(auto i:ans)
        {
            for(auto j:i)
            {
                cout<<j<<" ";
            }
            cout<<endl;
        }
}

void inOrder(Node* root,string &s)
{
    if(!root)
    return;

    inOrder(root->left,s);
    s+=to_string(root->data)+" ";
    inOrder(root->right,s);
}

void preOrder(Node* root,string &s)
{
    if(!root)
    return;

    s+=to_string(root->data)+" ";
    preOrder(root->left,s);
    preOrder(root->right,s);
}

string Serialize(Node* root)
{
    if(!root)
    return "";

    string s1;
    inOrder(root,s1);
    string s2;
    preOrder(root,s2);

    // cout<<s1<<" ||| "<<s2;
    return s1+s2;
}

vector<int> h1(string s)
{
    vector<int>a;
    istringstream iss(s);
    string word;

    while(iss>>word)
    a.push_back(stoi(word));

    return a;
}

Node* h2(vector<int> &inOrder,int inStart,int inEnd,unordered_map<int,int> &mp,vector<int> &preOrder,int preStart,int preEnd)
{
    if(inOrder.size()!=preOrder.size())
    return NULL;

    if(inStart>inEnd || preStart>preEnd)
    return NULL;

    Node* root=new Node(preOrder[preStart]);
    int inRootPosition=mp[preOrder[preStart]];
    int numsLeft=inRootPosition-inStart;

    root->left=h2(inOrder,inStart,inRootPosition-1,mp,preOrder,preStart+1,preStart+numsLeft);
    root->right=h2(inOrder,inRootPosition+1,inEnd,mp,preOrder,preStart+numsLeft+1,preEnd);

    return root;
}

Node* DeSerializeHelper(vector<int> &inOrder,vector<int> &preOrder,unordered_map<int,int> &mp)
{
    return h2(inOrder,0,inOrder.size()-1,mp,preOrder,0,preOrder.size()-1);
}

Node* DeSerialize(string s)
{
    vector<int>inOrder=h1(s.substr(0,s.length()/2));
    vector<int>preOrder=h1(s.substr(s.length()/2,s.length()));

    for(auto i:inOrder)
    cout<<i<<" ";

    cout<<endl;

    for(auto i:preOrder)
    cout<<i<<" ";

    cout<<endl;
    
    unordered_map<int,int>mp;

    for(int i=0;i<inOrder.size();i++)
    {
        mp[inOrder[i]]=i;
    }

    Node* ans=DeSerializeHelper(inOrder,preOrder,mp);

    return ans;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(8);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    string s=Serialize(root);
    cout<<s<<endl;
    Node* ans=DeSerialize(s);

    levelOrder(ans);
}