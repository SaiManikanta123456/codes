#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

int f(Node* root,int &res)
{
    if(!root)
    return 0;

    int left1=max(0,f(root->left,res));
    int right1=max(0,f(root->right,res));

    res=max(res,root->data+left1+right1);

    return max(left1,right1)+root->data;
}

int main()
{
    Node* root = new Node(20);
    root->left = new Node(10);
    root->right = new Node(30);
    root->left->left = new Node(5);
    root->left->right = new Node(18);
    root->right->right = new Node(31);
    root->right->left = new Node(25);

    int res=0;
    f(root,res);
    cout<<res;
}