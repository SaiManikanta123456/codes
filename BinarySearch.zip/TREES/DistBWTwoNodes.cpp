#include <bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* left;
    Node* right;

    Node(int val) {
        data = val;
        left = right = NULL;
    }
};

Node* Lca(Node* root,int a,int b)
{
    if(!root || root->data==a || root->data==b)
    return root;

    Node* leftRoot=Lca(root->left,a,b);
    Node* rightRoot=Lca(root->right,a,b);

    if(leftRoot==NULL)
    return rightRoot;

    if(rightRoot==NULL)
    return leftRoot;

    return root;
}

// int dist(Node* root,int a,int level)
// {
//     if(!root)
//     return -1;

//     if(root->data==a)
//     return level;

//     int left=dist(root->left,a,level+1);
//     if(left==-1)
//         return dist(root->right,a,level+1);

//     return left;
// }

int dist(Node* root,int a,int level)
{
    if(!root)
    return -1;

    queue<pair<Node*,int>>q;
    q.push({root,0});
    while(!q.empty())
    {
        int size=q.size();
        for(int i=0;i<size;i++)
        {
            Node* node=q.front().first;
            int lev=q.front().second;
            q.pop();

            if(node->data==a)
            return lev;

            if(node->left)
            q.push({node->left,lev+1});
            if(node->right)
            q.push({node->right,lev+1});
        }
    }
    return -1;
}

int distBWTwoNode(Node* root,int a,int b)
{
    Node* lca=Lca(root,a,b);

    int one=dist(lca,a,0);
    int two=dist(lca,b,0);

    return one+two;
}

int main()
{
    Node* root = new Node(5);
    root->left = new Node(2);
    root->right = new Node(3);
    root->left->left = new Node(51);
    root->left->right = new Node(15);
    root->right->right = new Node(54);
    root->right->left = new Node(53);

    cout<<distBWTwoNode(root,2,53);    
}