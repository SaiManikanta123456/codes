#include <bits/stdc++.h>
using namespace std;

int main()
{
    int n=4;
    vector<vector<int>> graph{{2,1},{3,1},{1,4}};
    vector<int>indegree(n+1,0);
    vector<vector<int>> adj(n+1);
    for(auto edge:graph)
    {
        int u=edge[0];
        int v=edge[1];
        adj[u].push_back(v);
        indegree[v]++;
    }

    queue<int>q;

    for(int i=1;i<=n;i++)
    {
        if(indegree[i]==0)
        {
            q.push(i);
        }
    }

    int completedSems=0,takenCourses=0;

    while(!q.empty())
    {
        int size=q.size();

        for(int i=0;i<size;i++)
        {
            int node=q.front();
            q.pop();

            takenCourses++;

            for(auto neigh:adj[node])
            {
                indegree[neigh]--;
                if(indegree[neigh]==0)
                q.push(neigh);
            }
        }

        completedSems++;
    }

    if(takenCourses==n)
    {
        cout<<"Good !!";
        exit(0);
    }

    cout<<"-1";

}