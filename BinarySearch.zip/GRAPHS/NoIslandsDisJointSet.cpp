#include <bits/stdc++.h>
using namespace std;

class DisJoint
{
public:
    vector<int> parent, usize;
    DisJoint(int n)
    {
        parent.resize(n + 1);
        usize.resize(n + 1);
        for (int i = 0; i <= n; i++)
        {
            parent[i] = i;
            usize[i] = 1;
        }
    }

    int findUP(int node)
    {
        if (parent[node] == node)
            return parent[node];

        return parent[node] = findUP(parent[node]);
    }

    void findUbySize(int u, int v)
    {
        int parent_u = findUP(u);
        int parent_v = findUP(v);

        if (usize[parent_u] < usize[parent_v])
        {
            parent[parent_u] = parent_v;
            usize[parent_v] = usize[parent_u] + usize[parent_v];
        }
        else
        {
            parent[parent_v] = parent_u;
            usize[parent_u] = usize[parent_u] + usize[parent_v];
        }
    }
};

void no_of_islands()
{
    DisJoint ds(5);
    vector<vector<int> > graph{
        {1, 1, 0, 0, 0},
        {1, 1, 1, 0, 0},
        {0, 1, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {1, 0, 0, 0, 1}};

    int V = 5;
    vector<int> adj[V];
    for (int i = 0; i < V; i++)
    {
        for (int j = 0; j < V; j++)
        {
            if (graph[i][j] == 1)
            {
                ds.findUbySize(i, j);
            }
        }
    }

    int c = 0;

    for (int i = 0; i <= V; i++)
    {
        if (ds.findUP(i) == i)
        {
            c++;
        }
    }
    cout << c;
}

void no_of_islands_1()
{

    vector<vector<int> > graph{
        {1, 1, 0, 0, 0},
        {1, 1, 1, 0, 0},
        {0, 1, 1, 0, 0},
        {0, 0, 0, 0, 0},
        {1, 0, 0, 0, 1}};
    int n = graph.size();
    DisJoint ds(n * n);
    int V = 5;
    int dr[] = {0, -1, 0, 1};
    int dc[] = {-1, 0, 1, 0};
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (graph[i][j] == 0)
                continue;
            for (int k = 0; k < 4; k++)
            {
                int nr = i + dr[k];
                int nc = j + dc[k];

                if (nr >= 0 && nr < n && nc >= 0 && nc < n && graph[i][j] == 1)
                {
                    int node = i * n + j;
                    int newnode = nr * n + nc;
                    ds.findUbySize(node, newnode);
                }
            }
        }
    }

    for (int row = 0; row < n; row++)
    {
        for (int col = 0; col < n; col++)
        {
            if (graph[row][col] == 1)
            {
                int node = (row * n) + col;
                if (ds.findUP(node) == node)
                    cout << node << " ";
            }
        }
    }
}
int main()
{

    // no_of_islands();
    no_of_islands_1();
    // for(auto i:adj)
    // {
    //     for(auto j:i)
    //     {
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }
}