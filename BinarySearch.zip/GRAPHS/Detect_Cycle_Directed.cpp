#include<bits/stdc++.h>
using namespace std;

bool dfs(int node,int vis[],int pathvis[],vector<int> adjList[],int check[])
{
    vis[node]=1;
    pathvis[node]=1;
    check[node]=0;
    for(auto i:adjList[node])
    {
        if(!vis[i])
        {
            vis[i]=1;
            if(dfs(i,vis,pathvis,adjList,check))
            return true;
        }
        else if(pathvis[i]==1)
        {
            return true;
        }
    }

    check[node]=1;
    pathvis[node]=0;
    return false;
}
int main()
{
    int V=6;
    vector<int> adjList[V+1];
    vector<vector<int>>graph{
        {1,2},{2,4},{4,3},{4,5},{5,6},{4,6},{3,1}
    };
    for(int i=0;i<graph.size();i++)
    {
        int m=graph[i][0];
        int n=graph[i][1];

        adjList[m].push_back(n);
    }

    for(int i=1;i<=V;i++)
    {
        cout<<i<<"--->";
        for(auto j:adjList[i])
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }

    int vis[V+1]={0};
    int pathvis[V+1]={0};
    int check[V+1]={0};
    vector<int>safeNode;
    for(int i=1;i<=V;i++)
    {
        if(!vis[i])
        {
            dfs(i,vis,pathvis,adjList,check);
        }
    }
    for(int i=1;i<=V;i++)
    {
        if(check[i])
            safeNode.push_back(i);
    }
    for(auto i:safeNode)
    cout<<i<<" ";

}