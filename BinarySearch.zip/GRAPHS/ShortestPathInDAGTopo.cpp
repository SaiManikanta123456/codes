#include <bits/stdc++.h>
using namespace std;

int main()
{
    vector<vector<int>> edges= {{0,1,2},{0,4,1},{4,5,4},{4,2,2},{1,2,3},{2,3,6},{5,3,1}};
    int V=6;
    unordered_map<int,vector<pair<int,int>>>adjList;
    for(auto i:edges)
    {
        adjList[i[0]].push_back({i[1],i[2]});
    }

    vector<int>topo,indegree(V,0);
    queue<int>q;

    for(int i=0;i<V;i++)
    {
        for(auto it:adjList[i])
        {
            indegree[it.first]++;
        }
    }

    for(int i=0;i<V;i++)
    {
        if(indegree[i]==0)
        {
            q.push(i);
        }
    }

    while(!q.empty())
    {
        int node=q.front();
        q.pop();

        topo.push_back(node);

        for(auto i:adjList[node])
        {
            indegree[i.first]--;
            if(indegree[i.first]==0)
                q.push(i.first);
        }
    }

    vector<int>dist(V,1e9);  //vector<int> dist(V, -1e9); for Longest Path in DAG
    dist[0]=0;
    for(auto node:topo)
    {
        if(dist[node]!=1e9)
        {
            for(auto i:adjList[node])
            {
                int neigh=i.first;
                int neighwt=i.second;

                dist[neigh]=min(dist[neigh],dist[node]+neighwt); //max()  for Longest Path in DAG
            }
        }
    }

    for(auto i:dist)
    {
        cout<<i<<" ";
    }
}