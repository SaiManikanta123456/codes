#include<bits/stdc++.h>
using namespace std;

void rotten_2()
{
    vector<vector<int>> basket{
        {0,1,2},
        {0,1,1},
        {2,1,1}
    };
    int time = 0,n=basket.size(),m=basket[0].size(),oranges=0,cnt=0;
    queue<pair<int,int>>q;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(basket[i][j]!=0)oranges++;
            if(basket[i][j]==2)
            q.push({i,j});
        }
    }
    int delrow[]={0,-1,0,1};
    int delcol[]={-1,0,1,0};
    while(!q.empty())
    {
        int k=q.size();
        cnt=cnt+k;
        while(k--)
        {
            int r=q.front().first;
            int c=q.front().second;

            q.pop();
            for(int i=0;i<4;i++)
            {
                int nr=r+delrow[i];
                int nc=c+delcol[i];

                if(nr>=0 && nr<n && nc>=0 && nc<m && basket[nr][nc]==1)
                {   
                    q.push({nr,nc});
                    basket[nr][nc]=2;
                }

            }
        }

        if(!q.empty())
        {
            days++;
        }
    }
    if(oranges==cnt)
    cout<<days;
    else
    cout<<"-1";
}

int main()
{
    vector<vector<int>> basket{
        {0,1,2},
        {0,1,1},
        {2,1,1}
    };
    int time = 0,n=basket.size(),m=basket[0].size();
    rotten_2();
    vector<vector<int>> vis(n,vector<int>(m,0));

    queue<pair<pair<int,int>,int>>q;    //{{row,col},time}

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(basket[i][j]==2)
            {
                vis[i][j]=2;
                q.push({{i,j},0});
            }
        }
    }

    while(!q.empty())
    {
        int r=q.front().first.first;
        int c=q.front().first.second;
        int t=q.front().second;
        time=max(time,t);
        q.pop();

        int delrow[]={0,-1,0,1};
        int delcol[]={-1,0,1,0};

        for(int i=0;i<4;i++)
        {
            int nr=r+delrow[i];
            int nc=c+delcol[i];

            if(nr>=0 && nr<n && nc>=0 && nc<m && basket[nr][nc]==1 && vis[nr][nc]==0)
            {
                q.push({{nr,c},t+1});
                vis[nr][nc]=2;
            }
        }
    }

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(basket[i][j]==1 && vis[i][j]!=2)
            {
                cout<<"-1";
            }
        }
    }
    cout<<time;
}