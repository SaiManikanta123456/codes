#include<bits/stdc++.h>
using namespace std;

class Disjoint{
    public: 

    vector<int>size,parent;

    Disjoint(int n)
    {
        size.resize(n+1);
        parent.resize(n+1);

        for(int i=0;i<=n;i++)
        {
            parent[i]=i;
            size[i]=1;
        }
    }

    int findUltimateParent(int node)
    {
        if(node==parent[node])
        return node;

        return findUltimateParent(parent[node]);
    }

    void unionBySize(int u,int v)
    {
        int ultimateParentOfU=findUltimateParent(u);
        int ultimateParentOfV=findUltimateParent(v);

        if(ultimateParentOfU==ultimateParentOfV)
        return;

        if(size[ultimateParentOfU] < size[ultimateParentOfV])
        {
            parent[ultimateParentOfU] = ultimateParentOfV;
            size[ultimateParentOfV] = size[ultimateParentOfV] + size[ultimateParentOfU];
        }

        else
        {
            parent[ultimateParentOfV] = ultimateParentOfU;
            size[ultimateParentOfU] = size[ultimateParentOfU] + size[ultimateParentOfV];
        }
    }
};

int main()
{
    Disjoint ds(7);

    ds.unionBySize(1,2);
    ds.unionBySize(2,3);
    ds.unionBySize(4,5);
    ds.unionBySize(6,7);
    ds.unionBySize(5,6);

    if(ds.findUltimateParent(3) == ds.findUltimateParent(7))
    {
        cout<<"Same"<<endl;
    }
    else
    {
        cout<<"Not Same"<<endl;
    }

    ds.unionBySize(3,7);

    if(ds.findUltimateParent(3) == ds.findUltimateParent(7))
    {
        cout<<"Same"<<endl;
    }
    else
    {
        cout<<"Not Same"<<endl;
    }

}