#include <bits/stdc++.h>
using namespace std;

class DisJoint{
    public:
    vector<int>parent,size;
    DisJoint(int n)
    {
        parent.resize(n+1);
        size.resize(n+1,1);

        for(int i=0;i<=n;i++)
        {
            parent[i]=i;
        }
    }

    int findUP(int node)
    {
        if(parent[node]==node)
        return node;

        return parent[node]=(parent[node]);
    }

    void unionBySize(int u,int v)
    {
        int upu=findUP(u);
        int upv=findUP(v);

        if(upu==upv)
        return;

        else if(size[upv]<size[upu])
        {
            parent[upv]=upu;
            size[upu]=size[upu]+size[upv];
        }
        else
        {
            parent[upu]=upv;
            size[upv]=size[upu]+size[upv];
        }
    }
};

static bool comp(vector<int> &a,vector<int> &b)
{
    return a[2]<b[2];
}

int main()
{
    DisJoint ds(4);
    vector<vector<int>> edges = {
        {0, 1, 10}, {1, 3, 15}, {2, 3, 4}, {2, 0, 6}, {0, 3, 5}
    };

    sort(edges.begin(),edges.end(),comp);

    int totalCost=0;

    for(auto edge:edges)
    {
        int source=edge[0];
        int dest=edge[1];
        int cost=edge[2];

        if(ds.findUP(source)!=ds.findUP(dest))
        {
            ds.unionBySize(source,dest);
            totalCost=totalCost+cost;
        }
    }

    cout<<totalCost;

}