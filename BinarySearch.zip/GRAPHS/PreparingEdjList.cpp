#include<bits/stdc++.h>
using namespace std;
void f1()
{
    int V=6;
    vector<int> adjList[V+1];
    vector<vector<int>>graph{
        {1,2},{2,4},{4,3},{4,5},{5,6},{4,6},{3,1}
    };
    for(int i=0;i<graph.size();i++)
    {
        int m=graph[i][0];
        int n=graph[i][1];

        adjList[m].push_back(n);
    }

    for(int i=1;i<=V;i++)
    {
        cout<<i<<"--->";
        for(auto j:adjList[i])
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}
void f2()
{
    vector<vector<int>>graph{
        {1,1,0,0},{1,1,1,0},{0,1,1,1},{0,0,1,1}
    };
    int n=graph.size();
    vector<int>adjList[n];

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(graph[i][j]==1 && i!=j)
            {
                adjList[i].push_back(j);
                // adjList[j].push_back(i);
            }
        }
    }
    for(int i=0;i<n;i++)
    {
        cout<<i<<"--->";
        for(auto j:adjList[i])
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}

void f3()
{
    vector<vector<int>>graph{
        {0,1,1},{1,2,2},{2,3,3}
    };
    vector<pair<int,int>>edgeList[4];
    for(auto i:graph)
    {
        int u=i[0];
        int v=i[1];
        int w=i[2];
            
        edgeList[u].push_back({v,w});
        // edgeList[v].push_back({u,w});
    }
    for(int i=0;i<4;i++)
    {
        cout<<i<<"--->";
        for(auto j:edgeList[i])
        {
            cout<<j.first<<".....> "<<j.second<<" ";
        }
        cout<<endl;
    }
}
int main()
{
    //case-1 
    //when graph is given as {source,destination}
    // f1();

    //case-2
    //when graph is given as matrix of 1's and 0's
    // 1 when there is edge between u and v (u--->v)
    // f2();

    //case-3
    //when graph is given as {source,destination,edgeWeight}
    f3();

}