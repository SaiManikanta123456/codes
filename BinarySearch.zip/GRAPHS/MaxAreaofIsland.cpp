#include<bits/stdc++.h>
using namespace std;

int bfs(int n,int m,int row,int col,vector<vector<int>> &graph,vector<vector<int>> &vis)
{
    vis[row][col]=1;
    queue<pair<int,int>>q;
    q.push({row,col});
    int count=1;
    while(!q.empty())
    {
        int r=q.front().first;
        int c=q.front().second;
        q.pop();
        for(int i=-1;i<=1;i++)
        {
            for(int j=-1;j<=1;j++)
            {
                int nr=r+i;
                int nc=c+j;
               
                if(nr>=0 && nr<n && nc>=0 && nc<m && graph[nr][nc]==1 && vis[nr][nc]==0)
                {
                    vis[nr][nc]=1;
                    q.push({nr,nc});
                    count++;
                }
            }
        }
    }

    return count;
}

int main()
{
    vector<vector<int>>graph{
    {1, 0, 0, 0, 1, 0, 0},
    {0, 1, 0, 0, 1, 1, 0},
    {1, 1, 0, 0, 0, 0, 0},
    {1, 0, 0, 1, 1, 0, 0},
    {1, 0, 0, 1, 0, 1, 1}};

    int n=graph.size();
    int m=graph[0].size();

    vector<vector<int>>vis(n,vector<int>(m,0));

    int maxArea=0;

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(!vis[i][j] && graph[i][j]==1)
            {
                maxArea=max(maxArea,bfs(n,m,i,j,graph,vis));
            }
        }
    }

    cout<<maxArea;
}