#include <bits/stdc++.h>
using namespace std;

int dfs(int row,int col,vector<vector<int>> &graph,vector<vector<int>> &vis,int ind,int n,int m)
{
    vis[row][col]=ind;

    vector<int>dr{0,1,0,-1};
    vector<int>dc{-1,0,1,0};
    int c=1;
    for(int i=0;i<4;i++)
    {
        int nr=row+dr[i];
        int nc=col+dc[i];

        if(nr>=0 && nr<n && nc>=0 && nc<m && !vis[nr][nc] && graph[nr][nc]==1)
        {
            c=c+dfs(nr,nc,graph,vis,ind,n,m);
        }
    }

    return c;
}

int main()
{
    vector<vector<int>>graph{
        {1,1,1,0,0},
        {0,0,0,1,1},
        {0,0,0,1,1},
        {1,1,0,0,0}
    };

    int n=graph.size();
    int m=graph[0].size();
    vector<vector<int>>vis(n,vector<int>(m,0));

    unordered_map<int,int>mp;
    int ind=2;

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(graph[i][j]==1 && vis[i][j]==0)
            {
                mp[ind]=dfs(i,j,graph,vis,ind,n,m);
                ind++;
            }
        }
    }

    int maxIsland=0;
    for(auto i:mp)
    {
        maxIsland=max(maxIsland,i.second);
    }

    vector<int>dr{0,1,0,-1};
    vector<int>dc{-1,0,1,0};

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(graph[i][j]==0)
            {
                unordered_set<int>set;
                int total=1;

                for(int k=0;k<4;k++)
                {
                    int nr=i+dr[k];
                    int nc=j+dc[k];

                    if(nr>=0 && nr<n && nc>=0 && nc<m && vis[nr][nc]>0)
                    {
                        int nid=vis[nr][nc];
                        if(set.find(nid)==set.end())
                        {
                            set.insert(nid);
                            total=total+mp[nid];
                        }
                    }
                }

                maxIsland=max(maxIsland,total);
            }
        }
    }

    cout<< maxIsland;
}