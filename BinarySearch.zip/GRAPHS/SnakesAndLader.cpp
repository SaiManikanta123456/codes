#include <bits/stdc++.h>
using namespace std;

int getMinDiceThrows(vector<int> &moves,int n)
{
    queue<pair<int,int>>q;
    q.push({0,0});
    vector<int>visited(n,false);

    while(!q.empty())
    {
        int dist=q.front().second;
        int v=q.front().first;
        q.pop();
        
        if(v==n-1)
        return dist;

        for(int i=v+1;i<=v+6;i++)
        {
            if(i<n)
            {
                if(!visited[i])
                {
                    visited[i]=true;

                    int desti=0;
                    if(moves[i]!=-1)
                    {
                        desti=moves[i];
                    }
                    else
                    {
                        desti=i;
                    }

                    q.push({desti,dist+1});
                }
            }
        }
    }
}

int main()
{
    int n = 30;
    vector<int> moves(n, -1);

    // Ladders
    moves[2] = 21;
    moves[4] = 7;
    moves[10] = 25;
    moves[19] = 28;

    // Snakes
    moves[26] = 0;
    moves[20] = 8;
    moves[16] = 3;
    moves[18] = 6;

    cout << getMinDiceThrows(moves,n);
}