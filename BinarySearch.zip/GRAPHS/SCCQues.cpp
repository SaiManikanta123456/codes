#include <bits/stdc++.h>
using namespace std;

void dfs1(int node,vector<bool> &vis,vector<int> adj[],stack<int> &st)
{
    vis[node]=true;
    for(auto i:adj[node])
    {
        if(!vis[i])
        {
            dfs1(i,vis,adj,st);
        }
    }
    st.push(node);
}

void dfs2(int node,vector<bool> &vis,vector<int> adj[],vector<int> &component,int comp)
{
    vis[node]=true;
    component[node]=comp;

    for(auto i:adj[node])
    {
        if(!vis[i])
        {
            dfs2(i,vis,adj,component,comp);
        }
    }
}

int main()
{
    vector<vector<int>> edges{
        {0,2},{1,0},{2,1},{0,3},{3,4}
    };

    // Step 1: Build adjacency list
    int maxNode = 0;
    for (auto &e : edges) {
        maxNode = max({maxNode, e[0], e[1]});
    }
    int v = maxNode + 1;
    vector<int> adj[v];
    for (auto e : edges) {
        adj[e[0]].push_back(e[1]);
    }

    stack<int>st;
    vector<bool>vis1(v,false);
    
    for(int i=0;i<v;i++)
    {
        if(!vis1[i])
        {
            dfs1(i,vis1,adj,st);
        }
    }

    vector<int> adjT[v];
    for(int i=0;i<v;i++)
    {
        for(auto it:adj[i])
        {
            adjT[it].push_back(i);
        }
    }

    int comp=0;
    vector<int>component(v,-1);
    vector<bool>vis2(v,false);
    while(!st.empty())
    {
        int u=st.top();st.pop();
        if(!vis2[u])
        {
            dfs2(u,vis2,adjT,component,comp++);
        }
    }
    for(auto i:component)
    {
        cout<<i<<" ";
    }
    vector<int>indeg(comp,0),outdg(comp,0);
    for(int i=0;i<v;i++){
        for(auto j:adj[i])
        {
            if(component[i]!=component[j])
            {
                outdg[component[i]]++;
                indeg[component[j]]++;
            }
        }
    }

    int src=0,sink=0;
    for (int i = 0; i < comp; i++) {
        if (indeg[i] == 0) src++;
        if (outdg[i] == 0) sink++;
    }

    cout<<max(src,sink);
}