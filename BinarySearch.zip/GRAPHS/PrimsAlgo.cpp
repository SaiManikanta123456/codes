#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<vector<int>>graph{
        {0,1,5},{1,2,3},{0,2,1}
    };
    int n=graph.size();
    vector<pair<int,int>>edgeList[n];
    for(auto i:graph)
    {
        int u=i[0];
        int v=i[1];
        int w=i[2];
            
        edgeList[u].push_back({v,w});
        edgeList[v].push_back({u,w});
    }
    // for(int i=0;i<n;i++)
    // {
    //     cout<<i<<"--->";
    //     for(auto j:edgeList[i])
    //     {
    //         cout<<j.first<<".....> "<<j.second<<" ";
    //     }
    //     cout<<endl;
    // }

    int sum=0;
    vector<pair<int,int>>edges;
    //{dist,{node,paent}}
    priority_queue< 
    pair<int, pair<int, int>>,            // type of elements
    vector<pair<int, pair<int, int>>>,    // underlying container
    greater<pair<int, pair<int, int>>>    // min-heap comparator
    > pq;
    vector<int>vis(n,0);
    pq.push({0,{0,-1}});
    while(!pq.empty())
    {
        int weight=pq.top().first;
        int node=pq.top().second.first;
        int parent=pq.top().second.second;

        pq.pop();

        if(vis[node]==1) continue;
        vis[node]=1;
        sum=sum+weight;
        edges.push_back({node,parent});

        for(auto i:edgeList[node])
        {
            int neigh=i.first;
            int edgeWeight=i.second;

            if(!vis[neigh])
            {
                pq.push({edgeWeight,{neigh,node}});
            }
        }
    }

    cout<<sum<<endl;

    for(auto i:edges)
    {
        if(i.second!=-1)
        cout<<i.first<<" "<<i.second<<endl;
    }
}