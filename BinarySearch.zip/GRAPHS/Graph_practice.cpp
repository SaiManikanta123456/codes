#include<bits/stdc++.h>
using namespace std;
int f(int i,int j,vector<vector<int>> &graph)
{
    int n=3,m=3,co=0;
    for(int dr=0;dr<=1;dr++)
    {
        for(int dc=0;dc<=1;dc++)
        {
            int nr=i+dr;
            int nc=j+dc;
            if(nr>=0&&nr<n&&nc>=0&&nr<m&&graph[nr][nc]%2==0)
            {
                co++;
            }
        }
    }
    return co;
    
}
void iscircular(vector<vector<int>> &graph)
{
    int n=graph.size();
    int m=graph[0].size();
    vector<int> edge[n];
    for(auto i:graph)
    {
        edge[i[0]].push_back(i[1]);
    }
    int v=3;
    int incoming[v]={0};
    for(int i=0;i<v;i++)
    {
        for(auto j:edge[i])
        {
            incoming[j]++;
        }
    }
    queue<int>q;
    int c=0;
    for(int i=0;i<v;i++)
    {
        if(incoming[i]==0)
        q.push(i);
    }
    vector<int>v1;
    while(!q.empty())
    {
        int node=q.front();
        q.pop();
        v1.push_back(node);
        c++;
        for(auto i:edge[node])
        {
            incoming[i]--;
            if(incoming[i]==0)
            q.push(i);
        }
    }
    for(auto i:v1)
    cout<<i<<" ";
    if(c==v)
    cout<<"Nope";
    else
    cout<<"Yes";
}
int main()
{
    vector<vector<int>>graph{
       {0,1},{1,2},{2,3}
    };
    iscircular(graph);
    // vector<vector<int>>ans(0);
    // for(int i=0;i<3;i++)
    // {
    //     for(int j=0;j<3;j++)
    //     {
    //         cout<<f(i,j,graph);
    //     }
    //     cout<<endl;
    // }
    // f(0,0,graph);
    // for(int i=0;i<3;i++)
    // {
    //     for(int j=0;j<3;j++)
    //     {
    //        cout<<ans[i][j];
    //     }
    //     cout<<endl;
    // }
    // cout<<1;
}