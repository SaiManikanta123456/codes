#include<bits/stdc++.h>
using namespace std;

void bfs(int row,int col,vector<vector<bool>> &vis,vector<vector<int>> &graph)
{
    vis[row][col]=true;
    queue<pair<int,int>>q;
    q.push({row,col});
    while(!q.empty())
    {
        int r=q.front().first;
        int c=q.front().second;
        q.pop();

        for(int i=-1;i<=1;i++)
        {
            for(int j=-1;j<=1;j++)
            {
                int nr=r+i;
                int nc=c+j;

                if(nr>=0 && nr<graph.size() && nc>=0 && nc<graph.size() && vis[nr][nc]==false && graph[nr][nc]==1)
                {
                    q.push({nr,nc});
                    vis[nr][nc]=1;
                }
            }
        }
    }
}

int main()
{
    vector<vector<int>>graph{
        {1,1,0,0,0},
        {1,1,1,0,0},
        {0,1,1,0,0},
        {0,0,0,0,0},
        {1,0,0,0,1}
    };

    int c=0,n=graph.size(),m=graph[0].size();

    vector<vector<bool>>vis(n,vector<bool>(m,0));

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(vis[i][j]==false && graph[i][j]==1)
            {
                c++;
                bfs(i,j,vis,graph);
            }
        }
    }

    cout<<c;
}