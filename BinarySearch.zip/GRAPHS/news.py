text="saimanisaikantasaisai"
def f(text):
    new=text.replace("sai","nope")
    return new
print(f(text))