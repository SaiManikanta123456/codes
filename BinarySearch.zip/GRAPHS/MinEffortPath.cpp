#include <bits/stdc++.h>
using namespace std;

int minEffort=1e9;
void dfs(int row,int col,int n,int m,vector<vector<int>> &a,vector<vector<int>>&vis,int curEffort)
{
    vis[row][col]=1;
    if(row==n-1 && col==m-1)
    {
        minEffort=min(minEffort,curEffort);
    }

    int dx[]={0,-1,0,1};
    int dy[]={-1,0,1,0};

    for(int i=0;i<4;i++)
    {
        int nr=row+dx[i];
        int nc=col+dy[i];

        if(nr>=0 && nr<n && nc>=0 && nc<m && vis[nr][nc]==0)
        {
            int diff=abs(a[nr][nc]-a[row][col]);
            dfs(nr,nc,n,m,a,vis,max(diff,curEffort));
        }
    }
    vis[row][col]=0;
}

int main()
{
    vector<vector<int>>a{{1,2,2},{3,8,2},{5,3,5}};
    int n=a.size();
    int m=a[0].size();
    vector<vector<int>>ans;
    vector<int>temp;
    vector<vector<int>>vis(n,vector<int>(m,0));
    
    dfs(0,0,n,m,a,vis,0);
    cout<<minEffort;
}