#include<bits/stdc++.h>
using namespace std;

void bfs(int sr,int sc,int init,int req,vector<vector<int>> &image,vector<vector<int>> &ans)
{
    queue<pair<int,int>>q;
    q.push({sr,sc});
    int delrow[]={0,-1,0,1};
    int delcol[]={-1,0,1,0};

    while(!q.empty())
    {
        int r=q.front().first;
        int c=q.front().second;

        q.pop();

        for(int i=0;i<4;i++)
        {
            int nr=r+delrow[i];
            int nc=c+delcol[i];

            if(nr>=0 && nr<ans.size() && nc>=0 && nc<ans.size() && image[nr][nc]==init && ans[nr][nc]!=req)
            {
                q.push({nr,nc});
                ans[nr][nc]=req;
            }
        }
    }
}

int main()
{
    vector<vector<int>> image{
        {1,1,1},
        {1,1,0},
        {1,0,1}
    };

    int reqColour=2,sr=0,sc=0;
    int initialColour=image[sr][sc];
    vector<vector<int>>ans=image;

    bfs(sr,sc,initialColour,reqColour,image,ans);

    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}