#include <bits/stdc++.h>
using namespace std;

struct State{
    int row,col,broken,dist;
};



int shortestPathWithOneBreak(vector<vector<int>> grid)
{
    int n = grid.size(), m = grid[0].size();
    vector<vector<vector<bool>>> vis(n, vector<vector<bool>>(m, vector<bool>(2, false)));

    queue<State>q;
    q.push({0,0,0,1});

    vis[0][0][0]=true;

    int dr[4] = {1, -1, 0, 0};
    int dc[4] = {0, 0, 1, -1};

    while(!q.empty())
    {
        auto cur=q.front();
        q.pop();

        if(cur.row==n-1 && cur.col==m-1)
        return cur.dist;

        for(int i=0;i<4;i++)
        {
            int nr=cur.row+dr[i];
            int nc=cur.col+dc[i];

            if(nr<0 || nr>=n || nc<0 || nc>=m)
            continue;

            if(grid[nr][nc]==0 && !vis[nr][nc][cur.broken])
            {
                vis[nr][nc][cur.broken]=true;
                q.push({nr,nc,cur.broken,cur.dist+1});
            }

            if(grid[nr][nc]==1 && !vis[nr][nc][1] && cur.broken==0)
            {
                vis[nr][nc][1]=true;
                q.push({nr,nc,1,cur.dist+1});
            }
        }
    }
}

int main()
{
    vector<vector<int>> grid = {
        {0,1,0},
        {0,1,0},
        {0,0,0}
    };

    cout << shortestPathWithOneBreak(grid) << endl;
}