#include<bits/stdc++.h>
using namespace std;

void dfs(int node,int vis[],stack<int> &st,vector<int>adjList[])
{
    vis[node]=1;

    for(auto i:adjList[node])
    {
        if(!vis[i])
        dfs(i,vis,st,adjList);
    }
    st.push(node);
}
int main()
{
    vector<string>dir{"baa", "abcd", "abca", "cab", "cad"};
    vector<int>adjList[26];
    for(int i=0;i<dir.size()-1;i++)
    {
        string s1=dir[i];
        string s2=dir[i+1];

        int mini=min(s1.length(),s2.length());

        for(int j=0;j<mini;j++)
        {
            if(s1[j]!=s2[j])
            {
                adjList[s1[j]-'a'].push_back(s2[j]-'a');
                break;
            }
        }
    }

    for(int i=0;i<dir.size();i++)
    {
        cout<<i<<"--->";
        for(auto j:adjList[i])
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }

    stack<int>st;

    int vis[dir.size()]={0};

    for(int i=0;i<dir.size();i++)
    {
        if(!vis[i])
        {
            dfs(i,vis,st,adjList);
        }
    }

    while(!st.empty())
    {
        cout<<st.top()<<" ";
        st.pop();
    }
}