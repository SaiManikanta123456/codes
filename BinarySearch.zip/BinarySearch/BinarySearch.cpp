#include <bits/stdc++.h>
using namespace std;
int binarySearch(vector<int> &a,int n,int target)
{
    int low=0;
    int high=n-1;
    int ans=-1;
    while(low<=high)
    {
        int mid=(low+high)/2;

        if(a[mid]==target)
        return mid;
        
        else if(a[mid]>target)
        high=mid-1;   
        else
        low=mid+1;
    }
    return ans;
}
int main() {
    vector<int>a{1,2,3,4,5,6};
    cout<<binarySearch(a,a.size(),5);
}