#include <bits/stdc++.h>
using namespace std;

int calculate(vector<int> &a,int time)
{
    int res=0;

    for(auto i:a)
    {
        res=res+ceil((double)i/(double)time);
    }
    return res;
}
int main()
{
    vector<int>a{3,6,7,11};
    int h=8;

    int lowerBound=1;
    int upperBound=*max_element(a.begin(),a.end());

    int ans=-1;

    while(lowerBound<=upperBound)
    {
        int mid=(lowerBound+upperBound)/2;

        if(calculate(a,mid)<=h)
        {
            ans=mid;
            cout<<ans<<endl;
            upperBound=mid-1;
        }  
        else
        {
            lowerBound=mid+1;
        }
    }

    cout<<ans;
}