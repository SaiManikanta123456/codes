#include <bits/stdc++.h>
using namespace std;

int binarySearch(vector<int>a,int k)
{
    int low=0,high=a.size()-1;
    while(low<high)
    {
        int mid=(low+high)/2;

        if(a[mid]==k)
        return mid;
        else if(a[mid]>k)
        high=mid-1;
        else
        low=mid+1;
    }
}

int lowerbound(vector<int>a,int k)
{
    int low=0,high=a.size()-1;
    while(low<high)
    {
        int mid=(low+high)/2;

        if(a[mid]>=k)
        return mid;
        else
        low=mid+1;
    }
}

int firstoccurance(vector<int>a,int target)
{
    int low=0;
    int high=a.size()-1;
    while(low<=high)
    {
        int mid=(low)
    }
}

int main()
{
    //Binary Search
    // vector<int>a{1,2,3,4,5,6,7};
    // int target=5;
    // cout<<binarySearch(a,5);

    //LowerBound i.e. a[i]>=target
    // vector<int>a{1,2,3,4,5,6,7};
    // int target=5;
    // cout<<lowerbound(a,5);

    //First occurance of element x in array
    vector<int>a{1,2,2,3,3,3,4,5,6,7};
    int target=3;
    cout<<firstoccurance(a,target);
}