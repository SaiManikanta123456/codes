#include <bits/stdc++.h>
using namespace std;
int lowerBound(vector<int> &a,int n,int target)
{
    int low=0;
    int high=n-1;
    int ans=-1;
    while(low<=high)
    {
        int mid=(low+high)/2;

        if(a[mid]>target)
        return mid;
        else
        low=mid+1;
    }
    return ans;
}
int main()
{
    vector<int>a{2,2,2,2,2};
    // cout<<lowerBound(a,a.size(),110); //a[i]>=target
    // cout<<lowerBound(a,a.size(),2); //a[i]>target
    cout<<upper_bound(a.begin(),a.end(),1)-a.begin();
}