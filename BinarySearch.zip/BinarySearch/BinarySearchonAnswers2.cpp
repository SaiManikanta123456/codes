#include <bits/stdc++.h>
using namespace std;

bool calculate(vector<int> &a,int mid,int roses,int boquet)
{
    int c=0;
    int b=0;
    for(auto i:a)
    {
        if(i<=mid)
        {
            c++;
        }
        else
        {
            b+=(roses/c);
            c=0;
        }
    }
    b+=(roses/c);

    return b>=boquet;
}

int main()
{
    vector<int>a{7,7,7,7,13,11,12,7};

    int low=*min_element(a.begin(),a.end());
    int high=*max_element(a.begin(),a.end());
    int roses=3;
    int boquet=2;
    int ans=-1;

    while(low<=high)
    {
        int mid=(low+high)/2;

        if(calculate(a,mid,roses,boquet))
        {
            ans=mid;
            high=mid-1;
        }
        else
        {
            low=mid+1;
        }
    }

    cout<<ans;
}