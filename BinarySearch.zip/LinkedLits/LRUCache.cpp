#include<bits/stdc++.h>
using namespace std;

class Node{
  public:
  
  int key;
  int val;
  Node* next;
  Node* prev;

  Node(int k,int v)
  {
    key=k;
    val=v;
    next=nullptr;
    prev=nullptr;
  }
  
};

class NodeImpl{
    public:

    int capacity;
    Node* head;
    Node* tail;
    unordered_map<int,Node*>mp;

    NodeImpl(int capacity)
    {
        this->capacity=capacity;
        head=new Node(-1,-1);
        tail=new Node(-1,-1);
        tail->prev=head;
        head->next=tail;
    }

    void put(int key,int val)
    {
        if(mp.find(key)!=mp.end())
        {
            Node* toBeDeleted=mp[key];
            removeNode(toBeDeleted);
            delete toBeDeleted;
        }

        Node* node=new Node(key,val);
        mp[key]=node;
        addNode(node);

        if(mp.size() > capacity)
        {
            Node* toBeDeleted=tail->prev;
            removeNode(toBeDeleted);
            mp.erase(toBeDeleted->key);
            delete toBeDeleted;
        }
    }

    int get(int key)
    {
        if(mp.find(key)==mp.end())
        {
            return -1;
        }

        Node* curNode=mp[key];
        addNode(curNode);
        removeNode(curNode);

        return mp[key]->val;
    }

    void addNode(Node* node) //We add node right after the head
    {
        Node* nextNode=head->next;
        head->next=node;
        node->prev=head;
        node->next=nextNode;
        nextNode->prev=node;
    }

    void removeNode(Node* node) 
    {
        Node* prevNode=node->prev;
        Node* nextNode=node->next;
        prevNode->next=nextNode;
        nextNode->prev=prevNode;
    }

    void printState()
    {
        Node* temp = head->next;
        while(temp!=tail)
        {
            cout<<temp->key<<" --> "<<temp->val<<endl;
            temp=temp->next;
        }
    }
};

int main()
{
    NodeImpl* ni=new NodeImpl(4);
    ni->put(1,100);
    ni->put(2,200);
    ni->put(3,300);
    ni->put(4,400);

    ni->printState();

    ni->put(3,350);

    ni->printState();

    cout<<ni->get(3)<<endl;
    cout<<ni->get(1)<<endl;
    cout<<ni->get(56)<<endl;

    ni->printState();
}