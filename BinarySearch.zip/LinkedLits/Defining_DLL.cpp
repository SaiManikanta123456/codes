#include<bits/stdc++.h>
using namespace std;

class DoubleLinkedList{
    public:

    int data;
    DoubleLinkedList* next;
    DoubleLinkedList* prev;

    DoubleLinkedList(int data1,DoubleLinkedList* next1,DoubleLinkedList* prev1)
    {
        data=data1;
        next=next1;
        prev=prev1;
    }

    DoubleLinkedList(int data1)
    {
        data=data1;
        next=nullptr;
        prev=nullptr;
    }
};

void printList(DoubleLinkedList* head)
{
    while(head)
    {
        cout<<head->data<<" ";
        head=head->next;
    }
}

void printListReverse(DoubleLinkedList* head)
{
    DoubleLinkedList* temp=head;

    while(temp->next)
    {
        temp=temp->next;
    }
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->prev;
    }
}

DoubleLinkedList* DeleteHead(DoubleLinkedList* head)
{
    if(head==nullptr || (head->prev==nullptr && head->next==nullptr))
    return nullptr;

    DoubleLinkedList* prev=head;
    head=head->next;
    head->prev=nullptr;
    prev->next=nullptr;
    delete prev;

    return head;
}

DoubleLinkedList* DeleteTail(DoubleLinkedList* head)
{
    if(head==nullptr || (head->prev==nullptr && head->next==nullptr))
    return nullptr;

    DoubleLinkedList* temp=head;
    while(temp->next)
    {
        temp=temp->next;
    }

    DoubleLinkedList* back=temp->prev;

    back->next=nullptr;

    temp->prev=nullptr;

    delete temp;

    return head;

}

DoubleLinkedList* deleteKthElement(DoubleLinkedList* head,int k)
{
    if(head==nullptr)
    return nullptr;

    if(k==4)
    {
        return DeleteTail(head);
    }

    if(k==1)
    {
        return DeleteHead(head);
    }

    int c=0;
    DoubleLinkedList* temp=head;
    while(temp)
    {
        c++;
        if(c==k)
        break;

        temp=temp->next;
    }

    DoubleLinkedList* back=temp->prev;
    DoubleLinkedList* front=temp->next;

    back->next=front;
    front->prev=back;

    delete temp;

    return head;
}

DoubleLinkedList* InsertAtHead(DoubleLinkedList* head,int val)
{
    if(head==nullptr)
    {
        return new DoubleLinkedList(val,nullptr,nullptr);
    }

    DoubleLinkedList* newHead=new DoubleLinkedList(val,head,nullptr);
    head->prev=newHead;

    return newHead;
}

DoubleLinkedList* InsertAtTail(DoubleLinkedList* head,int val)
{
    if(head==nullptr)
    {
        return new DoubleLinkedList(val,nullptr,nullptr);
    }

    DoubleLinkedList* temp=head;

    while(temp->next)
    {
        temp=temp->next;
    }

    DoubleLinkedList* newTail=new DoubleLinkedList(val,nullptr,temp);

    temp->next=newTail;

    return head;

}

DoubleLinkedList* InsertAtKthPosition(DoubleLinkedList* head,int val,int k)
{
    if(head==nullptr)
    {
        return new DoubleLinkedList(val,nullptr,nullptr);
    }

    DoubleLinkedList* temp=head;

    int c=0;

    while(temp)
    {
        c++;
        if(c==k)
        break;
        
        temp=temp->next;
    }

    DoubleLinkedList* back=temp->next;
    DoubleLinkedList* front=temp->next;

    DoubleLinkedList* newNode=new DoubleLinkedList(val,front,temp);

    temp->next=newNode;

    return head;
}

int main()
{
    vector<int>a{1,2,3,4};

    DoubleLinkedList* list=new DoubleLinkedList(a[0]);
    DoubleLinkedList* prev=list;

    for(int i=1;i<a.size();i++)
    {
        DoubleLinkedList* temp=new DoubleLinkedList(a[i],nullptr,prev);
        prev->next=temp;
        prev=temp;
    }

    DoubleLinkedList* head=list;

    // DoubleLinkedList* dll=DeleteHead(head);

    // printList(dll);

    // DoubleLinkedList* dll=DeleteTail(head);

    // printList(dll);

    // DoubleLinkedList* dll=deleteKthElement(head,3);

    // printList(dll);

    // DoubleLinkedList* dll=InsertAtHead(head,0);

    // printList(dll);

    // DoubleLinkedList* dll=InsertAtTail(head,0);

    // printList(dll);

    DoubleLinkedList* dll=InsertAtKthPosition(head,0,2);

    printList(dll);

    // printListReverse(head);
}