#include<bits/stdc++.h>
using namespace std;

struct Trie{
    Trie* links[26];

    bool containsKey(char ch)
    {
        return links[ch-'a']!=NULL;
    }

    void put(char ch,Trie* node)
    {
        links[ch-'a']=node;
    }

    Trie* get(char ch)
    {
        return links[ch-'a'];
    }
};

int main()
{
    Trie* root=new Trie();
    int c=0;
    string s="abc";

    for(int i=0;i<s.length();i++)
    {
        Trie* node=root;
        for(int j=i;j<s.length();j++)
        {
            
            if(!node->containsKey(s[j]))
            {
                c++;
                node->put(s[j],new Trie());
            }
            node=node->get(s[j]);
        }
    }
    cout<<c+1;
}