#include <bits/stdc++.h>
using namespace std;

// Definition of the Trie node structure.
struct Trie {
    Trie* links[26];
    bool flag;  // indicates end of a word

    // Constructor: initialize all links to nullptr and flag to false.
    Trie() : flag(false) {
        for (int i = 0; i < 26; i++)
            links[i] = nullptr;
    }

    // Check if there is a link for character ch.
    bool containsKey(char ch) {
        return (links[ch - 'a'] != nullptr);
    }

    // Insert a link for character ch.
    void put(char ch, Trie* node) {
        links[ch - 'a'] = node;
    }

    // Get the link corresponding to character ch.
    Trie* get(char ch) {
        return links[ch - 'a'];
    }

    // Check if this node marks the end of a word.
    bool isEnd() {
        return flag;
    }

    // Mark this node as representing the end of a word.
    void setEnd() {
        flag = true;
    }
};

// Trie implementation class
class TrieImplementation {
    Trie* root;
public:
    TrieImplementation() {
        root = new Trie();
    }

    // Insert a word into the Trie.
    void insert(string word) {
        Trie* node = root;
        for (char ch : word) {
            if (!node->containsKey(ch)) {
                node->put(ch, new Trie());
            }
            node = node->get(ch);
        }
        node->setEnd();
    }

    // Search for a prefix in the Trie. Returns the node corresponding to the last character of the prefix, or nullptr if not found.
    Trie* searchPrefix(string prefix) {
        Trie* node = root;
        for (char ch : prefix) {
            if (!node->containsKey(ch))
                return nullptr;
            node = node->get(ch);
        }
        return node;
    }

    // Depth-first search to collect suggestions from the given Trie node.
    // The 'current' string is the prefix built so far (including the characters from the path),
    // and suggestions vector collects up to 3 words.
    void dfs(Trie* node, string& current, vector<string>& suggestions) {
        if (suggestions.size() == 3) return; // Limit to three suggestions.
        if (node->isEnd()) {
            suggestions.push_back(current);
        }
        for (char ch = 'a'; ch <= 'z'; ch++) {
            if (node->containsKey(ch)) {
                current.push_back(ch);
                dfs(node->get(ch), current, suggestions);
                current.pop_back();
            }
        }
    }

    // Given a prefix, returns up to three lexicographically smallest suggestions.
    vector<string> getSuggestions(string prefix) {
        vector<string> suggestions;
        Trie* node = searchPrefix(prefix);
        // printnode(node);
        if (node == nullptr) return suggestions;
        string current = prefix;
        dfs(node, current, suggestions);
        return suggestions;
    }
};

// The solution class that uses the Trie to generate search suggestions.
class Solution {
public:
    vector<vector<string>> suggestedProducts(vector<string>& products, string searchWord) {
        // Sort products lexicographically.
        sort(products.begin(), products.end());

        // Build the Trie with the sorted product list.
        TrieImplementation trie;
        for (string& word : products)
            trie.insert(word);

        vector<vector<string>> ans;
        string prefix = "";
        // For every character in the search word, form the prefix and get suggestions.
        for (char ch : searchWord) {
            prefix.push_back(ch);
            ans.push_back(trie.getSuggestions(prefix));
        }
        return ans;
    }
};

int main() {
    vector<string> products = {"mobile", "mouse", "moneypot", "monitor", "mousepad"};
    string searchWord = "mou";
    Solution sol;
    vector<vector<string>> result = sol.suggestedProducts(products, searchWord);

    // Print the suggestions for each prefix.
    for (auto& suggestions : result) {
        for (auto& word : suggestions) {
            cout << word << " ";
        }
        cout << "\n";
    }
    return 0;
}
