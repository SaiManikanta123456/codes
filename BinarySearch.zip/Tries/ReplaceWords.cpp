#include <bits/stdc++.h>
using namespace std;

struct trie
{
    trie* links[26];
    bool flag=false;

    bool containskey(char ch)
    {
        return links[ch-'a']!=NULL;
    }

    trie* get(char ch)
    {
        return links[ch-'a'];
    }

    void put(char ch,trie* t)
    {
        links[ch-'a']=t;
    }

    bool isEnd()
    {
        return flag;
    }

    void setEnd()
    {
        flag=true;
    }
};

class TrieImplimentation{

    Trie* root;
    TrieImplimentation()
    {
        root=new trie();
    }

    void insert(string word)
    {
        trie* node=root;

        for(int i=0;i<word.length();i++)
        {
            char ch=word[i];
            if(!node->containskey(ch))
            {
                node->put(ch,new trie());
            }
            node=node->get(ch);
        }
        node->setEnd();
    }

    bool searchPattern(string word,string &ans)
    {
        trie* node=root;
        for(int i=0;i<word.length();i++)
        {
            char ch=word[i];
            ans.push_back(ch);
            if(!node->containskey(ch))
            {
                return false;
            }
            node=node->get(ch);
            if(node->isEnd()) return true;
        }

        return false;
    }
};

int main()
{
    string dictionary[] = {"cat","bat","rat"};
    string sentence = "the cattle was rattled by the battery";
    TrieImplimentation t;
    for(auto i:dictionary)
    {
        t.insert(i);
    }

    stringstream ss(sentence);
    vector<string>temp,ansh;
    string s;
    stringstream ss(sentence);
    while(getline(ss,s,' '))
    temp.push_back(s);

    for(auto i:temp)
    {
        string s1;
        if(t.searchPattern(i,s1))
        {
            ansh.push_back(s1);
        }
        else
        {
            ansh.push_back(i);
        }
    }

}