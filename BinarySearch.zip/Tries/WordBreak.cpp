#include<bits/stdc++.h>
using namespace std;

struct Trie
{
    Trie* links[26];
    bool flag=false;

    bool containsKey(char ch)
    {
        return links[ch-'a']!=NULL;
    }

    void put(char ch,Trie t)
    {
        links[ch-'a']=t;
    }

    Trie* get(char ch)
    {
        return links[ch-'a'];
    }

    bool isEnd()
    {
        return flag;
    }

    void setEnd()
    {
        flag=true;
    }
}

class TrieImplimentation
{
    Trie* root;
    TrieImplimentation()
    {
        root=new Trie();
    }

    void insert(string word)
    {
        Trie* node=root;

        for(int i=0;i<word.size();i++)
        {
            if(!node->containsKey(word[i]))
                node->put(word[i],new Trie());

            node=node->get(word[i]);
        }
        node->setEnd();
    }

    bool search(string word)
    {
        Trie* node=root;
        for(int i=0;i<word.size();i++)
        {
            if(!node->containsKey(word[i]))
                return false;

            node=node->get(word[i]);
        }

        if(node->isEnd())
        return true;

        return false;
    }
}

bool dfs(string s,int start,TrieImplimentation* t)
{
    if(start==s.size())
    return 1;

    TrieImplimentation* node=t;

    for(int i=0;i<s.length();i++)
    {
        if(!node->links[s[i]-'a'])
        return 0;

        node=node->links[s[i]-'a'];

        if(node->isEnd())
        {
            if(dfs(s,start+1,t))
            return 1;
        }
    }

    return 0;
}

int main()
{
   TrieImplimentation* t=new TrieImplimentation();
   vector<string>vs{"sai","mani","kanta"};
   string s="saimanikanta";

   for(auto i:vs)
   t->insert(i);

   cout<<dfs(s,0,t);

}