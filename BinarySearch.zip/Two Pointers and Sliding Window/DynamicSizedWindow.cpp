#include<bits/stdc++.h>
using namespace std;

int main()
{
    vector<int>a{-1,4,5,1,-2};
    int targetSum=5;
    int l=0;
    int r=0;
    int sum=0;
    int maxLen=0;
    int rans=0;
    int lans=0;
    while(r<a.size())
    {
        sum=sum+a[r];

        while(sum>targetSum)
        {
            sum=sum-a[l];
            l++;
        }

        if(sum<targetSum)
        {
            if(maxLen<r-l+1)
            {
                maxLen=r-l+1;
                rans=r;
                lans=l;
            }
        }

        r++;
    }

    cout<<maxLen<<" "<<lans<<" "<<rans;
}