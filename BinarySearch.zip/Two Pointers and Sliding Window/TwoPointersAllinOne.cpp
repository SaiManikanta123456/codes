#include<bits/stdc++.h>
using namespace std;

int longestSubstringWithUniqueCharecters(string s)
{
    unordered_map<char,int>mp;
    int len=s.length();
    int r=0;
    int l=0;
    int maxLen=0;
    while(r<len)
    {
        mp[s[r]]++;
        while(mp[s[r]]>1)
        {
            mp[s[l]]--;
            l++;
        }

        maxLen=max(maxLen,r-l+1);
        r++;
    }

    return maxLen;
}

int longestSubstringWithAtMostKUniqueCharecters(string s,int k)
{
    unordered_map<char,int>mp;
    int len=s.length();
    int r=0;
    int l=0;
    int maxLen=0;
    while(r<len)
    {
        mp[s[r]]++;
        while(mp.size()>k)
        {
            mp[s[l]]--;
            if(mp[s[l]]==0)
            mp.erase(s[l]);
            l++;
        }

        if(mp.size()==k) //condition comes when we need exactly k unique characters
        maxLen=max(maxLen,r-l+1);

        r++;
    }

    return maxLen;
}

int longestSubarraySumLessThanEqualToTarget(vector<int> &a,int target)
{
    int r=0;
    int l=0;
    int maxLen=0;
    int s=0;

    while(r<a.size())
    {
        s=s+a[r];

        while(s>target)
        {
            s=s-a[l];
            l++;
        }

        maxLen=max(maxLen,r-l+1);
        //c=c+(r-l+1); if ask for count subarrays 

        r++;
    }
    return maxLen;
    //return c; if ask for count subarrays
}
int main()
{
    // string s="abcabcbb";
    // cout<<longestSubstringWithUniqueCharecters(s);

    // string s="aaaac";
    // int k=3;
    // cout<<longestSubstringWithAtMostKUniqueCharecters(s,k); //exactly unique charecters

    vector<int>a{1,1,1,1,2,2,4};
    int target=4;
    cout<<longestSubarraySumLessThanEqualToTarget(a,target); //  sum <= target
}