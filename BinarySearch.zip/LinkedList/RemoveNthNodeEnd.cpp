#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

void removeNthNodeBrute(Node* head,int n)
{
    Node* temp=head;
    int len=0;
    while(temp)
    {
        len++;
        temp=temp->next;
    }

    int k=len-n+1;

    Node* node=head;
    for(int i=1;i<=k-2;i++)
    {
        node=node->next;
    }

    node->next=node->next->next;

}

int main() {

    Node* head1 = new Node(1);
    head1->next = new Node(2);
    head1->next->next = new Node(3);
    head1->next->next->next = new Node(4);
    head1->next->next->next->next = new Node(5);

    removeNthNodeBrute(head1,2);
    printList(head1);
}