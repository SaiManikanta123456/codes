#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

Node* reverse(Node* root)
{
    Node* temp=root;
    Node* prev=NULL;

    while(temp!=NULL)
    {
        Node* front=temp->next;
        temp->next=prev;

        prev=temp;
        temp=front;
    }

    return prev;
}

int main() {

    Node* head = new Node(1);
    head->next = new Node(2);
    head->next->next = new Node(3);
    head->next->next->next = new Node(2);
    head->next->next->next->next = new Node(4);

    // Node* reversed=reverse(head);

    // printList(reversed);

    Node* slow=head;
    Node* fast=head;

    while(fast->next!=NULL && fast->next->next!=NULL)
    {
        slow=slow->next;
        fast=fast->next->next;
    }

    Node* newHead=reverse(slow->next);

    Node* first=head;
    Node* second=newHead;

    while(second!=NULL)
    {
        if(first->data != second->data)
        {
            reverse(newHead);
            cout<<"false"<<endl;
            printList(head);
            exit(9);
        }

        first=first->next;
        second=second->next;
    }

    reverse(newHead);
    cout<<"True"<<endl;

    printList(head);
}