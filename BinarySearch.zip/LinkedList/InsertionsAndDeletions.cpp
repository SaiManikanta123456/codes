#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

Node* insertAtBegin(Node* head,int k)
{
    Node* new_node=new Node(k);
    new_node->next=head;
    return new_node;
}

Node* insertAtEnd(Node* head,int k)
{
    Node* temp=head;
    while(temp->next!=NULL)
    temp=temp->next;

    Node* new_node=new Node(k);
    temp->next=new_node;

    return head;
}

Node* insertAtK(Node* head,int k,int pos)
{
    Node* new_node=new Node(k);
    Node* temp=head;

    while(pos-1)
    {
        temp=temp->next;
        pos--;
    }
    new_node->next=temp->next;
    temp->next=new_node;

    return head;
}

Node* deleteAtBegin(Node* head)
{
    Node* temp=head;
    head=head->next;

    return head;
}

Node* deleteAtEnd(Node* head)
{
    Node* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }

    temp->next=NULL;

    return head;
}

Node* deleteAtK(Node* head,int pos)
{
    Node* temp=head;
    Node* prev;
    for(int i=1;i<pos-1;i++)
    {
        temp=temp->next;
    }
    temp->next=temp->next->next;

    return head;
}

int main() {

    Node* head = new Node(1);
    head->next = new Node(2);
    head->next->next = new Node(3);
    head->next->next->next = new Node(4);
    head->next->next->next->next = new Node(5);

    
    // Node* t=insertAtBegin(head,0);
    // printList(t);

    // Node* t=insertAtEnd(head,6);
    // printList(t);

    // Node* t=insertAtK(head,100,3);
    // printList(t);

    // Node* t=deleteAtBegin(head);
    // printList(t);

    // Node* t=deleteAtEnd(head);
    // printList(t);

    Node* t=deleteAtK(head,3);
    printList(t);
}