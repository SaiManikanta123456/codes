#include<bits/stdc++.h>
using namespace std;

struct Node {
    int data;
    Node* next;
    
    Node(int val) : data(val), next(NULL) {}
};

void printList(Node* head)
{
    Node* temp=head;
    while(temp)
    {
        cout<<temp->data<<" ";
        temp=temp->next;
    }
}

void sort012brute(Node* root)
{
    int c0=0,c1=0,c2=0;
    Node* temp=root;
    while(temp!=NULL)
    {
        if(temp->data==0)
        c0++;
        else if(temp->data==1)
        c1++;
        else
        c2++;

        temp=temp->next;
    }

    Node* node=root;
    while(node!=NULL)
    {
        if(c0)
        {
            node->data=0;
            c0--;
        }
        else if(c1)
        {
            node->data=1;
            c1--;
        }
        else
        {
            node->data=2;
            c2--;
        }

        node=node->next;
    }

    printList(root);
}

void sort012optimal(Node* root)
{
    Node* zeroNode=new Node(-1);
    Node* oneNode=new Node(-1);
    Node* twoNode=new Node(-1);

    Node* zero=zeroNode;
    Node* one=oneNode;
    Node* two=twoNode;

    Node* temp=root;

    while(temp!=NULL)
    {
        if(temp->data==0)
        {
            zero->next=temp;
            zero=zero->next;
        }
        else if(temp->data==1)
        {
            one->next=temp;
            one=one->next;
        }
        else
        {
            two->next=temp;
            two=two->next;
        }

        temp=temp->next;
    }

    if(oneNode->next!=NULL)
    {
        zero->next=oneNode->next;
    }
    else
    {
        zero->next=twoNode->next;
    }

    one->next=twoNode->next;
    two->next=NULL;

    printList(zeroNode->next);
}

int main() {

    Node* root = new Node(1);
    root->next = new Node(2);
    root->next->next = new Node(0);
    root->next->next->next=new Node(0);
    root->next->next->next->next=new Node(1);

    sort012brute(root);
    sort012optimal(root);
}