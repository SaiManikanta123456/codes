#include<bits/stdc++.h>
using namespace std;

void brute(int ind,set<vector<int>> &ans,vector<int> &ds,vector<int>&a,int target,int sum,int n)
{
    if(ind==n)
    {
        if(sum==target)
        {
            sort(ds.begin(),ds.end());
            ans.insert(ds);
            return;
        }
        return;
    }

    ds.push_back(a[ind]);
    brute(ind+1,ans,ds,a,target,sum+a[ind],n);
    ds.pop_back();

    brute(ind+1,ans,ds,a,target,sum,n);
}

void optimal(int ind,vector<vector<int>> &ans,vector<int> &ds,vector<int>&a,int target,int sum,int n)
{
    if(target==0)
    {
        ans.push_back(ds);
        return;
    }

    for(int i=ind;i<n;i++)
    {
        if(i>ind &&a[i-1]==a[i])
        continue;
        if(a[i]>target)
        break;
        ds.push_back(a[i]);
        optimal(i+1,ans,ds,a,target-a[i],sum,n);
        ds.pop_back();
    }
}

int main()
{
    vector<int>a{10,1,2,7,6,1,5};
    sort(a.begin(),a.end());
    int target=8;

    // set<vector<int>>ans;
    // vector<int>ds;

    // brute(0,ans,ds,a,target,0,a.size());

    // for(auto i:ans)
    // {
    //     for(auto j:i)
    //     {
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }

    vector<vector<int>>ans;
    vector<int>ds;
    optimal(0,ans,ds,a,target,0,a.size());
     for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}