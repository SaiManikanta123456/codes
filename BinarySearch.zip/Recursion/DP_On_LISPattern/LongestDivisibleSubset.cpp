#include<bits/stdc++.h>
using namespace std;

void LDS(vector<int> &a,vector<int> &ans,vector<int> &temp,int n,int ind,int prev_ind)
{
    if(ind==n)
    {
        if(ans.size() > temp.size())
        {
            temp=ans;
        }
        return;
    }

    LDS(a,ans,temp,n,ind+1,prev_ind);

    if(prev_ind==-1 || a[ind]%a[prev_ind]==0)
    {
        ans.push_back(a[ind]);
        LDS(a,ans,temp,n,ind+1,ind);
        ans.pop_back();
    }
}

void LargestDivisibleSubset(vector<int> &a)
{
    int n=a.size();
    vector<int>ans,temp;
    LDS(a,ans,temp,n,0,-1);
    for(auto i:temp)
    cout<<i<<" ";
}

int main()
{
    vector<int>a{16,8,2,4,1,7,14,35};
    sort(a.begin(),a.end());
    LargestDivisibleSubset(a);
}