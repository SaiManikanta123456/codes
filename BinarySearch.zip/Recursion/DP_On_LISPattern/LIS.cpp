#include<bits/stdc++.h>
using namespace std;

int LisHelper(vector<int> &a,int prev_ind,int ind,int n,vector<vector<int>> &dp)
{
    if(ind == n)
    return 0;

    if(dp[ind][prev_ind+1]!=-1)
        return dp[ind][prev_ind+1];
    
    int NotTake_len=0+LisHelper(a,prev_ind,ind+1,n,dp);

    int Take_len=0;

    if(prev_ind==-1 || a[ind]>a[prev_ind])
    {
        Take_len=1+LisHelper(a,ind,ind+1,n,dp);
    }

    return dp[ind][prev_ind+1]=max(NotTake_len,Take_len);
}

void LIS(vector<int> &a)
{
    int n=a.size();
    //since pre_ind is starting drom -1 to n-1, but we cannot start index from -1, so we are moving indexes to 0 to n
    vector<vector<int>>dp(n,vector<int>(n+1,-1));
    cout<<LisHelper(a,-1,0,n,dp)<<endl;
    for(auto i:dp)
    {
        for(auto j:i)
        {
            cout<<j<<"  ";
        }
        cout<<endl;
    }

    
}

int main()
{
    vector<int>a{2,4,5,6,7,8,9,1,0};
    int n=a.size();
    //since pre_ind is starting drom -1 to n-1, but we cannot start index from -1, so we are moving indexes to 0 to n
    vector<vector<int>>dp(n+1,vector<int>(n+1,0));
    for(int ind=n-1;ind>=0;ind--)
    {
        for(int prev_ind=ind-1;prev_ind>=-1;prev_ind--)
        {
            int ntake=dp[ind+1][prev_ind+1];
            int take=0;
            if(prev_ind==-1 || a[ind]>a[prev_ind])
            {
                take=1+dp[ind+1][ind+1];
            }

            dp[ind][prev_ind+1]=max(take,ntake);
        }
    }
    cout<<dp[0][0]<<endl;
    for(auto i:dp)
    {
        for(auto j:i)
        {
            cout<<j<<"  ";
        }
        cout<<endl;
    }
    cout<<endl;
    // LIS(a);
    vector<int>ans;
    int ind=0,prev_ind=-1;
    while(ind < n)
    {
        int ntake=dp[ind+1][prev_ind+1];
        int take=0;
        if(prev_ind==-1 || a[ind]>a[prev_ind])
        take=dp[ind+1][ind+1];

        if(take>=ntake && (prev_ind==-1 || a[ind]>a[prev_ind]))
        {
            ans.push_back(a[ind]);
            prev_ind=ind;
            ind++;
        }
        else
        {
            ind++;
        }
    }

    for(auto i:ans)
    cout<<i<<" ";
}