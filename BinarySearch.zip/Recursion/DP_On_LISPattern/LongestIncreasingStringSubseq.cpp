#include<bits/stdc++.h>
using namespace std;

static bool c(string &a,string &b)
{
    return a.length()<b.length();
}

bool stringcheck(string &a,string &b)
{
    if (b.length() != a.length() + 1)
        return false;

    int i = 0, j = 0;
    while (i < a.length() && j < b.length())
    {
        if (a[i] == b[j])
        {
            i++;
        }
        j++;
    }
    return i == a.length();
}

int helper(vector<string>words,int n,int ind,int prev_ind)
{
    if(ind==n)
    {
        return 0;
    }

    int notTake=helper(words,n,ind+1,prev_ind);
    int take=0;

    if(prev_ind==-1 || stringcheck(words[prev_ind],words[ind]))
    {
        take=1+helper(words,n,ind+1,ind);
    }

    return max(notTake,take);
}

void LongestIncreasingSubSeq(vector<string>words)
{
    int n=words.size();
    cout<<helper(words,n,0,-1);
}

int main()
{
    vector<string>words{"a","ab","abc","abcd","ax","axy","axyz"};
    sort(words.begin(),words.end(),c);
    LongestIncreasingSubSeq(words);
}