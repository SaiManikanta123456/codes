#include <bits/stdc++.h>
using namespace std;

int ninjaHelper(int days,int lastTask,int n,int m,vector<vector<int>> &tasks)
{
    if(days==0)
    {
        int maxi=0;
        for(int i=0;i<=2;i++)
        {
            if(i!=lastTask)
            {
                maxi=max(maxi,tasks[0][i]);
            }
        }
        return maxi;
    }

    int maxi=0;

    for(int i=0;i<=2;i++)
    {
        if(i!=lastTask)
        {
            int points=tasks[days][i]+ninjaHelper(days-1,i,n,m,tasks);
            maxi=max(maxi,points);
        }
    }

    return maxi;
}

void ninja(vector<vector<int>>tasks)
{
    int n=tasks.size();
    int m=tasks[0].size();
    int days=n;
    cout<<ninjaHelper(days-1,3,n,m,tasks);
}

int main()
{
    vector<vector<int>>tasks{
        {2,1,3},
        {3,4,6},
        {10,1,6},
        {8,3,7}
    };

    ninja(tasks);
}