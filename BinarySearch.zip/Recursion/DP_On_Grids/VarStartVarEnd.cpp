#include <bits/stdc++.h>
using namespace std;

int maxFallingPathHelper(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(i==n-1)
    {
        return grid[i][j];
    }

    if(j<0 || j>m-1 || j<n-1)
    {
        return -1e9;
    }

    if(dp[i][j]!=-1)
        return dp[i][j];
    
        
    int q=grid[i][j]+maxFallingPathHelper(i+1,j-1,n,m,grid,dp);
    int w=grid[i][j]+maxFallingPathHelper(i+1,j,n,m,grid,dp);
    int e=grid[i][j]+maxFallingPathHelper(i+1,j+1,n,m,grid,dp);

    return dp[i][j]=max(e,max(q,w));
}

void maxFallingPath()
{
    vector<vector<int>>grid{
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    int n=grid.size();
    int m=grid[0].size();
    vector<vector<int>>dp(n+1,vector<int>(m+1,-1));
    int maxi=0;
    for(int j=0;j<m;j++)
    {
        maxi=max(maxi,maxFallingPathHelper(0,j,n,m,grid,dp));
    }

    cout<<maxi;
}

int minFallingPathHelper(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(i==n-1)
    {
        return grid[n-1][j];
    }

    if(j<0 || j>m-1)
    {
        return 1e9;
    }

    if(dp[i][j]!=-1)
    return dp[i][j];

    int p=minFallingPathHelper(i+1,j,n,m,grid,dp);
    int q=minFallingPathHelper(i+1,j+1,n,m,grid,dp);
    int r=minFallingPathHelper(i+1,j-1,n,m,grid,dp);

    return dp[i][j]=min(p,min(q,r));
}

void minFallingPath()
{
    vector<vector<int>>grid{
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    int n=grid.size();
    int m=grid[0].size();
    vector<vector<int>>dp(n+1,vector<int>(m+1,-1));
    int mini=1e9;
    for(int j=0;j<m;j++)
    {
        mini=min(mini,minFallingPathHelper(0,j,n,m,grid,dp));
    }

    cout<<mini;
}

int main()
{
    // maxFallingPath();
    minFallingPath();
}