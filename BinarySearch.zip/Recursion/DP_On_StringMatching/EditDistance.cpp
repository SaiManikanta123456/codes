#include <bits/stdc++.h>
using namespace std;

int MinDist(int i,int j,string s1,string s2,int n,int m,vector<vector<int>> &dp)
{
    if(i<0)
    return j+1;

    if(j<0)
    return i+1;

    if(dp[i][j]!=-1)
    return dp[i][j];

    if(s1[i]==s2[j])
    return dp[i][j]=0+MinDist(i-1,j-1,s1,s2,n,m,dp);

    return dp[i][j]=min({1+MinDist(i,j-1,s1,s2,n,m,dp),1+MinDist(i-1,j,s1,s2,n,m,dp),1+MinDist(i-1,j-1,s1,s2,n,m,dp)}); //insert,delete,replace
}

int main()
{
    string s1="horse";
    string s2="ros";
    int n=s1.length();
    int m=s2.length();

    vector<vector<int>>dp(n,vector<int>(m,-1));

    cout<<MinDist(n-1,m-1,s1,s2,n,m,dp);
}