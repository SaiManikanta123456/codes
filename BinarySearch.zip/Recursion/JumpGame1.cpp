#include<bits/stdc++.h>
using namespace std;

bool jumpgame(vector<int> &a,int start,int end,vector<int> &dp)
{
    if(start==end)
    return true;

    if(a[start]==0)
    return false;

    if(dp[start]!= -1)
    return dp[start];

    for(int i=1;i<=a[start];i++)
    {
        if(start+i<=end && jumpgame(a,start+i,end,dp))
            return dp[start]=true;
    }

    return dp[start]=false;
}

int main()
{
    vector<int>a{1,2,4,1,1,0,2,5};
    vector<int>dp(a.size(),-1);
    cout<<jumpgame(a,0,a.size()-1,dp);
}