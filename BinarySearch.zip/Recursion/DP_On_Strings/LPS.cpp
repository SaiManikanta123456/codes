#include <bits/stdc++.h>
using namespace std;

int LPS(string &s1, string &s2, int ind1, int ind2, vector<vector<int>> &dp) {
    if (ind1 == 0 || ind2 == 0) {
        return 0;
    }

    if (dp[ind1][ind2] != -1)
        return dp[ind1][ind2 ];

    if (s1[ind1 - 1] == s2[ind2 - 1]) {
        dp[ind1][ind2] = 1 + LPS(s1, s2, ind1 - 1, ind2 - 1, dp);
    } 
    else {
        dp[ind1][ind2] = max(LPS(s1, s2, ind1 - 1, ind2, dp), LPS(s1, s2, ind1, ind2 - 1, dp));   
    }

    return dp[ind1][ind2];
}

int main()
{
    string s1 = "babad";
    string s2 = s1;
    reverse(s2.begin(), s2.end());

    int n = s1.length();
    int m = s2.length();

    vector<vector<int>> dp(n + 1, vector<int>(m + 1, -1));

    cout << LPS(s1, s2, n, m, dp) << endl;

    // Printing dp table
    for(int i = 0; i <= n; i++) {
        for(int j = 0; j <= m; j++) {
            cout << dp[i][j] << " "; 
        }
        cout << endl;
    }
}
