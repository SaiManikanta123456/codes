#include<bits/stdc++.h>
using namespace std;

void f(vector<int> &a,int n,vector<vector<int>> &ans,vector<int> &ds,vector<int> &freq)
{
    if(ds.size()==n)
    {
        ans.push_back(ds);
        return;
    }

    for(int i=0;i<n;i++)
    {
        if(!freq[i])
        {
            freq[i]=1;
            ds.push_back(a[i]);
            f(a,n,ans,ds,freq);
            freq[i]=0;
            ds.pop_back();
        }
    }
}

int main()
{
    vector<int>a{1,2,3,4};
    vector<vector<int>>ans;
    vector<int>ds;
    vector<int>freq(a.size(),0);
    f(a,a.size(),ans,ds,freq);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}