#include <bits/stdc++.h>
using namespace std;

int gridUniquePaths1Helper(int row,int col,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(row==0 && col==0)
    return 1;

    if(row<0 || col<0)
    return 0;

    if(dp[row][col]!=-1)
    return dp[row][col];

    int up=gridUniquePaths1Helper(row-1,col,n,m,grid,dp);
    int down=gridUniquePaths1Helper(row,col-1,n,m,grid,dp);

    return dp[row][col]=up+down;
}

int gridUniquePaths1HelperTab(int row,int col,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    dp[0][0]=1;

    for(int i=0;i<=n-1;i++)
    {
        for(int j=0;j<=m-1;j++)
        {
            if(i==0 && j==0)continue;

            int up=0;
            if(i>0)
            up=dp[i-1][j];
            int left=0;
            if(j>0)
            left=dp[i][j-1];

            dp[i][j]=up+left;
        }
    }

    return dp[n-1][m-1];
}

int gridUniquePaths2HelperTab(int row,int col,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    dp[0][0]=1;

    for(int i=0;i<=n-1;i++)
    {
        for(int j=0;j<=m-1;j++)
        {
            if(i==0 && j==0)continue;

            if(grid[i][j]==-1){
            dp[i][j]=0;
            continue;
            }

            int left=0,up=0;

            if(i>0)
            up=dp[i-1][j];
            else
            up=0;

            if(j>0)
            left=dp[i][j-1];
            else
            left=0;

            dp[i][j]=up+left;
        }
    }

    return dp[n-1][m-1];
}

int minPath(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(i==0 && j==0)
    return grid[i][j];

    if(i<0 || j<0)
    return 1e9;

    if(dp[i][j] != -1)
    return dp[i][j];

    int up=grid[i][j]+minPath(i-1,j,n,m,grid,dp);
    int left=grid[i][j]+minPath(i,j-1,n,m,grid,dp);

    return dp[i][j]=min(up,left);
}

int minPathTab(int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    dp[0][0]=grid[0][0];

    for(int i=0;i<=n-1;i++)
    {
        for(int j=0;j<=m-1;j++)
        {
            if(i==0 && j==0)
            continue;

            int left=grid[i][j],up=grid[i][j];
            if(i>0)
            {
                up=up+dp[i-1][j];
            }
            else
            {
                up=1e9;
            }

            if(j>0)
            {
                left=left+dp[i][j-1];
            }
            else
            {
                left=1e9;
            }

            dp[i][j]=min(left,up);
        }
    }
    return dp[n-1][m-1];
}

int fixedStartVariableEnd(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(i>n-1 || j<0 || j>m-1)
    return -1e9;

    if(i==n-1)
    return grid[n-1][j];

    if(dp[i][j]!=-1)
    return dp[i][j];

    int p=grid[i][j]+fixedStartVariableEnd(i+1,j-1,n,m,grid,dp);
    int q=grid[i][j]+fixedStartVariableEnd(i+1,j,n,m,grid,dp);
    int r=grid[i][j]+fixedStartVariableEnd(i+1,j+1,n,m,grid,dp);

    return dp[i][j]=max({p,q,r});
}

int fixedStartVariableEndTab(int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    for(int i=0;i<m;i++)
    {
        dp[n-1][i]=grid[n-1][i];
    }

    for(int i=n-2;i>=0;i--)
    {
        for(int j=0;j<=m-1;j++)
        {
            int p=grid[i][j]+dp[i+1][j];

            int q=0;
            if(j>0)
            q=grid[i][j]+dp[i+1][j-1];
            else
            q=-1e9;

            int r=0;
            if(j+1<m)
            r=grid[i][j]+dp[i+1][j+1];
            else
            r=-1e9;

            dp[i][j]=max({p,q,r});
        }
    }

    int ans=-1e9;
    for(int i=0;i<m;i++)
    {
        ans=max(ans,dp[0][i]);
    }

    return ans=dp[0][0];
}

int variableStartFixedEnd(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp,int tr,int tc)
{
    if(j<0 || j>m-1 || i>n-1)
    return -1e9;

    if(i==tr && j==tc)
    return grid[tr][tc];

    if(dp[i][j]!=-1)
    return dp[i][j];

    int p=grid[i][j]+variableStartFixedEnd(i+1,j,n,m,grid,dp,tr,tc);
    int q=0;
    if(j+1<m)
    q=grid[i][j]+variableStartFixedEnd(i+1,j+1,n,m,grid,dp,tr,tc);
    else
    q=-1e9;
    int r=0;
    if(j>0)
    r=grid[i][j]+variableStartFixedEnd(i+1,j-1,n,m,grid,dp,tr,tc);
    else
    r=-1e9;
    
    return dp[i][j]=max({p,q,r});
}

int variableStartFixedEndTab(int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp,int tr,int tc)
{
    dp[tr][tc]=grid[tr][tc];

    for(int i=tr-1;i>=0;i--)
    {
        for(int j=0;j<=m-1;j++)
        {
            int p=0;
            if(i+1<n)
            p=grid[i][j]+dp[i+1][j];
            else
            p=-1e9;
            int q=0;
            if(j>0)
            q=grid[i][j]+dp[i+1][j-1];
            else
            q=-1e9;
            int r=0;
            if(j+1<m)
            r=grid[i][j]+dp[i+1][j+1];
            else
            r=-1e9;

            dp[i][j]=max({p,q,r});
        }
    }

    int ans=-1e9;
    for(int j=0;j<m;j++)
    {
        ans=max(ans,dp[0][j]);
    }

    return ans;
}

int variableStartFixedEndLastRow(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(j<0 || j+1>m || i+1>n)
    return -1e9;

    if(i==n-1)
    return grid[i][j];

    if(dp[i][j]!=-1)
    return dp[i][j];

    int p=grid[i][j]+variableStartFixedEndLastRow(i+1,j,n,m,grid,dp);
    int q=grid[i][j]+variableStartFixedEndLastRow(i+1,j-1,n,m,grid,dp);
    int r=grid[i][j]+variableStartFixedEndLastRow(i+1,j+1,n,m,grid,dp);

    return dp[i][j]=max({p,q,r});
}

int variableStartFixedEndLastRowTab(int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    for(int i=0;i<m;i++)
    {
        dp[0][i]=grid[0][i];
    }

    for(int i=1;i<=n-1;i++)
    {
        for(int j=0;j<=m-1;j++)
        {
            int p=0,q=0,r=0;
            p=grid[i][j]+dp[i-1][j];
            if(j>0)
            q=grid[i][j]+dp[i-1][j-1];
            else
            q=-1e9;
            if(j+1<m)
            r=grid[i][j]+dp[i-1][j+1];
            else
            r=-1e9;

            dp[i][j]=max({p,q,r});
        }
    }

    int ans=-1e9;
    for(int i=0;i<m;i++)
    {
        ans=max(ans,dp[n-1][i]);
    }

    return ans;
}

int main()
{
    vector<vector<int>>grid{
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    // int n=grid.size();
    // int m=grid[0].size();
    // vector<vector<int>>dp(n+1,vector<int>(m+1,-1));
    // cout<<gridUniquePaths1Helper(n-1,m-1,n,m,grid,dp);
    // cout<<gridUniquePaths1HelperTab(n-1,m-1,n,m,grid,dp);
    vector<vector<int>>grid1{
        {1,2,3},
        {4,-1,6},
        {7,8,9}
    };
    // cout<<gridUniquePaths2HelperTab(n-1,m-1,n,m,grid1,dp);

    // cout<<minPath(n-1,m-1,n,m,grid,dp);
    // cout<<minPathTab(n,m,grid,dp);

    // cout<<fixedStartVariableEnd(0,0,n,m,grid,dp);
    // vector<vector<int>>dp(n,vector<int>(m,-1));
    // cout<<fixedStartVariableEndTab(n,m,grid,dp);
    vector<vector<int>>grid2{
        {1, 2, 3, 4},
        {5, 6, 7, 8},
        {9, 10,11,12},
        {13,14,15,16}
    };

    int n=grid2.size();
    int m=grid2[0].size();
    vector<vector<int>>dp(n,vector<int>(m,-1));

    //memozation
    // int ans=-1e9;
    // for(int j=0;j<m;j++)
    // {
    //     ans=max(ans,variableStartFixedEnd(0,j,n,m,grid2,dp,3,0));
    // }
    // cout<<ans;

    //Tabulation
    // cout<<variableStartFixedEndTab(n,m,grid2,dp,3,0);

    //memozation
    // int ans=-1e9;
    // for(int j=0;j<m;j++)
    // {
    //     ans=max(ans,variableStartFixedEndLastRow(0,j,n,m,grid2,dp));
    // }
    // cout<<ans;

    //Tabulation
    cout<<variableStartFixedEndLastRowTab(n,m,grid2,dp);

}