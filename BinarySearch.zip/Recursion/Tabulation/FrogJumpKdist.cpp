#include <bits/stdc++.h>
using namespace std;

int Mem(int ind,vector<int> &a,int n,int k,vector<int> &dp)
{
    if(ind==0)
    return 0;

    if(ind < 0)
    return 1e9;

    if(dp[ind]!=-1)
    return dp[ind];

    int minSteps=1e9;

    for(int i=1;i<=k;i++)
    {
        if(ind-i >= 0)
        {
            int ans=Mem(ind-i,a,n,k,dp)+abs(a[ind]-a[ind-i]);
            minSteps=min(minSteps,ans);
        }
    }

    return dp[ind]=minSteps;
}

int Tab(vector<int> &a,int n,int k,vector<int> &dp)
{
    dp[0]=0;

    for(int i=1;i<=n-1;i++)
    {
        int minsteps=1e9;
        for(int j=1;j<=k;j++)
        {
            if(i-j >= 0)
            {
                int ans=dp[i-j]+abs(a[i]-a[i-j]);
                minsteps=min(ans,minsteps);
            }
        }
        dp[i]=minsteps;
    }

    return dp[n-1];
}

int main()
{
    vector<int> a{30, 10, 60, 10, 60, 50};
    int n = a.size();
    int k = 2;
    vector<int>dp(n,-1);
    // cout<<Mem(n-1,a,n,k,dp);
    cout<<Tab(a,n,k,dp);
}