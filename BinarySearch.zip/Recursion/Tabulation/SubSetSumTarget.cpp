#include <bits/stdc++.h>
using namespace std;

bool memo(int ind,int n,int target,vector<int> &a,vector<vector<int>> &dp)
{
    if(target==0)
    return 1;

    if(ind==n-1)
    return a[n-1]==target;

    if(dp[ind][target]!=-1)
    return dp[ind][target];

    bool nt=memo(ind+1,n,target,a,dp);
    bool t=false;
    if(target-a[ind] >= 0)
    t=memo(ind+1,n,target-a[ind],a,dp);

    return dp[ind][target]=nt | t;
}

bool Tab(int n,int target,vector<int> &a,vector<vector<bool>> &dp)
{
    for(int i=0;i<n;i++)
    {
        dp[i][0]=true;
    }

    if(a[0]<=target)
    dp[0][a[0]]=true;

    for(int i=1;i<=n-1;i++)
    {
        for(int j=1;j<=target;j++)
        {
            bool noTake=dp[i-1][j];
            bool take=false;
            if(j-a[i] >= 0)
            take=dp[i-1][j-a[i]];

            dp[i][j]=take|noTake;
        }
    }

    return dp[n-1][target];
}

bool TabforminAbsDiff(int n,int target,vector<int> &a,vector<vector<bool>> &dp)
{
    for(int i=0;i<n;i++)
    dp[i][0]=true;

    dp[0][a[0]]=true;

    for(int i=1;i<=n-1;i++)
    {
        for(int j=1;j<=target;j++)
        {
            bool Ntake=dp[i-1][j];
            bool take=false;

            if(j-a[i] >= 0)
            take=dp[i-1][j-a[i]];

            dp[i][j]=take|Ntake;
        }
    }

    return dp[n-1][target];
}

int countSubSetSumTarget(int ind,vector<int> &a,int target,vector<vector<int>> &dp)
{
    if(target==0)
    return 1;

    if(ind==0)
    {
        if(target==a[ind])
        return 1;

        return 0;
    }

    if(dp[ind][target]!=-1)
    return dp[ind][target];

    int nt=countSubSetSumTarget(ind-1,a,target,dp);
    int t=0;
    if(target-a[ind] >= 0)
    t=countSubSetSumTarget(ind-1,a,target-a[ind],dp);

    return dp[ind][target]=t+nt;
}

int countSubSetSumTargetTab(int n,vector<int> &a,int target,vector<vector<int>> &dp)
{
    for(int i=0;i<n;i++)
    {
        dp[i][0]=1;
    }

    if(a[0]<=target)
    dp[0][a[0]]=1;

    for(int i=1;i<=n-1;i++)
    {
        for(int j=1;j<=target;j++)
        {
            int nt=dp[i-1][j];
            int t=0;
            if(j-a[i] >= 0)
            t=dp[i-1][j-a[i]];

            dp[i][j]=nt+t;
        }
    }

    return dp[n-1][target];
}

int main()
{
    vector<int>a{1,2,3,4};
    int target=4;
    int n=a.size();
    // vector<vector<int>>dp(n,vector<int>(target+1,-1));
    // cout<<memo(0,n,target,a,dp);
    // vector<vector<bool>>dp(n,vector<bool>(target+1,0));
    // cout<<Tab(n,target,a,dp)<<endl;

    // for(auto i:dp)
    // {
    //     for(auto j:i)
    //     {
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }

    // int totsum=0;
    // for(auto i:a)
    // totsum+=i;

    // vector<vector<bool>>dp(n,vector<bool>(totsum+1,0));
    // cout<<TabforminAbsDiff(n,target,a,dp)<<endl;

    // int mini=1e9;
    // for(int i=0;i<=totsum;i++)
    // {
    //     if(dp[n-1][i])
    //     mini=min(mini,abs((totsum-i)-i));
    // }
    // cout<<mini;

    // vector<vector<int>>dp(n,vector<int>(target+1,-1));
    // cout<<countSubSetSumTarget(n-1,a,target,dp)<<endl;

    vector<vector<int>>dp(n,vector<int>(target+1,0));
    cout<<countSubSetSumTargetTab(n,a,target,dp)<<endl;
    
}