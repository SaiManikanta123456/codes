#include <bits/stdc++.h>
using namespace std;

int Mem(int ind,vector<int> &a,int n,vector<int> &dp)
{
    if(ind==0)
    return a[ind];

    if(ind<0)
    return -1e9;

    if(dp[ind]!=-1)
    return dp[ind];

    int not_take=Mem(ind-1,a,n,dp);
    int take=-1e9;
    if(ind-1 >= 0)
    {
        take=a[ind]+Mem(ind-2,a,n,dp);
    }

    return dp[ind]=max(not_take,take);
}

int Tab(vector<int> &a,int n,vector<int> &dp)
{
    dp[0]=a[0];

    for(int i=1;i<=n-1;i++)
    {
        int not_take=dp[i-1];
        int take=-1e9;
        if(i-1 > 0)
        take=a[i]+dp[i-2];

        dp[i]=max(take,not_take);
    }

    return dp[n-1];
}

int main()
{
    vector<int>a{1,2,3,1,3,5,8,1,9};
    int n=a.size();
    vector<int>dp(n,-1);
    // cout<<Mem(n-1,a,n,dp);
    cout<<Tab(a,n,dp);
}