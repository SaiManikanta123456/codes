#include<bits/stdc++.h>
using namespace std;

void f_1(int ind,vector<int> &a,vector<vector<int>> &ans,int n,vector<int>&ds)
{
    if(ind==n)
    {
        ans.push_back(ds);
        return;
    }

    ds.push_back(a[ind]);
    f_1(ind+1,a,ans,n,ds);

    ds.pop_back();
    f_1(ind+1,a,ans,n,ds);
}

void printAllSub()
{
    vector<int>a{1,2,3};
    vector<vector<int>>ans;
    vector<int>ds;
    f_1(0,a,ans,a.size(),ds);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}

void f_2(int ind,vector<int> &a,vector<vector<int>> &ans,int n,vector<int>&ds,int target)
{
    if(ind==n)
    {
        if(target==0){
        ans.push_back(ds);
        return;
        }
        return;
    }

    if(a[ind]<=target){
    ds.push_back(a[ind]);
    f_2(ind+1,a,ans,n,ds,target-a[ind]);

    ds.pop_back();
    }
    f_2(ind+1,a,ans,n,ds,target);
}

void printAllSubSeqWithTarget()
{
    vector<int>a{1,2,3};
    vector<vector<int>>ans;
    vector<int>ds;
    f_2(0,a,ans,a.size(),ds,3);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}

void merge(vector<int>&a,int low,int mid,int high)
{

    vector<int>temp;
    int left=low;
    int right=mid+1;

    while(left<=mid && right<=high)
    {
        if(a[left]<=a[right])
        {
            temp.push_back(a[left]);
            left++;
        }
        else
        {
            temp.push_back(a[right]);
            right++;
        }
    }

    while(left<=mid)
    {
        temp.push_back(a[left]);
        left++;
    }

    while(right<=high)
    {
        temp.push_back(a[right]);
        right++;
    }

    for(int i=low;i<=high;i++)
    {
        a[i]=temp[i-low];
    }
}

// 4035 6218 4967 0009

void mS(vector<int> &a,int low,int high)
{
    if(low==high)
    return;

    int mid=(low+high)/2;
    mS(a,low,mid);
    mS(a,mid+1,high);
    merge(a,low,mid,high);
}
void mergeSort()
{
    vector<int>a{1,2,3,0,-67};
    mS(a,0,a.size()-1);

    for(auto i:a)
    cout<<i<<" ";
}

void f_3(int ind,vector<int> &a,vector<vector<int>> &ans,int n,vector<int>&ds,int target)
{
    if(target==0)
    {
        ans.push_back(ds);
        return;
    }

    for(int i=ind;i<n;i++)
    {
        if(i!=ind && a[i]==a[i-1])
        continue;
        if(a[i]>target)
        break;
        ds.push_back(a[i]);
        f_3(i+1,a,ans,n,ds,target-a[i]);
        ds.pop_back();
    }
}

void printAllSubSeqWithTargetwithDuplicates()
{
    vector<int>a{1,1,1,2,2,3,3,3};
    vector<vector<int>>ans;
    vector<int>ds;
    f_3(0,a,ans,a.size(),ds,3);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    // printAllSubSeq(); //without dulicates;
    // printAllSubSeqWithTarget();//without dulicates;
    // printAllSubSeqWithTargetwithDuplicates();//with dulicates;
    
    // mergeSort();
}
