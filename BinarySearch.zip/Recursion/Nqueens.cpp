#include<bits/stdc++.h>
using namespace std;

bool isSafe(int row,int col,vector<string> &board,int n)
{
    int trow=row;
    int tcol=col;
    //upper dagnol
    while(row>=0 && col>=0)
    {
        if(board[row][col]=='Q')
        return false;
        row--;col--;
    }

    row=trow;
    col=tcol;

    //row
    while(col>=0)
    {
        if(board[row][col]=='Q')
        return false;
        col--;
    }

    row=trow;
    col=tcol;

    //lower diagnol
    while(row<n && col>=0)
    {
        if(board[row][col]=='Q')
        return false;
        row++;
        col--;
    }

    return true;
    
}

void queens(int n,int col,vector<string> &board,vector<vector<string>>&ans)
{
    if(col==n)
    {
        ans.push_back(board);
        return;
    }

    for(int row=0;row<n;row++)
    {
        if(isSafe(row,col,board,n))
        {
            board[row][col]='Q';
            queens(n,col+1,board,ans);
            board[row][col]='.';
        }
    }
}
int main()
{
    int n=4;
    vector<string>board(n);
    vector<vector<string>>ans;
    string s(n,'.');
    for(int i=0;i<n;i++)
    {
        board[i]=s;
    }

    queens(n,0,board,ans);

    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" "<<endl;
        }
        cout<<endl;
    }
}