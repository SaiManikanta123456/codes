#include <bits/stdc++.h>
using namespace std;

bool approch1(int ind,vector<int> &a,int target)
{
    if(ind==0)
    {
        if(target==0)
        {
            return true;
        }
    }

    bool nottake=approch1(ind-1,a,target);
    bool take=false;
    if(target>=a[ind])
    take=approch1(ind-1,a,target-a[ind]);

    return nottake || take;
}

bool approch2(int ind,vector<int> &a,int target)
{
    if(target==0)
    {
        return true;
    }
    
    if(ind==0)
    {
        return a[0]==target;
    }

    bool nottake=approch2(ind-1,a,target);
    bool take=false;
    if(target>=a[ind])
    take=approch2(ind-1,a,target-a[ind]);

    return nottake || take;
}

int main()
{
    vector<int>a{1,2,3,4};
    int target=4;
    cout<<approch1(a.size()-1,a,target);
    cout<<approch2(a.size()-1,a,target);
}