#include<bits/stdc++.h>
using namespace std;

int jumpgame2(vector<int> &a,int start,int end,vector<int> &dp)
{
    if(start==end)
    return 0;

    if(start>end)
    return INT_MAX;

    if(dp[start]!=-1)
    return dp[start];

    int ans=INT_MAX;

    for(int i=1;i<=a[start];i++)
    {
        if(start+i<=end)
        {
            int res=jumpgame2(a,start+i,end,dp);

            if(res!=INT_MAX)
            {
                ans=min(ans,res+1);
            }
        }
    }

    return dp[start]=ans;
}

int main()
{
    vector<int>a{2,3,1,4,1,1,1,2};
    vector<int>dp(a.size(),-1);
    cout<<jumpgame2(a,0,a.size()-1,dp);
}