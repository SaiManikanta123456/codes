//spinach,dark chocolate and salmon fish
#include <bits/stdc++.h>
using namespace std;

int diceThrow(int n,int m,int x)
{
    if(n==0 && x==0)
    return 1;

    if(n==0 || x<=0)
    return 0;

    int ans=0;

    for(int i=1;i<=m;i++)
    {
        ans=ans+diceThrow(n-1,m,x-i);
    }
    return ans;
}

int diceThrowTab(int n,int m,int x,vector<vector<int>> &dp)
{
    dp[0][0]=1;

    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=x;j++)
        {
            for(int k=1;k<=m;k++)
            {
                if(j-k >= 0)
                {
                    dp[i][j]=dp[i][j]+dp[i-1][j-k];
                }
            }
        }
    }

    return dp[n][x];
}

int main()
{
    int n=3,m=6,x=8;
    vector<vector<int>>dp(n+1,vector<int>(x+1,0));
    // cout<<diceThrow(n,m,x);
    cout<<diceThrowTab(n,m,x,dp);
}