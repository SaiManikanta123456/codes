#include<bits/stdc++.h>
using namespace std;

class DoubleLinkedList{
    public:

    int data;
    DoubleLinkedList* next;
    DoubleLinkedList* prev;

    DoubleLinkedList(int data1,DoubleLinkedList* next1,DoubleLinkedList* prev1)
    {
        data=data1;
        next=next1;
        prev=prev1;
    }

    DoubleLinkedList(int data1)
    {
        data=data1;
        next=nullptr;
        prev=nullptr;
    }
};


void printList(DoubleLinkedList* head)
{
    while(head)
    {
        cout<<head->data<<" ";
        head=head->next;
    }
}

DoubleLinkedList* ReverseDLL(DoubleLinkedList* head)
{
    DoubleLinkedList* temp1=head;
    stack<int>st;
    while(temp1)
    {
        st.push(temp1->data);
        temp1=temp1->next;
    }

    DoubleLinkedList* temp2=head;

    while(temp2)
    {
        temp2->data=st.top();st.pop();
        temp2=temp2->next;
    }

    return head;
}

int main()
{
    vector<int>a{1,2,3,4};

    DoubleLinkedList* list=new DoubleLinkedList(a[0]);
    DoubleLinkedList* prev=list;

    for(int i=1;i<a.size();i++)
    {
        DoubleLinkedList* temp=new DoubleLinkedList(a[i],nullptr,prev);
        prev->next=temp;
        prev=temp;
    }

    DoubleLinkedList* head=list;

    DoubleLinkedList* ans=ReverseDLL(head);

    printList(ans);
}