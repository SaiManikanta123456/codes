#include<bits/stdc++.h>
using namespace std;

class ListNode{
  public:
  
  int val;
  ListNode* next;
  
  ListNode(int val1,ListNode* node1)
  {
      val=val1;
      next=node1;
  }

  ListNode(int val1)
  {
    val=val1;
    next=nullptr;
  }
  
};

ListNode* reverse(ListNode* head)
{
    ListNode* temp=head;
    ListNode* prev=NULL;
    while(temp)
    {
        ListNode* forward=temp->next;
        temp->next=prev;
        prev=temp;
        temp=forward;
    }

    return prev;
}

ListNode* addOne(ListNode* head)
{
    if(head==NULL)
    {
        return head;
    }

    ListNode* newHead=reverse(head);

    ListNode* temp=newHead;
    ListNode* ans=new ListNode(0);
    ListNode* ans1=ans;
    int c=1;
    while(temp || c)
    {
        int s=0;

        if(temp)
        {
            s=s+temp->val;
            temp=temp->next;
        }

        s=s+c;
        c=s/10;
        ListNode* node=new ListNode(s%10);
        ans1->next=node;
        ans1=node;
    }
    return ans->next;
}

void print(ListNode* head)
{
    while(head)
    {
        cout<< head->val <<" ";
        head=head->next;
    }
}

int main()
{
    vector<int>a{1,2,3,4};
    ListNode* head=NULL;
    
    for(int i=a.size()-1;i>=0;i--)
    {
        ListNode* node=new ListNode(a[i],head);
        head=node;
    }

    // print(head);
    

    ListNode* ans=addOne(head);
    
    ListNode* ans1=reverse(ans);

    print(ans1);
}