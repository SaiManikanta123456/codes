#include<bits/stdc++.h>
using namespace std;

class ListNode{
  public:
  
  int val;
  ListNode* next;
  
  ListNode(int val1,ListNode* node1)
  {
      val=val1;
      next=node1;
  }

  ListNode(int val1)
  {
    val=val1;
    next=nullptr;
  }
  
};


ListNode* deleteHead(ListNode* head)
{
    if(head==nullptr)
    return NULL;

    ListNode* temp=head;
    head=head->next;
    delete temp;
    return head;
}

ListNode* deleteTail(ListNode* head)
{
    if(head==NULL || head->next==NULL)
        return NULL;

    ListNode* temp=head;
    while(temp->next->next!=NULL)
    {
        temp=temp->next;
    }

    delete temp->next;

    temp->next=NULL;

    return head;
}

ListNode* deleteKthElement(ListNode* head,int k)
{
    if(head==NULL)
    return NULL;

    if(k==1)
    {
        head=head->next;
        return head;
    }

    int c=1;
    ListNode* temp=head;
    ListNode* prev=NULL;

    while(temp!=NULL)
    {
        
        if(c==k)
        {
            prev->next=prev->next->next;
            delete temp;
            break;
        }
    
    prev=temp;
    temp=temp->next;
    c=c+1;
    }

    return head;
}

ListNode* deleteElementValue(ListNode* head,int element)
{
    if(head==NULL)
    return NULL;

    if(head->val==element)
    {
        head=head->next;
        return head;
    }

    ListNode* temp=head;
    ListNode* prev=NULL;

    while(temp->next!=NULL)
    {
        if(temp->val==element)
        {
            prev->next=prev->next->next;
            delete temp;
            break;
        }
        prev=temp;
        temp=temp->next;
    }

    return head;
}

ListNode* InsertBeginning(ListNode* head,int element)
{
    if(head==NULL)
    {
        return new ListNode(element);
    }
    ListNode* temp=new ListNode(element,head);

    return temp;
}

ListNode* InsertAtTail(ListNode* head,int element)
{
    if(head==nullptr)
    {
        return new ListNode(element);
    }

    ListNode* temp=head;

    while(temp->next!=nullptr)
    {
        temp=temp->next;
    }

    ListNode* node=new ListNode(element,nullptr);

    temp->next=node;

    return head;
}

ListNode* InsertAtKth(ListNode* head,int element,int pos)
{
    if(head==NULL)
    {
        return new ListNode(element);
    }

    if(pos==1)
    {
        ListNode* temp=new ListNode(element,head);
        return temp;
    }

    ListNode* temp=head;
    int c=1;
    while(temp!=NULL)
    {
        if(c==pos-1)
        {
            ListNode* node=new ListNode(element,temp->next);
            temp->next=node;
            return head;
        }
        c++;
        temp=temp->next;
        
    }    

}

void printList(ListNode* list)
{
    ListNode* temp=list;
    while(temp!=nullptr)
    {
        cout<<temp->val<<endl;
        temp=temp->next;
    }
}

int main()
{
    vector<int>a{1,2,3,4};
    ListNode* list=nullptr;
    for(int i=a.size()-1;i>=0;i--)
    {
        ListNode* temp=new ListNode(a[i],list);
        list=temp;
    }

    ListNode* head=list;
    
    // ListNode* deleteHead_result=deleteHead(head);

    // printList(deleteHead_result);

    // ListNode* deleteTail_result=deleteTail(head);

    // printList(deleteTail_result);

    // ListNode* deleteKthElement_result=deleteKthElement(head,6);

    // printList(deleteKthElement_result);

    
    // ListNode* InsertBeginning_result=InsertBeginning(head,0);

    // printList(InsertBeginning_result);

    // ListNode* InsertAtTail_result=InsertAtTail(head,5);

    // printList(InsertAtTail_result);

    ListNode* InsertAtKth_result=InsertAtKth(head,5,5);

    printList(InsertAtKth_result);
    
}


