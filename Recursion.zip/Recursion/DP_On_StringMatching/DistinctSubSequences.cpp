#include <bits/stdc++.h>
using namespace std;

// case-1:
// if charecters are matching --> you can move further or still stay on jth index to find another charecter match.

// case-2:
// if charecters are not matching --> you have to move ith index keep jth index intact, so that it may get a charecter match in future.

int countDistSubSeq(int i,int j,string s1,string s2,int n,int m,vector<vector<int>> &dp)
{
    if(j<0)
    return 1;

    if(i<0)
    return 0;

    if(dp[i][j]!=-1)
     return dp[i][j];

    if(s1[i]==s2[j])
    {
        return dp[i][j]=countDistSubSeq(i-1,j-1,s1,s2,n,m,dp)+countDistSubSeq(i-1,j,s1,s2,n,m,dp);
    }

    else
    {
        return dp[i][j]=countDistSubSeq(i-1,j,s1,s2,n,m,dp);
    }
}

int main()
{
    string s1="rabbbit";
    string s2="rabbit";

    int n=s1.length();
    int m=s2.length();

    vector<vector<int>>dp(n,vector<int>(m,-1));

    cout<<countDistSubSeq(n-1,m-1,s1,s2,n,m,dp);

}