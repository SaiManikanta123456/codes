// Given three arrays height[], width[], and length[] of size n, where height[i], width[i], and length[i] represent the dimensions of a box. 
// The task is to create a stack of boxes that is as tall as possible, but we can only stack a box on top of another box if the dimensions of the 
// 2-D base of the lower box are each strictly larger than those of the 2-D base of the higher box.


// Note:
// We can rotate a box so that any side functions as its base.
// It is also allowable to use multiple instances of the same type of box.
// The base of the lower box should be strictly larger than that of the new box we're going to place. 
// This is in terms of both length and width, not just in terms of area. So, two boxes with the same base cannot be placed one over the other.

#include <bits/stdc++.h>
using namespace std;

int boxStack(int i,vector<vector<int>> &boxes)
{
    int ans=boxes[i][2];

    for(int j=i+1;j<boxes.size();j++)
    {
        if(boxes[i][0]>boxes[j][0] && boxes[i][1]>boxes[j][1])
        {
            ans=max(ans,boxes[i][2]+boxStack(j,boxes));
        }
    }
    return ans;
}

int main()
{
    vector<int> height = {4, 1, 4, 10};
    vector<int> width = {6, 2, 5, 12};
    vector<int> length = {7, 3, 6, 32};

    vector<vector<int>>boxes;
    for(int i=0;i<height.size();i++)
    {
        int c=height[i],b=width[i],a=length[i];
        boxes.push_back({a,b,c});
        boxes.push_back({a,c,b});
        boxes.push_back({b,a,c});
        boxes.push_back({b,c,a});
        boxes.push_back({c,b,a});
        boxes.push_back({c,a,b});
    }
    sort(boxes.begin(),boxes.end(),greater<vector<int>>());

    int ans=0;
    // for(int i=0;i<boxes.size();i++)
    // {
    //     ans=max(ans,boxStack(i,boxes));
    // }

    vector<int>dp(boxes.size());
    for(int i=boxes.size()-1;i>=0;i--)
    {
        dp[i]=boxes[i][2];
        for(int j=i+1;j<boxes.size();j++)
        {
            if(boxes[i][0]>boxes[j][0] && boxes[i][1]>boxes[j][1])
            {
            dp[i]=max(dp[i],dp[i]+boxes[i][2]);
            }
        }
        ans=max(ans,dp[i]);
    }

    cout<<ans;
}