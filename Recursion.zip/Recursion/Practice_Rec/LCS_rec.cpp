#include <bits/stdc++.h>
using namespace std;

int LcsHelper(string s1,int i,string s2,int j,vector<vector<int>> &dp)
{
    if(i<0 || j<0)
    return 0;

    if(dp[i][j]!=-1)
    return dp[i][j];

    if(s1[i]==s2[j])
    return dp[i][j]=1+LcsHelper(s1,i-1,s2,j-1,dp);

    return dp[i][j]=max(LcsHelper(s1,i-1,s2,j,dp),LcsHelper(s1,i,s2,j-1,dp));
}

void LCS(string s1,string s2)
{
    int i=s1.length(),j=s2.length();
    vector<vector<int>>dp(i,vector<int>(j,-1));
    cout<<LcsHelper(s1,i-1,s2,j-1,dp)<<endl;
    vector<vector<int>>dp1(i+1,vector<int>(j+1,0));

    for(int r=1;r<=i;r++)
    {
        for(int c=1;c<=j;c++)
        {
            if(s1[r-1]==s2[c-1])
            {
                dp1[r][c]=1+dp1[r-1][c-1];
            }
            else
            {
                dp1[r][c]=max(dp1[r-1][c],dp1[r][c-1]);
            }
        }
    }
    cout<<dp1[i][j];
}

int main() {
    string s1 = "abx";
    string s2 = "abmcx";
    LCS(s1, s2);
}