#include <bits/stdc++.h>
using namespace std;

//     if(ind==0)
//     {
//         return (int)(W/wt[0])*val[0]
//     }


int knapsackHelp(vector<int>&wt,vector<int> &val,int W,int ind,vector<vector<int>> &dp)
{
    if(ind==0)
    {
        if(W-wt[ind] >= 0)
        return val[0];
        else
        return 0;
    }

    if(dp[ind][W]!=-1)
    return dp[ind][W];

    int nt=knapsackHelp(wt,val,W,ind-1,dp);
    int t=-1e9;
    if(W-wt[ind] >= 0)
    t=val[ind]+knapsackHelp(wt,val,W-wt[ind],ind-1,dp);

    return dp[ind][W]=max(t,nt);
}

int knapsackHelpTab(vector<int>&wt,vector<int> &val,int W,int ind,vector<vector<int>> &dp,int n)
{
    for(int i=wt[0];i<=W;i++)
    dp[0][i]=val[0];             //Use pen and paper to analyze base case...

    for(int i=1;i<n;i++)
    {
        for(int j=0;j<=W;j++)
        {
            int nt=dp[i-1][j];
            int t=-1e9;
            if(j-wt[i] >= 0)
            t=val[i]+dp[i-1][j-wt[i]];

            dp[i][j]=max(nt,t);
        }
    }

    return dp[n-1][W];
}

int main()
{
    vector<int> wt{1, 2, 4, 5};
    vector<int> val{5, 4, 8, 6};
    int W = 5;
    int n = wt.size();

    // vector<vector<int>>dp(n,vector<int>(W+1,-1));
    // cout<<knapsackHelp(wt,val,W,n-1,dp);

    vector<vector<int>>dp(n,vector<int>(W+1,0));
    cout<<knapsackHelpTab(wt,val,W,n-1,dp,n);
}