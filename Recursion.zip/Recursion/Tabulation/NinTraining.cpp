#include <bits/stdc++.h>
using namespace std;

int Train(int days,int lastTask,vector<vector<int>> &tasks,vector<vector<int>> &dp)
{
    if(days==0)
    {
        int maxi=0;
        for(int i=0;i<=2;i++)
        {
            if(i!=lastTask)
            {
                maxi=max(maxi,tasks[days][i]);
            }
        }

        return maxi;
    }

    if(dp[days][lastTask]!=-1)
    return dp[days][lastTask];

    int maxi=0;

    for(int i=0;i<=2;i++)
    {
        if(i!=lastTask)
        {
            int points=tasks[days][i] + Train(days-1,i,tasks,dp);
            maxi=max(points,maxi);
        }
    }

    return dp[days][lastTask]=maxi;
}

int TrainTab(int days,int lastTask,vector<vector<int>> &tasks,vector<vector<int>> &dp,int n)
{
    for(int i=0;i<=3;i++)
    {
        int maxi=-1;
        if(i!=lastTask)
        {
            maxi=max(maxi,dp[0][i]);
        }
        dp[0][i]=maxi;
    }

    for(int day=1;day<=n-1;day++)
    {
        for(int last=0;last<=3;last++)
        {
            
            int maxi=-1;

            

            dp[day][last]=
        }
    }
}

int main()
{
    vector<vector<int>>tasks{
        {2,1,3},
        {3,4,6},
        {10,1,6},
        {8,3,7}
    };

    int n=tasks.size();
    int m=tasks[0].size();
    int days=n;
    vector<vector<int>>dp(days,vector<int>(4,-1));
    // cout<<Train(days-1,3,tasks,dp);
    cout<<TrainTab(days-1,3,tasks,dp,n);

}