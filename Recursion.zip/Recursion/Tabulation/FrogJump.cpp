#include <bits/stdc++.h>
using namespace std;

int MemHelper(int ind,vector<int> &a,int n,vector<int> &dp)
{
    if(ind==0)
    return 0;

    if(ind<0)
    return 1e9;
    
    if(dp[ind]!=-1)
    return dp[ind];

    int l=MemHelper(ind-1,a,n,dp)+abs(a[ind]-a[ind-1]);
    int r=1e9;
    if(ind-1 > 0)
    {
        r=MemHelper(ind-2,a,n,dp)+abs(a[ind]-a[ind-2]);
    }

    return dp[ind]=min(l,r);
}

int Mem(vector<int> &a,int n,vector<int> &dp)
{
    return MemHelper(n-1,a,n,dp);
}

int TabHelper(int ind,vector<int> &a,int n,vector<int> &dp)
{
    dp[0]=0;

    for(int i=1;i<=n-1;i++)
    {
        int l=dp[i-1]+abs(a[i]-a[i-1]);
        int r=1e9;
        if(i>1)
        r=dp[i-2]+abs(a[i]-a[i-2]);

        dp[i]=min(l,r);
    }

    return dp[n-1];
}

int Tab(vector<int> &a,int n,vector<int> &dp)
{
    return TabHelper(n-1,a,n,dp);
}

int main()
{
    vector<int>a{30,10,60,10,60,50};
    //each time you can jump 1 or 2 steps...
    int n=a.size();
    vector<int>dp(n,-1);
    // cout<<Mem(a,n,dp)<<endl;
    cout<<Tab(a,n,dp)<<endl;
}

