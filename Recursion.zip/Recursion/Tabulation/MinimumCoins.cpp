#include <bits/stdc++.h>
using namespace std;

int Memo(int ind,int n,int target,vector<int>&a,vector<vector<int>> &dp)
{
    if(ind==0)
    {
        if(target%a[ind]==0)
        return target/a[ind];
        else
        return 1e9;
    }

    if(dp[ind][target]!=-1)
    return dp[ind][target];

    int nt=0+Memo(ind-1,n,target,a,dp);
    int t=1e9;
    if(target-a[ind] >= 0)
    {
        t=1+Memo(ind,n,target-a[ind],a,dp);
    }

    return dp[ind][target]=min(nt,t);
}

int tab(int n,int target,vector<int>&a,vector<vector<int>> &dp)
{
    for(int i=0;i<=target;i++)
    {
        if(i%a[0]==0)
        {
            dp[0][i]=i/a[0];
        }
        else
        {
            dp[0][i]=1e9;
        }
    }

    for(int i=1;i<=n-1;i++)
    {
        for(int j=0;j<=target;j++)
        {
            int nt=dp[i-1][j];
            int t=1e9;
            if(j-a[i]>=0)
            t=1+dp[i][j-a[i]];

            dp[i][j]=min(t,nt);
        }
    }

    return dp[n-1][target];
}

int main()
{
    vector<int> a{9, 6, 5, 1};
    int n=a.size();
    int target=19;
    // vector<vector<int>>dp(n,vector<int>(target+1,-1));
    // cout<<Memo(n-1,n,target,a,dp)<<endl;

    vector<vector<int>>dp(n,vector<int>(target+1,0));
    cout<<tab(n,target,a,dp);
}