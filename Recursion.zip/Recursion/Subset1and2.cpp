#include<bits/stdc++.h>
using namespace std;

void subset1(int i,vector<int> &a,vector<int> &ans,vector<int>& ds,int n,int sum)
{
    if(i==n)
    {
        ans.push_back(sum);
        return;
    }

    subset1(i+1,a,ans,ds,n,sum+a[i]);
    subset1(i+1,a,ans,ds,n,sum);
}

// void subset2(int i,vector<int> &a,vector<vector<int>> &ans,vector<int>& ds,int n,int sum)
// {
//     if(i==n)
//     {
//         ans.push_back(ds);
//         return;
//     }

//     ds.push_back(a[i]);
//     subset2(i+1,a,ans,ds,n,sum);
//     ds.pop_back();
//     subset2(i+1,a,ans,ds,n,sum);
// }

void subset3(int ind,vector<int> &a,vector<vector<int>> &ans,vector<int>& ds,int n,int sum)
{
    ans.push_back(ds);
    for(int i=ind;i<n;i++)
    {
        if(i!=ind && a[i]==a[i-1])
        continue;

        ds.push_back(a[ind]);
        subset3(ind+1,a,ans,ds,n,sum);
        ds.pop_back();
    }
}

int main()
{
    // vector<int>a{1,3,5,2};
    // vector<int>ans;
    // vector<int>ds;
    // subset1(0,a,ans,ds,a.size(),0);
    // for(auto i:ans)
    // cout<<i<<" ";

    vector<int>a{1,1,2,2};
    vector<vector<int>>ans;
    vector<int>ds;
    // subset2(0,a,ans,ds,a.size(),0);
    subset3(0,a,ans,ds,a.size(),0);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}