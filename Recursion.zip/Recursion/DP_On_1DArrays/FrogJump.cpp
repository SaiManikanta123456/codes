#include <bits/stdc++.h>
using namespace std;

int frogJump(int n, vector<int>a,int ind)
{
    if(ind==n-1)
    {
        return 0;
    }

    int one=frogJump(n,a,ind+1)+abs(a[ind]-a[ind+1]);
    int two=1e9;
    if(ind+2<n)
    {
        two=frogJump(n,a,ind+2)+abs(a[ind]-a[ind+2]);
    }

    return min(one,two);
}

int frogJumpModified(int n, vector<int>a,int ind,int k)
{
    if(ind==n-1)
    {
        return 0;
    }

    int minSteps=1e9;
    for(int i=1;i<=k;i++)
    {
        if(ind+i<n)
        {
            int val=frogJumpModified(n,a,ind+i,k)+abs(a[ind]-a[ind+i]);
            minSteps=min(minSteps,val);
        }
    }

    return minSteps;
}

int main()
{
    int n=5;
    vector<int>a{10, 100, 10, 100, 10};

    // cout<<frogJump(n,a,0);
    cout<<frogJumpModified(n,a,0,2);
}