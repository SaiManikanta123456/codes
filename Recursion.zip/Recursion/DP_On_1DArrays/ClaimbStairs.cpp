#include <bits/stdc++.h>
using namespace std;

int cs(int n,int ind)
{
    if(ind==n)
    return 1;

    int ways=cs(n,ind+1);

    if(ind+2<=n)
    ways=ways+cs(n,ind+2);

    return ways;
}

int main()
{
    int n=3;
    cout<<cs(n,0);
}