#include <bits/stdc++.h>
using namespace std;

int robber(int ind,vector<int>a,int n)
{
    if(ind==n-1)
    {
        return a[n-1];
    }

    if(ind>n-1)
    return 0;

    int notTake=0+robber(ind+1,a,n);
    int take=-1e9;
    if(ind+2<n)
    {
        take=a[ind]+robber(ind+2,a,n);
    }

    return max(take,notTake);
}

int main()
{
    int n=4;
    vector<int>a{2,1,4,9};
    cout<<robber(0,a,n);
    cout<<endl;
    vector<int>dp(n,0);
    dp[n-1]=a[n-1];

    for(int i=n-2;i>=0;i--)
    {
        int nT=dp[i+1];
        int T=0;
        if(i+2<=n-1)
        T=a[i]+dp[i+2];

        dp[i]=max(T,nT);
    }

    cout<< dp[0];
}