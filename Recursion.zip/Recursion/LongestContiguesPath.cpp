#include<bits/stdc++.h>
using namespace std;

int dfs(int row,int col,vector<vector<int>>a, int n,int m,vector<vector<int>> &dp)
{
    if(dp[row][col]!=-1)
        return dp[row][col];

    int dx[]={0,-1,0,1};
    int dy[]={-1,0,1,0};

    int ans=1;

    for(int i=0;i<4;i++)
    {
        int nr=dx[i]+row;
        int nc=dy[i]+col;

        if(nr>=0 && nr<n && nc>=0 && nc<m && 1+a[row][col]==a[nr][nc])
        {
            ans=1+dfs(nr,nc,a,n,m,dp);
        }
    }

    return dp[row][col]=ans;
}

int main()
{
    vector<vector<int>>a{{1,2,9},{5,3,8},{4,6,7}};
    int n=a.size();
    int m=a[0].size();

    int maxi=1;

    vector<vector<int>>dp(n,vector<int>(m,-1));

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            maxi=max(maxi,dfs(i,j,a,n,m,dp));
        }
    }
    cout<<maxi;
}