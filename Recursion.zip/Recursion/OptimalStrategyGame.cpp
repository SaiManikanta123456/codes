#include <bits/stdc++.h>
using namespace std;

int maxPoints(int i,int j,vector<int> &a)
{
    if(i>j)
    return 0;

    int takeFirst=a[i]+min(maxPoints(i+1,j-1,a),maxPoints(i+2,j,a));

    int takeLast=a[j]+min(maxPoints(i,j-2,a),maxPoints(i+1,j-1,a));

    return max(takeFirst,takeLast);
}

int main()
{
    vector<int>a{8,15,3,7};
    int n=a.size();
    cout<<maxPoints(0,n-1,a);
}