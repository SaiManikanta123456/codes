#include <bits/stdc++.h>
using namespace std;

void printAllSubSeqWithTarget(int i,vector<int>a,vector<vector<int>> &ans,vector<int>&ds,int n,int target,int sum)
{
    if(i==n)
    {
        if(sum==target)
        {
            ans.push_back(ds);
            return;
        }
        return;
    }

    sum=sum+a[i];
    ds.push_back(a[i]);
    printAllSubSeqWithTarget(i+1,a,ans,ds,n,target,sum);

    sum=sum-a[i];
    ds.pop_back();
    printAllSubSeqWithTarget(i+1,a,ans,ds,n,target,sum);
}

void printAllSubSeq(int i,vector<int>a,vector<vector<int>> &ans,vector<int>&ds,int n)
{
    if(i==n)
    {
        ans.push_back(ds);
        return;
    }

    ds.push_back(a[i]);
    printAllSubSeq(i+1,a,ans,ds,n);

    ds.pop_back();
    printAllSubSeq(i+1,a,ans,ds,n);
}

int countSubSeqWithTarget(int i,vector<int>a,int n,int target,int sum)
{
    if(i==n)
    {
        if(target==sum)
        {
            return 1;
        }
        return 0;
    }

    sum=sum+a[i];
    int l=countSubSeqWithTarget(i+1,a,n,target,sum);

    sum=sum-a[i];
    int r=countSubSeqWithTarget(i+1,a,n,target,sum);

    return l+r;
}

int main()
{
    vector<int>a{1,2,3,4};
    //print all subsequences
    vector<vector<int>>ans;
    vector<int>ds;
    // printAllSubSeq(0,a,ans,ds,a.size());
    int target=4;
    int sum=0;
    // printAllSubSeqWithTarget(0,a,ans,ds,a.size(),target,sum);
    // for(auto i:ans)
    // {
    //     for(auto j:i)
    //     {
    //         cout<<j<<" ";
    //     }
    //     cout<<endl;
    // }

    cout<<countSubSeqWithTarget(0,a,a.size(),target,sum);
}