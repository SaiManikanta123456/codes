#include <bits/stdc++.h>
using namespace std;

int coinchangeHelper(vector<int> &a,int target,int ind)
{
    if(ind<0)
    {
        if(target==0)
        return 1;

        return 0;
    }

    int nottake=coinchangeHelper(a,target,ind-1);
    int take=0;
    if(target>=a[ind])
    take=coinchangeHelper(a,target-a[ind],ind);

    return take+nottake;
}
void coinchange(vector<int> &a,int target)
{
    cout<<coinchangeHelper(a,target,a.size()-1);
}
int main()
{
    vector<int>a{1,2,3};
    int target=4; //Can take 1 element any number of times....so while picking the element don't alter index....
    coinchange(a,target);
}