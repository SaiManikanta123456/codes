#include <bits/stdc++.h>
using namespace std;

int targetSum(vector<int> &a,int target,int ind,int s,map<pair<int,int>,int> &dp)
{
    if(ind==0)
    {
        if(target-s+a[0]==0)
        return 1;
        if(target-s-a[0]==0)
        return 1;

        return 0;
    }

    if(dp.find({ind,s})!=dp.end())
    return dp[{ind,s}];

    int plus=targetSum(a,target,ind-1,s+a[ind],dp);
    int minus=targetSum(a,target,ind-1,s-a[ind],dp);

    return dp[{ind,s}]=plus+minus;
}

void f(vector<int> &a,int target)
{
    int s=0;
    int n=a.size();
    map<pair<int,int>,int>dp;
    cout<<targetSum(a,target,a.size()-1,s,dp);
}

int main()
{
    vector<int>a{1,2,3,1};
    int target=3;

    f(a,target);
}