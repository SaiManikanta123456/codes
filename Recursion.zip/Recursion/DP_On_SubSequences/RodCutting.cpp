#include <bits/stdc++.h>
using namespace std;

int rodCuttingHelper(vector<int> &a,int N,int ind)
{
    if(ind==0)
    {
        return N*a[0];
    }

    int nottake=rodCuttingHelper(a,N,ind-1);
    int take=0;
    int rod_len=ind+1;

    if(rod_len<=N)
    {
        take=rodCuttingHelper(a,N-rod_len,ind);
    }

    return max(take,nottake);
}

void rodcutting(vector<int> &a,int N)
{
    int n=a.size();
    cout<<rodCuttingHelper(a,N,a.size()-1);
}

int main()
{
    vector<int>a{2,5,7,8,10};
    int N=5;
    rodcutting(a,N);
}