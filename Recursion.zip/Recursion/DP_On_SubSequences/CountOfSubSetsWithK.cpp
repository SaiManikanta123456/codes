#include <bits/stdc++.h>
using namespace std;

int countSubSeqKHelp(int ind,vector<int> &a,int target,vector<vector<int>> &dp)
{
    if(target==0)
    return dp[ind][target]=1;
    if(ind==0)
    {
        return dp[ind][target]=(a[ind]==target);
    }
    
    if(dp[ind][target]!=-1)
    {
        return dp[ind][target];
    }

    int nottake=countSubSeqKHelp(ind-1,a,target,dp);
    int take=0;
    if(a[ind]<=target)
    take=countSubSeqKHelp(ind-1,a,target-a[ind],dp);

    return dp[ind][target]=take+nottake;
}

void countSubSeqK(vector<int> &a,int target)
{
    vector<vector<int>>dp(a.size(),vector<int>(target+1,-1));
    cout<<countSubSeqKHelp(a.size()-1,a,target,dp);
}

int main()
{
    vector<int>a{1,2,3,4};
    int target=4;
    countSubSeqK(a,target);
}