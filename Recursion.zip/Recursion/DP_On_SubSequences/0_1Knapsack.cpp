#include <bits/stdc++.h>
using namespace std;

int knapsackHelp(vector<int>&wt,vector<int> &val,int W,int ind,vector<vector<int>> &dp)
{
    if(ind==0)
    {
        if(wt[0]<=W)
        {
            return dp[ind][W]=val[0];
        }
        else
        {
            return INT_MIN;
        }
    }

    if(dp[ind][W]!=-1)
    return dp[ind][W];

    int nottake=knapsackHelp(wt,val,W,ind-1,dp);
    int take=0;
    if(wt[ind]<=W)
    {
        take=val[ind]+knapsackHelp(wt,val,W-wt[ind],ind-1,dp);
    }

    return dp[ind][W]=max(take,nottake);
}

void knapsack(vector<int>&wt,vector<int> &val,int W,int n)
{
    vector<vector<int>>dp(n,vector<int>(W+1,-1));
    cout<<knapsackHelp(wt,val,W,n-1,dp);
}

int main()
{
    vector<int> wt{1, 2, 4, 5};
    vector<int> val{5, 4, 8, 6};
    int W = 5;
    int n = wt.size();
    knapsack(wt,val,W,n);
}