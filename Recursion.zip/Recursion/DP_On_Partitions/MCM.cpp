#include <bits/stdc++.h>
using namespace std;

int f(vector<int> &a,int i,int j,int n)
{
    if(i==j)
    return 0;

    int mini=1e9;

    for(int k=i;k<j;k++)
    {
        int steps=a[i-1]*a[k]*a[j]+f(a,i,k,n)+f(a,k+1,j,n);

        mini=min(mini,steps);
    }

    return mini;
}

int main()
{
    vector<int>a{10,20,30,40,50};
    int n=a.size();
    cout<<f(a,1,n-1,n);
}

