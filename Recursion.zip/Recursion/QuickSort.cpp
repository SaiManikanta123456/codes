#include<bits/stdc++.h>
using namespace std;

int QuickHelper(vector<int> &a, int low,int high)
{
    int pivot=a[low];
    int i=low;
    int j=high;

    while(i<j)
    {
        while(a[i]<=pivot && i<=high-1)
        {
            i++;
        }
        while(a[j]>pivot && j>=low+1)
        {
            j--;
        }

        if(i<j)
        swap(a[i],a[j]);
    }
    swap(a[j],a[low]);

    return j;
}

void QuickSort(vector<int> &a, int low,int high)
{
    if(low<high)
    {
        int pIdx=QuickHelper(a,low,high);
        QuickSort(a,low,pIdx-1);
        QuickSort(a,pIdx+1,high);
    }
}

int main()
{
    vector<int>a{4,5,1,2,3,7,9,6};
    QuickSort(a,0,a.size()-1);
    for(auto i:a)
    {
        cout<<i<<" ";
    }
}