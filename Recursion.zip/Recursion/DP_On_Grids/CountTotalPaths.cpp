#include <bits/stdc++.h>
using namespace std;

int gridUniquePaths1Helper(int i,int j,int n,int m,vector<vector<int>> &grid,vector<vector<int>> &dp)
{
    if(i==n-1 && j==m-1)
    {
        return 1;
    }

    if(i>n-1 || j>m-1)
    {
        return 0;
    }

    if(dp[i][j]!=-1)
    return dp[i][j];

    int l=gridUniquePaths1Helper(i+1,j,n,m,grid,dp);
    int r=gridUniquePaths1Helper(i,j+1,n,m,grid,dp);

    return dp[i][j]=l+r;
}
void gridUniquePaths1()
{
    vector<vector<int>>grid{
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    int n=grid.size();
    int m=grid[0].size();
    vector<vector<int>>dp(n+1,vector<int>(m+1,-1));
    cout<<gridUniquePaths1Helper(0,0,n,m,grid,dp);
}

int minCostPathHelper(int i,int j,int n,int m,vector<vector<int>>grid,vector<vector<int>> &dp)
{
    if(i==n-1 && j==m-1)
    {
        return grid[i][j];
    }

    if(i>n-1 || j>m-1)
    {
        return 1e9;
    }

    if(dp[i][j]!=-1)
    {
        return dp[i][j];
    }

    int l=grid[i][j]+minCostPathHelper(i+1,j,n,m,grid,dp);
    int r=grid[i][j]+minCostPathHelper(i,j+1,n,m,grid,dp);

    return dp[i][j]=min(l,r);
}

void minCostPath()
{
    vector<vector<int>>grid{
        {1,2,3},
        {4,5,6},
        {7,8,9}
    };

    int n=grid.size();
    int m=grid[0].size();

    vector<vector<int>>dp(n+1,vector<int>(m+1,-1));
    cout<<minCostPathHelper(0,0,n,m,grid,dp);
}

int main()
{
    //fixed start and fixed end...
    // gridUniquePaths1();
    // gridUniquePaths2();
    minCostPath();
}