#include <bits/stdc++.h>
using namespace std;

int lcsHelper(string s1, string s2, int i, int j, vector<vector<int>> &dp) {
    if (i == 0 || j == 0) {
        return 0;
    }

    if (dp[i][j] != -1)
        return dp[i][j];

    if (s1[i - 1] == s2[j - 1]) { // Matching character
        return dp[i][j] = 1 + lcsHelper(s1, s2, i - 1, j - 1, dp);
    } else {
        return dp[i][j] = max(lcsHelper(s1, s2, i - 1, j, dp), lcsHelper(s1, s2, i, j - 1, dp));
    }
}

string printlcsstring(vector<vector<int>> &dp, string s1, string s2) {
    int n = s1.size();
    int m = s2.size();

    int i = n, j = m;
    string ans = "";

    while (i > 0 && j > 0) {
        if (s1[i - 1] == s2[j - 1]) { // Match found
            ans.push_back(s1[i - 1]);
            i--;
            j--;
        } else if (dp[i - 1][j] > dp[i][j - 1]) {
            i--;
        } else {
            j--;
        }
    }

    reverse(ans.begin(), ans.end());
    return ans;
}

void lcs(string s1, string s2) {
    int n = s1.length();
    int m = s2.length();
    vector<vector<int>> dp(n + 1, vector<int>(m + 1, -1));

    cout << "Length of LCS: " << lcsHelper(s1, s2, n, m, dp) << endl;

    cout << "DP Table:" << endl;
    for (int i = 0; i <= n; i++) {
        for (int j = 0; j <= m; j++) {
            cout << dp[i][j] << " ";
        }
        cout << endl;
    }

    cout << "LCS String: " << printlcsstring(dp, s1, s2) << endl;
}

int main() {
    string s1 = "amx";
    string s2 = "abmcx";
    lcs(s1, s2);
}
