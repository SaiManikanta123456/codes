#include<bits/stdc++.h>
using namespace std;
void rec_f(int n,string x)
{
    if(n==0)
    return;
    cout<<n<<endl;
    rec_f(n-1,x);
}

void f_1(string x)
{
    rec_f(5,x);
}

int f_2(int n)
{
    if(n==0)
    return 0;
    if(n==1)
    return 1;
    int sum=f_2(n-1)+f_2(n-2);
    return sum;
}
void f_3(int n,vector<int> &a,int ind,vector<int> &ans)
{
    if(ind==n)
    {
        for(auto i:ans)
        {
            cout<<i<<" ";         
        }
        cout<<endl;
        return;
    }

    ans.push_back(a[ind]);
    f_3(n,a,ind+1,ans);

    ans.pop_back();
    f_3(n,a,ind+1,ans);
}
void merge(vector<int> &a,int low,int mid,int high)
{
    vector<int>temp;
    int left=low;
    int right=mid+1;
    while(left<=mid && right<=high)
    {
        if(a[left]<=a[right])
        {
            temp.push_back(a[left]);
            left++;
        }
        else
        {
            temp.push_back(a[right]);
            right++;
        }
    }

    while(left<=mid)
    {
        temp.push_back(a[left]);
        left++;
    }
    while(right<=high)
    {
        temp.push_back(a[right]);
        right++;
    }

    for(int i=low;i<=high;i++)
    {
        a[i]=temp[i-low];
    }

}
void mergeSort(vector<int> &a,int low,int high)
{
    if(low>=high)
    {
        return;
    }
    int mid=(low+high)/2;

    mergeSort(a,low,mid);
    mergeSort(a,mid+1,high);
    merge(a,low,mid,high);
}

void f_4(int ind,vector<int> &a,int target,vector<int>&ans,int n)
{
    if(ind==n)
    {
        if(target==0)
        {
            for(auto i:ans)
            {
                cout<<i<<" ";
            }
            cout<<endl;
        }

        return;
    }

    if(a[ind]<=target)
    {
    ans.push_back(a[ind]);
    f_4(ind,a,target-a[ind],ans,n);
    ans.pop_back();
    }

    f_4(ind+1,a,target,ans,n);
}
void f_5(int ind,vector<int> &a,vector<vector<int>> &ans,int n,vector<bool> &freq,vector<int> &ds)
{
    if(ds.size()==n)
    {
        ans.push_back(ds);
        return;
    }

    for(int i=0;i<n;i++)
    {
        if(!freq[i])
        {
        freq[i]=true;
        ds.push_back(a[i]);
        f_5(ind,a,ans,n,freq,ds);
        ds.pop_back();
        freq[i]=false;
        }
    }
}
int main()
{
    string x="sai";
    // f_1(x);
    // cout<<f_2(6);
    // vector<int>a{11,52,83,0,67};
    // vector<int>ans;
    // f_3(3,a,0,ans);
    // mergeSort(a,0,a.size());
    // for(auto i:a)
    // cout<<i<<" ";
    vector<int>a{2,3};
    // vector<int>ans;
    // f_4(0,a,7,ans,a.size());
    vector<vector<int>>ans;
    vector<bool>freq(a.size(),false);
    vector<int> ds;
    f_5(0,a,ans,a.size(),freq,ds);
    for(auto i:ans)
    {
        for(auto j:i)
        {
            cout<<j<<" ";
        }
        cout<<endl;
    }
}