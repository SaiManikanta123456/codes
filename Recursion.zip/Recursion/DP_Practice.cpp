#include <bits/stdc++.h>
using namespace std;

int LCSHelper(string s1,string s2,int i,int j,int n,int m,vector<vector<int>> &dp,int &maxi)
{
    if(i<0 || j<0)
    return 0;

    if(dp[i][j]!=-1)
    return dp[i][j];

    if(s1[i]==s2[j])
    {     
        dp[i][j]=1+LCSHelper(s1,s2,i-1,j-1,n,m,dp,maxi);
        maxi=max(maxi,dp[i][j]);
        return dp[i][j];
    }
    else
    {
        dp[i][j]=0;
        return dp[i][j]=max(LCSHelper(s1,s2,i,j-1,n,m,dp,maxi),LCSHelper(s1,s2,i-1,j,n,m,dp,maxi));
    }

    return maxi;
}

void LCS(string s1,string s2)
{
    int n=s1.length();
    int m=s2.length();
    vector<vector<int>>dp(n,vector<int>(m,-1));
    cout<<LCSHelper(s1,s2,n-1,m-1,n,m,dp,-99);
}

int main()
{
    string s1="mani";
    string s2="kanta";
    LCS(s1,s2);
}