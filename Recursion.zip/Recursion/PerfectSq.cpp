#include <bits/stdc++.h>
using namespace std;

int f(vector<vector<int>> &a,int n,int m,int row,int col)
{
    if(row>=n || col>=m)
    return -1e9;

    if(row==n-1)
    {
        return a[row][col];
    }

    int down=a[row][col]+f(a,n,m,row+1,col);
    int left=a[row][col]+f(a,n,m,row,col+1);
    int leftdown=a[row][col]+f(a,n,m,row+1,col+1);

    return max({down,left,leftdown});
}

int countPaths(vector<vector<int>> &a,int n,int m,int row,int col,int target)
{
    if(row>=n || col>=m)
    return 0;

    if(row==n-1 && col==m-1)
    {
        if(target==a[row][col])
            return 1;
        else
            return 0;
    }

    int down=countPaths(a,n,m,row+1,col,target-a[row][col]);
    int left=countPaths(a,n,m,row,col+1,target-a[row][col]);
    int leftdown=countPaths(a,n,m,row+1,col+1,target-a[row][col]);
    int rightdown=countPaths(a,n,m,row+1,col-1,target-a[row][col]);

    return down+left+leftdown+rightdown;
}

int main()
{
    vector<vector<int>>a{{9,1,9},{7,9,2},{9,0,9}};
    int n=a.size();
    int m=a[0].size();

    int maxSum=-1;
    // for(int i=0;i<m;i++)
    maxSum=max(maxSum,f(a,n,m,0,0));

    cout<<maxSum<<endl;
    cout<<countPaths(a,n,m,0,0,maxSum);
}